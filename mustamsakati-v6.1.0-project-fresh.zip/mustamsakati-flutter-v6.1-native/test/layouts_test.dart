import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as im;
import 'package:mustamsakati/exporters.dart';
import 'package:mustamsakati/layouts.dart';
import 'package:mustamsakati/perspective.dart';
import 'package:mustamsakati/scan_filters.dart';

void main() {
  test('Moving a single corner leaves the other corners fixed', () {
    final original = List<Offset>.from(defaultCorners);
    final changed = List<Offset>.from(original);
    changed[0] = const Offset(.13, .1);
    expect(isValidQuadrilateral(changed), isTrue);
    expect(changed[1], original[1]);
    expect(changed[2], original[2]);
    expect(changed[3], original[3]);
  });

  test('Crossing corners is rejected', () {
    expect(isValidQuadrilateral(const [
      Offset(.1, .1), Offset(.9, .9), Offset(.9, .1), Offset(.1, .9),
    ]), isFalse);
  });

  test('Homography maps all four destination corners correctly', () {
    const corners = [
      Offset(.1, .08), Offset(.91, .02), Offset(.85, .9), Offset(.18, .82),
    ];
    final h = solveHomography(corners);
    const outputCorners = [
      Offset(0, 0), Offset(1, 0), Offset(1, 1), Offset(0, 1),
    ];
    for (var i = 0; i < 4; ++i) {
      final u = outputCorners[i].dx;
      final v = outputCorners[i].dy;
      final d = h[6] * u + h[7] * v + 1;
      expect((h[0] * u + h[1] * v + h[2]) / d,
          closeTo(corners[i].dx, 1e-8));
      expect((h[3] * u + h[4] * v + h[5]) / d,
          closeTo(corners[i].dy, 1e-8));
    }
  });

  test('Every layout includes real image placements, never a line alone', () {
    final bytesA = Uint8List.fromList(im.encodeJpg(im.Image(width: 120, height: 70)));
    final bytesB = Uint8List.fromList(im.encodeJpg(im.Image(width: 120, height: 70)));
    final first = PhotoData(bytesA, 120, 70);
    final second = PhotoData(bytesB, 120, 70);
    final doc = ScanDocument('بطاقة وطنية')..front = first..back = second;
    final settings = PrintSettings();
    for (final style in LayoutStyle.values) {
      settings.style = style;
      final pages = layoutDocument(doc, settings);
      expect(pages.expand((page) => page.placements).length, 2,
          reason: '$style must show BOTH scanned sides');
      for (final item in pages.expand((page) => page.placements)) {
        expect(item.photo.bytes.isNotEmpty, isTrue);
        expect(item.rect.width, greaterThan(10));
        expect(item.rect.height, greaterThan(10));
      }
      if (style == LayoutStyle.separate || style == LayoutStyle.single) {
        expect(pages.length, 2);
      } else {
        expect(pages.length, 1);
        expect(pages.first.placements.length, 2);
      }
    }
  });

  test('Original photo survives selecting scanner appearances', () {
    final original = PhotoData(Uint8List.fromList([1, 2, 3]), 120, 80);
    final scanned = PhotoData(Uint8List.fromList([4, 5, 6]), 120, 80);
    final document = ScanDocument('اختبار')
      ..frontOriginal = original
      ..front = scanned
      ..frontAppearance = ScanAppearance.gray;
    expect(identical(document.frontOriginal, original), isTrue);
    document.front = document.frontOriginal;
    document.frontAppearance = ScanAppearance.original;
    expect(identical(document.front, original), isTrue);
  });

  test('Scanner outputs real color, gray and black-white image bytes', () {
    final bitmap = im.Image(width: 30, height: 20);
    for (var y = 0; y < 20; ++y) {
      for (var x = 0; x < 30; ++x) {
        bitmap.setPixelRgb(x, y, x < 15 ? 24 : 238,
          x < 15 ? 61 : 232, x < 15 ? 102 : 221);
      }
    }
    final original = Uint8List.fromList(im.encodeJpg(bitmap, quality: 100));
    expect(identical(scanImageSync(original, ScanAppearance.original), original), isTrue);
    for (final filter in [ScanAppearance.color, ScanAppearance.gray,
        ScanAppearance.blackWhite]) {
      final result = scanImageSync(original, filter);
      expect(result.take(2).toList(), [255, 216]);
      final decoded = im.decodeJpg(result)!;
      expect(decoded.width, 30);
      expect(decoded.height, 20);
      final sample = decoded.getPixel(5, 10);
      if (filter == ScanAppearance.gray) {
        expect((sample.r - sample.g).abs(), lessThan(5));
        expect((sample.g - sample.b).abs(), lessThan(5));
      }
      if (filter == ScanAppearance.blackWhite) {
        expect(sample.r, lessThan(12));
        final light = decoded.getPixel(25, 10);
        expect(light.r, greaterThan(242));
      }
    }
  });

  test('All layouts stay inside page margins', () {
    final photo = PhotoData(Uint8List.fromList([1, 2]), 1200, 720);
    final doc = ScanDocument('test')..front = photo..back = photo;
    final settings = PrintSettings();
    for (final layout in LayoutStyle.values) {
      settings.style = layout;
      for (final page in layoutDocument(doc, settings)) {
        for (final p in page.placements) {
          expect(p.rect.left >= settings.margin - 0.01, isTrue, reason: '$layout left');
          expect(p.rect.top >= settings.margin - 0.01, isTrue, reason: '$layout top');
          expect(p.rect.right <= settings.paper.width - settings.margin + 0.01,
              isTrue, reason: '$layout right');
          expect(p.rect.bottom <= settings.paper.height - settings.margin + 0.01,
              isTrue, reason: '$layout bottom');
        }
      }
    }
  });


  test('PDF output has a real PDF header and two images', () async {
    final bitmap = im.Image(width: 32, height: 20);
    final photo = PhotoData(Uint8List.fromList(im.encodeJpg(bitmap)), 32, 20);
    final doc = ScanDocument('test')..front = photo..back = photo;
    final settings = PrintSettings()..style = LayoutStyle.stackRight;
    final pdf = await Exporter.makePdf(layoutDocument(doc, settings), settings);
    expect(String.fromCharCodes(pdf.take(4)), '%PDF');
  });

  test('Word is an OOXML archive with positioned editable images', () {
    final photo = PhotoData(Uint8List.fromList([0xFF, 0xD8, 0xFF, 0xD9]), 120, 80);
    final doc = ScanDocument('test')..front = photo..back = photo;
    final bytes = Exporter.makeDocx(layoutDocument(doc, PrintSettings()), PrintSettings());
    final zip = ZipDecoder().decodeBytes(bytes);
    final names = zip.files.map((f) => f.name).toSet();
    expect(names.contains('[Content_Types].xml'), isTrue);
    expect(names.contains('word/document.xml'), isTrue);
    expect(names.contains('word/media/image1.jpg'), isTrue);
    expect(names.contains('word/media/image2.jpg'), isTrue);
  });
}
