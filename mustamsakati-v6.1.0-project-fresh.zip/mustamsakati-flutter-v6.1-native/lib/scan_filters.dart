import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show IconData, Icons;
import 'package:image/image.dart' as im;

import 'layouts.dart';

extension ScanAppearanceLabel on ScanAppearance {
  String get label => switch (this) {
    ScanAppearance.original => 'الأصلية',
    ScanAppearance.color => 'ملوّن',
    ScanAppearance.gray => 'رمادي',
    ScanAppearance.blackWhite => 'أبيض وأسود',
  };

  IconData get icon => switch (this) {
    ScanAppearance.original => Icons.photo_outlined,
    ScanAppearance.color => Icons.palette_outlined,
    ScanAppearance.gray => Icons.gradient_outlined,
    ScanAppearance.blackWhite => Icons.contrast_outlined,
  };
}

class _ScanJob {
  const _ScanJob(this.bytes, this.appearance);
  final Uint8List bytes;
  final ScanAppearance appearance;
}

/// Runs off the UI isolate; selecting the original never calls this function.
Future<Uint8List> scanImageAsync(
        Uint8List originalBytes, ScanAppearance appearance) =>
    compute(_runScanner, _ScanJob(originalBytes, appearance));

/// Exposed for deterministic tests using tiny generated images.
Uint8List scanImageSync(Uint8List bytes, ScanAppearance appearance) =>
    _runScanner(_ScanJob(bytes, appearance));

Uint8List _runScanner(_ScanJob job) {
  if (job.appearance == ScanAppearance.original) return job.bytes;
  final decoded = im.decodeImage(job.bytes);
  if (decoded == null) throw const FormatException('Unsupported image format');
  var source = im.bakeOrientation(decoded);
  final longSide = math.max(source.width, source.height);
  if (longSide > 2000) {
    final factor = 2000.0 / longSide;
    source = im.copyResize(source,
      width: math.max(1, (source.width * factor).round()),
      height: math.max(1, (source.height * factor).round()),
      interpolation: im.Interpolation.linear);
  }
  final result = im.Image(width: source.width, height: source.height,
    numChannels: 3);
  for (var y = 0; y < source.height; y++) {
    for (var x = 0; x < source.width; x++) {
      final p = source.getPixel(x, y);
      final alpha = (p.a / 255).clamp(0.0, 1.0);
      final red = p.r * alpha + 255 * (1 - alpha);
      final green = p.g * alpha + 255 * (1 - alpha);
      final blue = p.b * alpha + 255 * (1 - alpha);
      int bright(num v) => ((v - 128) * 1.12 + 135).round().clamp(0, 255).toInt();
      final gray = (red * .299 + green * .587 + blue * .114);
      if (job.appearance == ScanAppearance.color) {
        result.setPixelRgb(x, y,
          bright(red), bright(green), bright(blue));
      } else if (job.appearance == ScanAppearance.gray) {
        final value = bright(gray);
        result.setPixelRgb(x, y, value, value, value);
      } else {
        // Binary threshold: most useful for printed paper documents.
        final value = gray >= 152 ? 255 : 0;
        result.setPixelRgb(x, y, value, value, value);
      }
    }
  }
  return Uint8List.fromList(im.encodeJpg(result, quality: 91));
}
