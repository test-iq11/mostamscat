import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/painting.dart';
import 'package:image/image.dart' as im;

/// Coordinates are normalized (0..1) and ordered TL, TR, BR, BL.
const defaultCorners = <Offset>[
  Offset(0.04, 0.04),
  Offset(0.96, 0.04),
  Offset(0.96, 0.96),
  Offset(0.04, 0.96),
];

bool isValidQuadrilateral(List<Offset> p) {
  if (p.length != 4) return false;
  if (p.any((v) => v.dx < 0 || v.dx > 1 || v.dy < 0 || v.dy > 1)) {
    return false;
  }
  double? sign;
  for (var i = 0; i < 4; ++i) {
    final a = p[i];
    final b = p[(i + 1) % 4];
    final c = p[(i + 2) % 4];
    final cross = (b.dx - a.dx) * (c.dy - b.dy) -
        (b.dy - a.dy) * (c.dx - b.dx);
    if (cross.abs() < 0.0002) return false;
    sign ??= cross;
    if (sign * cross < 0) return false;
  }
  return true;
}

/// Solve H*[u,v,1] => [sourceX,sourceY,1].
/// Four independent source corners yield perspective correction, not a simple crop.
List<double> solveHomography(List<Offset> corners) {
  if (!isValidQuadrilateral(corners)) {
    throw ArgumentError('Invalid image corners');
  }
  const targets = <Offset>[
    Offset(0, 0),
    Offset(1, 0),
    Offset(1, 1),
    Offset(0, 1),
  ];
  final a = List.generate(8, (_) => List<double>.filled(9, 0));
  for (var i = 0; i < 4; ++i) {
    final u = targets[i].dx;
    final v = targets[i].dy;
    final x = corners[i].dx;
    final y = corners[i].dy;
    a[i * 2] = [u, v, 1, 0, 0, 0, -u * x, -v * x, x];
    a[i * 2 + 1] = [0, 0, 0, u, v, 1, -u * y, -v * y, y];
  }
  for (var column = 0; column < 8; ++column) {
    var pivot = column;
    for (var row = column + 1; row < 8; ++row) {
      if (a[row][column].abs() > a[pivot][column].abs()) pivot = row;
    }
    if (a[pivot][column].abs() < 1e-12) {
      throw StateError('Corners are too close to compute a perspective transform');
    }
    if (pivot != column) {
      final temp = a[column];
      a[column] = a[pivot];
      a[pivot] = temp;
    }
    final factor = a[column][column];
    for (var j = column; j < 9; ++j) {
      a[column][j] /= factor;
    }
    for (var row = 0; row < 8; ++row) {
      if (row == column) continue;
      final scale = a[row][column];
      for (var j = column; j < 9; ++j) {
        a[row][j] -= scale * a[column][j];
      }
    }
  }
  return [for (var i = 0; i < 8; ++i) a[i][8]];
}

class PerspectiveArgs {
  const PerspectiveArgs(this.bytes, this.corners, this.rotation, this.brightness);
  final Uint8List bytes;
  final List<Offset> corners;
  final int rotation;
  final int brightness;
}

Future<Uint8List> rectifyImage(PerspectiveArgs args) =>
    compute(_rectifyInIsolate, args);

Uint8List _rectifyInIsolate(PerspectiveArgs args) {
  final decoded = im.decodeImage(args.bytes);
  if (decoded == null) throw const FormatException('The image could not be decoded');
  final source = im.bakeOrientation(decoded);
  final corners = args.corners;
  final h = solveHomography(corners);
  final w = source.width.toDouble();
  final height = source.height.toDouble();
  final top = (corners[1] - corners[0]).distance;
  final bottom = (corners[2] - corners[3]).distance;
  final left = (corners[3] - corners[0]).distance;
  final right = (corners[2] - corners[1]).distance;
  final estimatedWidth = math.max(64.0, (top + bottom) * 0.5 * w);
  final estimatedHeight = math.max(64.0, (left + right) * 0.5 * height);
  final maxSide = math.max(estimatedWidth, estimatedHeight);
  final limitScale = math.min(1.0, 2200.0 / maxSide);
  final dstWidth = (estimatedWidth * limitScale).round().clamp(64, 2200).toInt();
  final dstHeight = (estimatedHeight * limitScale).round().clamp(64, 2200).toInt();
  final output = im.Image(width: dstWidth, height: dstHeight);
  for (var y = 0; y < dstHeight; ++y) {
    final v = dstHeight == 1 ? 0.0 : y / (dstHeight - 1);
    for (var x = 0; x < dstWidth; ++x) {
      final u = dstWidth == 1 ? 0.0 : x / (dstWidth - 1);
      final divisor = h[6] * u + h[7] * v + 1;
      final sx = ((h[0] * u + h[1] * v + h[2]) / divisor *
              (source.width - 1))
          .clamp(0.0, source.width - 1.0);
      final sy = ((h[3] * u + h[4] * v + h[5]) / divisor *
              (source.height - 1))
          .clamp(0.0, source.height - 1.0);
      final x0 = sx.floor();
      final y0 = sy.floor();
      final x1 = math.min(x0 + 1, source.width - 1);
      final y1 = math.min(y0 + 1, source.height - 1);
      final fx = sx - x0;
      final fy = sy - y0;
      final a = source.getPixel(x0, y0);
      final b = source.getPixel(x1, y0);
      final c = source.getPixel(x0, y1);
      final d = source.getPixel(x1, y1);
      num channel(num av, num bv, num cv, num dv) =>
          ((av * (1 - fx) + bv * fx) * (1 - fy) +
                  (cv * (1 - fx) + dv * fx) * fy +
                  args.brightness)
              .clamp(0, 255);
      output.setPixelRgb(
        x,
        y,
        channel(a.r, b.r, c.r, d.r),
        channel(a.g, b.g, c.g, d.g),
        channel(a.b, b.b, c.b, d.b),
      );
    }
  }
  final result = args.rotation % 360 == 0
      ? output
      : im.copyRotate(output, angle: args.rotation % 360);
  return Uint8List.fromList(im.encodeJpg(result, quality: 92));
}

Future<Uint8List> normalizeImage(Uint8List bytes) =>
    compute(_normalizeInIsolate, bytes);

Uint8List _normalizeInIsolate(Uint8List bytes) {
  final decoded = im.decodeImage(bytes);
  if (decoded == null) throw const FormatException('Unsupported image format');
  var source = im.bakeOrientation(decoded);
  if (math.max(source.width, source.height) > 2800) {
    source = im.copyResize(source,
        width: (source.width * 2800 / math.max(source.width, source.height)).round(),
        height: (source.height * 2800 / math.max(source.width, source.height)).round(),
        interpolation: im.Interpolation.linear);
  }
  return Uint8List.fromList(im.encodeJpg(source, quality: 93));
}
