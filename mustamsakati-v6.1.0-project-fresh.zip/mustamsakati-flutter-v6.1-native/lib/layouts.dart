import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';

enum LayoutStyle {
  sideCenter('متجاورتان في الوسط', Icons.view_column_outlined),
  verticalCenter('أعلى وأسفل', Icons.view_agenda_outlined),
  separate('كل صورة في صفحة', Icons.layers_outlined),
  halves('نصفا الصفحة', Icons.vertical_distribute_outlined),
  single('صورة واحدة / صفحة', Icons.crop_portrait),
  free('ترتيب حر بالسحب', Icons.open_with_rounded),
  sideTop('متجاورتان أعلى الورقة', Icons.vertical_align_top_rounded),
  stackRight('صورتان جهة اليمين', Icons.align_horizontal_right_rounded),
  stackLeft('صورتان جهة اليسار', Icons.align_horizontal_left_rounded);

  const LayoutStyle(this.label, this.icon);
  final String label;
  final IconData icon;
}

class PhotoData {
  const PhotoData(this.bytes, this.width, this.height);
  final Uint8List bytes;
  final int width;
  final int height;
  double get aspect => width / height;
}

enum ScanAppearance { original, color, gray, blackWhite }

class ScanDocument {
  ScanDocument(this.title);
  final String title;
  PhotoData? front;
  PhotoData? back;
  // Preserve the untouched photograph so the user can switch modes at any time.
  PhotoData? frontOriginal;
  PhotoData? backOriginal;
  ScanAppearance frontAppearance = ScanAppearance.original;
  ScanAppearance backAppearance = ScanAppearance.original;
  List<PhotoData> get photos => [if (front != null) front!, if (back != null) back!];
}

class ImagePlacement {
  ImagePlacement(this.photo, this.rect, this.index);
  final PhotoData photo;
  Rect rect;
  final int index;
}

class LayoutSheet {
  LayoutSheet(this.placements, {this.cutLine = false});
  final List<ImagePlacement> placements;
  final bool cutLine;
}

class PrintSettings {
  bool a5 = false;
  bool landscape = false;
  double margin = 28; // PDF points
  double gap = 14;
  double scale = 1.0;
  LayoutStyle style = LayoutStyle.sideTop;
  bool showCut = false;
  Color accent = const Color(0xFF136C83);
  bool dark = false;
  Size get paper {
    final base = a5 ? const Size(419.53, 595.28) : const Size(595.28, 841.89);
    return landscape ? Size(base.height, base.width) : base;
  }
}

/// One source of positioning for the Flutter preview and both export formats.
/// All positions use PDF points measured from the paper's top-left corner.
List<LayoutSheet> layoutDocument(
  ScanDocument doc,
  PrintSettings settings, {
  Map<int, Offset> freeOffsets = const {},
}) {
  final images = doc.photos;
  if (images.isEmpty) return [];
  final page = settings.paper;
  final m = settings.margin;
  final gap = settings.gap;
  final availableWidth = page.width - 2 * m;
  final availableHeight = page.height - 2 * m;
  final result = <LayoutSheet>[];
  final style = settings.style;

  Size fit(PhotoData image, double maxWidth, double maxHeight) {
    final w = math.max(12.0, maxWidth);
    final h = math.max(12.0, maxHeight);
    final constrainedW = math.min(w, h * image.aspect);
    final constrainedH = constrainedW / image.aspect;
    return Size(constrainedW, constrainedH);
  }

  Rect center(PhotoData image, double maxWidth, double maxHeight,
      {double? anchorX, double? anchorY}) {
    final size = fit(image, maxWidth, maxHeight);
    return Rect.fromLTWH(
      anchorX ?? (page.width - size.width) / 2,
      anchorY ?? (page.height - size.height) / 2,
      size.width,
      size.height,
    );
  }

  if (images.length == 1 ||
      style == LayoutStyle.separate ||
      style == LayoutStyle.single) {
    for (var i = 0; i < images.length; ++i) {
      final r = center(images[i], availableWidth * .83, availableHeight * .56);
      result.add(LayoutSheet([ImagePlacement(images[i], r, i)]));
    }
    return result;
  }

  final first = images[0];
  final second = images[1];
  if (style == LayoutStyle.sideTop || style == LayoutStyle.sideCenter) {
    final cellWidth = math.min(availableWidth / 2 - gap / 2,
        252.0 * settings.scale);
    final cellHeight = availableHeight * .5;
    final a = fit(first, cellWidth, cellHeight);
    final b = fit(second, cellWidth, cellHeight);
    final rowWidth = a.width + gap + b.width;
    final x0 = (page.width - rowWidth) / 2;
    final y0 = style == LayoutStyle.sideTop
        ? m
        : (page.height - math.max(a.height, b.height)) / 2;
    result.add(LayoutSheet([
      ImagePlacement(first, Rect.fromLTWH(x0, y0, a.width, a.height), 0),
      ImagePlacement(second,
          Rect.fromLTWH(x0 + a.width + gap, y0, b.width, b.height), 1),
    ]));
  } else if (style == LayoutStyle.verticalCenter ||
      style == LayoutStyle.stackRight ||
      style == LayoutStyle.stackLeft ||
      style == LayoutStyle.halves) {
    final maxWidth = math.min(availableWidth * .78, 345 * settings.scale);
    final maxHeight = style == LayoutStyle.halves
        ? (availableHeight - gap) / 2 * .82
        : availableHeight * .41;
    final a = fit(first, maxWidth, maxHeight);
    final b = fit(second, maxWidth, maxHeight);
    final top = style == LayoutStyle.verticalCenter
        ? (page.height - a.height - b.height - gap) / 2
        : style == LayoutStyle.halves
            ? m + (availableHeight / 2 - a.height) / 2
            : m;
    final secondTop = style == LayoutStyle.halves
        ? m + availableHeight / 2 + (availableHeight / 2 - b.height) / 2
        : top + a.height + gap;
    double xFor(double width) {
      if (style == LayoutStyle.stackRight) return page.width - m - width;
      if (style == LayoutStyle.stackLeft) return m;
      return (page.width - width) / 2;
    }
    result.add(LayoutSheet([
      ImagePlacement(first, Rect.fromLTWH(xFor(a.width), top, a.width, a.height), 0),
      ImagePlacement(second,
          Rect.fromLTWH(xFor(b.width), secondTop, b.width, b.height), 1),
    ], cutLine: style == LayoutStyle.halves && settings.showCut));
  } else {
    final a = fit(first, availableWidth * .63 * settings.scale,
        availableHeight * .35);
    final b = fit(second, availableWidth * .63 * settings.scale,
        availableHeight * .35);
    Rect free(int index, Size size, Offset fallback) {
      final offset = freeOffsets[index] ?? fallback;
      return Rect.fromLTWH(
        offset.dx.clamp(m, page.width - m - size.width).toDouble(),
        offset.dy.clamp(m, page.height - m - size.height).toDouble(),
        size.width, size.height,
      );
    }
    result.add(LayoutSheet([
      ImagePlacement(first, free(0, a, Offset(m, m)), 0),
      ImagePlacement(second,
          free(1, b, Offset(page.width - m - b.width, m + a.height + gap)), 1),
    ]));
  }
  return result;
}
