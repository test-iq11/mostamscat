#!/usr/bin/env python3
"""Fast source-level regression checks; does not replace flutter analyze."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
code = (root / 'lib/main.dart').read_text(encoding='utf-8')
manifest = (root / 'pubspec.yaml').read_text(encoding='utf-8')
assert 'version: 7.0.1+2' in manifest, 'Wrong project version selected'
assert 'separatorBuilder: (_, _)' not in code, 'Duplicate wildcard parameters'
assert 'identical(extra.original, source)) return;' not in code, 'Missing if braces'
assert "if (mounted) {\n                    ScaffoldMessenger.of(context)" not in code, 'BuildContext async safety regression'
# Ensure the repaired code is present, rather than only checking absence of old text.
assert re.search(r'!identical\(extra\.original, source\)\)\s*\{\s*return;\s*\}', code)
assert 'separatorBuilder: (context, index)' in code
assert "if (context.mounted) {\n                    ScaffoldMessenger.of(context)" in code
for path in ('lib/layouts.dart','lib/perspective.dart','lib/exporters.dart', 'lib/scan_filters.dart', 'test/layouts_test.dart'):
    assert (root/path).is_file(), path
print('V7.0.1 static regression checks passed; run flutter analyze/test next')
