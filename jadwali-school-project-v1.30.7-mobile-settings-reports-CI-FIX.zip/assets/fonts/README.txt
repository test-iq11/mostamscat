Arabic PDF font bundled with the app: Arabic-Regular.ttf (Noto Naskh Arabic Regular).
This font is from the Noto fonts project and is distributed under the SIL Open Font License (OFL).
It is bundled locally so PDF export works offline and does not depend on Android system fonts.
