#!/usr/bin/env python3
"""Deterministic safety/proof checks for Jadwali on a real or anonymized backup.

This is an independent witness validator, NOT the Flutter solver. It never
edits its input. Feasible scenarios reuse a known valid 181-lesson witness;
contradictory scenarios give independently checkable capacity/coverage bounds.
Use Flutter's separate Dart stress tests to exercise the actual search engine.
"""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / 'test/fixtures/backup_school_181.json'


def load(path):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    if 'tables' not in data:
        return {k: list(data.get(k, [])) for k in (
            'sections','requirements','teachers','qualifications','teacherGrades',
            'teacherSubjectGrades','days','slots','subjectBlockedSlots',
            'teacherAvailability','initialPlacements')}
    t = data['tables']
    grades = {x['id']: x for x in t['grades']}
    sections = [dict(x, grade_name=grades[x['grade_id']]['name']) for x in t['sections']]
    reqs = [dict(x) for x in t['section_subject_requirements']]
    for req in reqs:
        section = next(s for s in sections if s['id'] == req['section_id'])
        req['grade_id'] = section['grade_id']
    current = next((v for v in t['timetable_versions'] if v.get('is_active') == 1), None)
    if current is None:
        raise ValueError('No active timetable version in backup')
    version_id = current['id']
    entries = [{key: x.get(key) for key in (
        'section_id','subject_id','teacher_id','day_id','slot_id','room_id')}
        for x in t['timetable_entries'] if x['version_id'] == version_id]
    return {'sections':sections,'requirements':reqs,'teachers':t['teachers'],
            'qualifications':t['teacher_subjects'],'teacherGrades':t['teacher_grades'],
            'teacherSubjectGrades':t['teacher_subject_grades'],
            'days':t['school_days'],'slots':t['time_slots'],
            'subjectBlockedSlots':t['subject_blocked_slots'],
            'teacherAvailability':t['teacher_availability'],
            'initialPlacements':entries}


def verify(inp, extra_unavailability=(), extra_blocks=()):
    entries = inp['initialPlacements']
    teachers = {x['id']:x for x in inp['teachers']}
    sections = {x['id']:x for x in inp['sections']}
    req = {(x['section_id'],x['subject_id']):x for x in inp['requirements']}
    days = sorted([x for x in inp['days'] if x.get('is_active',1)],key=lambda r:(r.get('position',99),r['id']))
    slots = sorted([x for x in inp['slots'] if x.get('kind')=='lesson' and x.get('is_available',1)],key=lambda r:(r.get('position',99),r['id']))
    slot_index = {v['id']:i for i,v in enumerate(slots)}
    active_days = {d['id'] for d in days}
    subject_blocks = {(x['subject_id'],x['slot_id']) for x in [*inp['subjectBlockedSlots'],*extra_blocks]}
    unavail = {(x['teacher_id'],x['day_id'],x['slot_id']) for x in [*inp['teacherAvailability'],*extra_unavailability] if not x.get('is_available',1)}
    eligible = {(x['teacher_id'],x['subject_id']) for x in inp['qualifications']}
    grade_rules = {(x['teacher_id'],x['subject_id'],x['grade_id']) for x in inp['teacherSubjectGrades']}
    demand = Counter()
    for key,r in req.items(): demand[r['section_id']] += r['weekly_lessons']
    errors = []
    cs, ct, sr, sd, td, tw = set(), set(), Counter(),Counter(),Counter(),Counter()
    by_subject_day=Counter()
    by_teacher_day=defaultdict(list)
    for e in entries:
        sec,sub,teacher,day,slot=(e[x] for x in ('section_id','subject_id','teacher_id','day_id','slot_id'))
        if sec not in sections or teacher not in teachers or (sec,sub) not in req or day not in active_days or slot not in slot_index:
            errors.append('unknown element or inactive day/slot'); continue
        s=sections[sec]; r=req[(sec,sub)]
        if (teacher,sub) not in eligible or (grade_rules and (teacher,sub,s['grade_id']) not in grade_rules):
            errors.append('qualification violation')
        if (sub,slot) in subject_blocks: errors.append('forbidden subject period')
        if (teacher,day,slot) in unavail: errors.append('unavailable teacher period')
        if (sec,day,slot) in cs: errors.append('section collision')
        if (teacher,day,slot) in ct: errors.append('teacher collision')
        cs.add((sec,day,slot)); ct.add((teacher,day,slot))
        sr[(sec,sub)]+=1; sd[(sec,day)]+=1; td[(teacher,day)]+=1;tw[teacher]+=1
        by_subject_day[(sec,sub,day)]+=1
        by_teacher_day[(teacher,day)].append(slot_index[slot])
        is_sixth='السادس' in s.get('grade_name','')
        permitted = 7 if is_sixth and day==days[0]['id'] and demand[sec]>6*len(days) else min(6,s.get('max_daily_lessons',6))
        if slot_index[slot]>=permitted: errors.append('grade/day period restriction')
    for (sec,sub),r in req.items():
        if sr[(sec,sub)]!=r['weekly_lessons']: errors.append('weekly requirement mismatch')
        for d in days:
            n=by_subject_day[(sec,sub,d['id'])]
            if r['weekly_lessons']>=5 and not n: errors.append('daily subject coverage')
            limit=r.get('max_daily_lessons',1)
            if not r.get('allow_same_day',0):
                # Sixth grade Arabic (six lessons / five days) has one legal
                # early+late repeat. Other subjects cannot double that way.
                late_repeat=sections[sec].get('grade_name','').startswith('السادس') and r['weekly_lessons']>len(days) and sub==2
                limit=2 if late_repeat else 1
            if n>limit: errors.append('daily subject repeat')
    for (sec,day),n in sd.items():
        s=sections[sec]; is_sixth='السادس' in s.get('grade_name','')
        lim=7 if is_sixth and day==days[0]['id'] and demand[sec]>6*len(days) else min(6,s.get('max_daily_lessons',6))
        if n>lim: errors.append('section daily load')
    for teacher,t in teachers.items():
        if t.get('weekly_load',0)>0 and tw[teacher]>t['weekly_load']: errors.append('teacher weekly load')
        for d in days:
            if t.get('max_daily_lessons',0)>0 and td[(teacher,d['id'])]>t['max_daily_lessons']: errors.append('teacher daily load')
            streak=0; last=-9
            for rank in sorted(by_teacher_day[(teacher,d['id'])]):
                streak=streak+1 if rank==last+1 else 1
                if t.get('max_consecutive_lessons',0)>0 and streak>t['max_consecutive_lessons']: errors.append('teacher consecutive limit')
                last=rank
    return sorted(set(errors))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--backup',default=str(FIXTURE))
    p.add_argument('--output',default='')
    a=p.parse_args(); inp=load(a.backup)
    existing=inp['initialPlacements']
    teachers=[x['id'] for x in inp['teachers']]
    days=[x['id'] for x in inp['days'] if x.get('is_active',1)]
    slots=[x['id'] for x in inp['slots'] if x.get('kind')=='lesson' and x.get('is_available',1)]
    used={(x['teacher_id'],x['day_id'],x['slot_id']) for x in existing}
    unused=sorted((t,d,s) for t in teachers for d in days for s in slots if (t,d,s) not in used)
    subject_ids=sorted({x['subject_id'] for x in inp['requirements']})
    used_subject_slots={(x['subject_id'],x['slot_id']) for x in existing}
    free_subject_pairs=sorted((sub,slot) for sub in subject_ids for slot in slots if (sub,slot) not in used_subject_slots)
    rnd=random.Random(20261027); random_unused=unused[:];rnd.shuffle(random_unused)
    checks=[]
    def one(name,blocked=(),unavailable=(),expected='feasible',bound=None):
        errors=verify(inp,[{'teacher_id':t,'day_id':d,'slot_id':s,'is_available':0} for t,d,s in unavailable],
            [{'subject_id':sub,'slot_id':slot} for sub,slot in blocked])
        if expected=='feasible' and errors: raise AssertionError(name+': '+', '.join(errors))
        if expected=='impossible' and not bound: raise AssertionError('Missing rigorous impossibility proof')
        checks.append({'case':name,'expected':expected,'known_valid_witness':not errors,
            'teacher_unavailable_cells':len(unavailable),'subject_period_bans':len(blocked),
            'witness_violations':errors,'proof':bound or ''})
    one('unchanged_backup')
    for amount in [1,15,35,70,100,len(unused)]:
        one('known_feasible_unavailability_'+str(amount),unavailable=random_unused[:amount])
    one('all_unoccupied_subject_periods',blocked=free_subject_pairs)
    one('combined_maximum_witness_preserving',blocked=free_subject_pairs,unavailable=unused)
    # Certified contradictions: no search-outcome assumptions.
    # 1) Every 5+ lesson subject must cover Tuesday, but no teacher is available.
    day=days[1]
    blocked_day=[(t,day,s) for t in teachers for s in slots]
    one('entire_day_all_teachers_absent',unavailable=blocked_day,expected='impossible',
        bound='Every 5+ lesson requirement needs the selected weekday; union of teacher availability on that day is empty.')
    # 2) Block every period for a mandatory subject: its positive demand has zero slots.
    one('all_subject_periods_blocked',blocked=[(2,s) for s in slots],expected='impossible',
        bound='Arabic requires positive weekly hours; no permitted period remains for any section.')
    # 3) All actual grade-subject qualifications in this backup are singletons.
    # Blocking two entire working days leaves 3*6=18 feasible teacher-4
    # slots (even before consecutive/daily restrictions) for 21 mandatory hours.
    teacher=4
    offdays=days[:2]
    absent=[(teacher,d,s) for d in offdays for s in slots]
    mand=0
    sections={s['id']:s for s in inp['sections']}
    rules={(r['teacher_id'],r['subject_id'],r['grade_id']) for r in inp['teacherSubjectGrades']}
    q={(r['teacher_id'],r['subject_id']) for r in inp['qualifications']}
    for r in inp['requirements']:
        eligible=[t for t in teachers if (t,r['subject_id']) in q and (not rules or (t,r['subject_id'],sections[r['section_id']]['grade_id']) in rules)]
        if eligible==[teacher]: mand+=r['weekly_lessons']
    max_capacity=(len(days)-len(offdays))*min(6,next(t['max_daily_lessons'] for t in inp['teachers'] if t['id']==teacher))
    if mand<=max_capacity: raise AssertionError('teacher capacity stress proof invalid')
    one('mandatory_teacher_out_two_days',unavailable=absent,expected='impossible',
        bound=f'Teacher {teacher} sole-qualified demand {mand} exceeds an optimistic {max_capacity} periods after two entire days blocked.')
    one('combined_impossible_teacher_and_subject',blocked=[(2,s) for s in slots],unavailable=absent,
        expected='impossible',bound='The mandatory subject has zero legal periods; additionally teacher weekly capacity is insufficient.')
    # 500 deterministic combined stress masks at different densities. All
    # forbidden cells are outside the known witness, so these are constructive
    # feasibility certificates rather than unverified solver expectations.
    for index in range(500):
        count = 1 + (index * 37) % len(unused)
        selected = rnd.sample(unused, count)
        ban_count = index % (len(free_subject_pairs) + 1)
        ban_pairs = rnd.sample(free_subject_pairs, ban_count)
        one(f'feasible_random_mixed_{index:03d}',blocked=ban_pairs,
            unavailable=selected)
    # Prove arbitrary subject-global bans impossible for EVERY subject that
    # has positive demand, not just Arabic.
    for sub in subject_ids:
        one(f'impossible_all_periods_subject_{sub}',blocked=[(sub,s) for s in slots],
            expected='impossible',
            bound=f'Subject {sub} has positive demand, but all school period IDs are forbidden.')
    # A full school day with no available teachers prevents daily coverage.
    for d in days:
        day_blocks=[(t,d,s) for t in teachers for s in slots]
        one(f'impossible_all_teachers_absent_day_{d}',unavailable=day_blocks,
            expected='impossible',
            bound=f'At least one 5+ lessons requirement must appear on day {d}, but no teacher is available.')
    # Each teacher is the sole qualified instructor for some assignments in
    # this specific backup. Bound their remaining weekly teaching slots.
    mandatory_by_teacher=Counter()
    for r in inp['requirements']:
        eligible=[t for t in teachers if (t,r['subject_id']) in q and
            (not rules or (t,r['subject_id'],sections[r['section_id']]['grade_id']) in rules)]
        if len(eligible)==1: mandatory_by_teacher[eligible[0]]+=r['weekly_lessons']
    for t in inp['teachers']:
        max_daily=t['max_daily_lessons']
        for first in range(len(days)):
            for second in range(first+1,len(days)):
                for third in range(second+1,len(days)):
                    off={days[first],days[second],days[third]}
                    remaining=(len(days)-len(off))*max_daily
                    required=mandatory_by_teacher[t['id']]
                    if required<=remaining: continue
                    mask=[(t['id'],d,s) for d in off for s in slots]
                    one(f'impossible_teacher_{t["id"]}_absent_{first}_{second}_{third}',
                        unavailable=mask,expected='impossible',
                        bound=f'Mandatory teacher demand {required} exceeds maximum remaining {remaining}.')

    report={'version':'1.16.0','source':'user_backup' if 'tables' in json.loads(Path(a.backup).read_text(encoding='utf-8')) else 'anonymized_fixture',
        'original_backup_unchanged':True,'requested_lessons':sum(x['weekly_lessons'] for x in inp['requirements']),
        'active_schedule_lessons':len(existing),'teachers':len(teachers),'sections':len(inp['sections']),
        'total_teacher_time_cells':len(teachers)*len(days)*len(slots),'unused_teacher_time_cells':len(unused),
        'unused_subject_period_pairs':len(free_subject_pairs),
        'validated_scenarios':len(checks),'feasible_witness_scenarios':sum(x['known_valid_witness'] for x in checks),
        'proven_impossible_scenarios':sum(x['expected']=='impossible' for x in checks),'cases':checks,
        'limitations':'This independently checks one known witness and derives simple impossibility proofs. Flutter search execution is tested separately by Dart tests on GitHub Actions; no APK is built here.'}
    if report['requested_lessons']!=181 or report['active_schedule_lessons']!=181: raise AssertionError('Expected the full 181-lesson school.')
    if a.output: Path(a.output).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"Validated {len(checks)} scenarios on {len(existing)}/{report['requested_lessons']} lesson witness: "+
        f"{report['feasible_witness_scenarios']} feasible, {report['proven_impossible_scenarios']} impossible proofs. "+
        f"Unused teacher cells {len(unused)}, unused subject-slot pairs {len(free_subject_pairs)}.")

if __name__=='__main__': main()
