#!/usr/bin/env python3
"""Provision source project's fonts from the runner's OS font packages.

The distributed source archive intentionally contains no font binaries. On
GitHub Actions install fonts-noto-core before running this script. The original
Flutter font-family names and report asset paths remain intact.
"""
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parents[1]
DEST = HERE / 'assets' / 'fonts'
SYSTEM = Path('/usr/share/fonts/truetype/noto')
MAP = {
    'UI-Regular.ttf': 'NotoSansArabic-Regular.ttf',
    'UI-Bold.ttf': 'NotoSansArabic-Bold.ttf',
    'UI-Latin.ttf': 'NotoSans-Regular.ttf',
    'Arabic-Regular.ttf': 'NotoNaskhArabic-Regular.ttf',
    'Report-Regular.ttf': '../dejavu/DejaVuSans.ttf',
}

def main():
    DEST.mkdir(parents=True, exist_ok=True)
    failures = []
    for local, os_font in MAP.items():
        dst = DEST / local
        if dst.is_file() and dst.stat().st_size > 1000:
            print('Kept existing asset:', local)
            continue
        src = SYSTEM / os_font
        if not src.is_file():
            failures.append(f'{local}: /usr/share/fonts/truetype/noto/{os_font}')
            continue
        shutil.copyfile(src, dst)
        print('Provisioned asset:', local)
    if failures:
        print('::error::Missing OS font files. Install fonts-noto-core:', ', '.join(failures))
        return 1
    return 0

if __name__ == '__main__':
    sys.exit(main())
