import contextlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from prepare_android_ndk import ndk_problem, prepare

VERSION = '28.2.13676358'
FAKE_MANAGER = r'''#!/usr/bin/env python3
import json, os, pathlib, sys
sdk = pathlib.Path(next(a.split('=', 1)[1] for a in sys.argv if a.startswith('--sdk_root=')))
assert sys.argv[-2:] == ['--install', 'ndk;28.2.13676358']
assert os.environ['ANDROID_USER_HOME'] == os.environ['ANDROID_PREFS_ROOT']
state = sdk / 'calls.json'
calls = json.loads(state.read_text()) if state.exists() else []
calls.append(os.environ['ANDROID_USER_HOME']); state.write_text(json.dumps(calls))
ndk = sdk / 'ndk/28.2.13676358'
assert not ndk.exists(), 'partial install must be removed before retry'
assert not (sdk / '.temp').exists(), 'partial download staging must be removed'
ndk.mkdir(parents=True)
(ndk / 'source.properties').write_text('Pkg.Revision = 28.2.13676358\n')
mode = os.environ.get('JADWALI_TEST_MODE', '')
if mode == 'always-fail' or (mode == 'fail-first' and len(calls) == 1):
    (sdk / '.temp').mkdir(); (sdk / '.temp/incomplete.zip').write_bytes(b'bad zip')
    sys.exit(1)
if mode == 'incomplete-first' and len(calls) == 1:
    sys.exit(0)
clang = ndk / 'toolchains/llvm/prebuilt/linux-x86_64/bin/clang'
clang.parent.mkdir(parents=True)
clang.write_text('#!/bin/sh\nprintf "clang test executable\\n"\n'); clang.chmod(0o755)
cmake = ndk / 'build/cmake/android.toolchain.cmake'
cmake.parent.mkdir(parents=True); cmake.write_text('# test toolchain\n')
'''


class NdkPreparationTest(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory(prefix='jadwali-ndk-test-')
        self.addCleanup(self.folder.cleanup)
        self.sdk = Path(self.folder.name) / 'sdk'
        manager = self.sdk / 'cmdline-tools/latest/bin/sdkmanager'
        manager.parent.mkdir(parents=True)
        manager.write_text(FAKE_MANAGER); manager.chmod(0o755)
        self.work = Path(self.folder.name) / 'work'
        self.output = io.StringIO()

    def install(self, mode=''):
        with patch.dict(os.environ, {'JADWALI_TEST_MODE': mode}), contextlib.redirect_stdout(self.output):
            prepare(self.sdk, VERSION, self.work)

    def calls(self):
        return json.loads((self.sdk / 'calls.json').read_text())

    def test_corrupt_download_retries_with_fresh_cache_and_validates_toolchain(self):
        self.install('fail-first')
        self.assertEqual(len(self.calls()), 2)
        self.assertNotEqual(*self.calls())
        self.assertIsNone(ndk_problem(self.sdk / 'ndk' / VERSION, VERSION))

    def test_success_exit_with_incomplete_ndk_still_retries(self):
        self.install('incomplete-first')
        self.assertEqual(len(self.calls()), 2)
        self.assertIn('clang executable is missing', self.output.getvalue())

    def test_valid_existing_ndk_is_reused_without_download(self):
        self.install()
        self.install('always-fail')
        self.assertEqual(len(self.calls()), 1)
        self.assertIn('Verified existing NDK', self.output.getvalue())

    def test_failure_after_three_attempts_removes_partial_target_only(self):
        other = self.sdk / 'ndk/other-version/keep.txt'
        other.parent.mkdir(parents=True); other.write_text('keep')
        with self.assertRaisesRegex(RuntimeError, 'after 3 attempts'):
            self.install('always-fail')
        self.assertEqual(len(self.calls()), 3)
        self.assertFalse((self.sdk / 'ndk' / VERSION).exists())
        self.assertEqual(other.read_text(), 'keep')

    def test_wrong_version_is_replaced(self):
        target = self.sdk / 'ndk' / VERSION
        target.mkdir(parents=True); (target / 'source.properties').write_text('Pkg.Revision = 1.0.0\n')
        self.install()
        self.assertIsNone(ndk_problem(target, VERSION))

    def test_clang_that_cannot_execute_is_replaced(self):
        self.install()
        clang = self.sdk / 'ndk' / VERSION / 'toolchains/llvm/prebuilt/linux-x86_64/bin/clang'
        clang.write_text('#!/bin/sh\nexit 1\n')
        self.install()
        self.assertEqual(len(self.calls()), 2)
        self.assertIsNone(ndk_problem(self.sdk / 'ndk' / VERSION, VERSION))

    def test_invalid_version_cannot_delete_another_directory(self):
        with self.assertRaises(ValueError):
            prepare(self.sdk, '../../outside', self.work)
        self.assertTrue((self.sdk / 'cmdline-tools/latest/bin/sdkmanager').exists())


if __name__ == '__main__':
    unittest.main()
