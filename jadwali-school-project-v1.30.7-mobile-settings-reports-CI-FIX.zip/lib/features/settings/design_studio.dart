import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../core/design_style.dart';
import '../../core/interface_settings.dart';
import '../../core/school_hero.dart';
import '../../core/ui_helpers.dart';
import '../../data/database_service.dart';
import '../../services/design_export_service.dart';
import '../../services/file_save_service.dart';

Future<void> showDesignStudio(BuildContext context, {String? schoolName}) =>
    showDialog<void>(
      context: context,
      barrierColor: MediaQuery.sizeOf(context).width > 900
          ? Colors.transparent
          : Colors.black26,
      builder: (_) => DesignStudio(schoolName: schoolName),
    );

class DesignStudio extends StatefulWidget {
  const DesignStudio({super.key, this.schoolName});
  final String? schoolName;
  @override
  State<DesignStudio> createState() => _DesignStudioState();
}

class _DesignStudioState extends State<DesignStudio> {
  final ui = InterfaceSettings.instance;
  late final DesignStyle previous = ui.design;
  late final TextEditingController name = TextEditingController(
    text: widget.schoolName ?? '',
  );
  final scroll = ScrollController();
  bool busy = false;
  @override
  void initState() {
    super.initState();
    if (widget.schoolName == null) _loadName();
  }

  Future<void> _loadName() async {
    try {
      final settings = await DatabaseService.instance.getSettings();
      if (mounted && name.text.isEmpty)
        setState(() => name.text = '${settings['school_name'] ?? 'المدرسة'}');
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر تحميل اسم المدرسة: $e');
    }
  }

  Future<void> _saveName() async {
    final text = name.text.trim();
    if (text.isEmpty) {
      showMessage(context, 'أدخل اسم المدرسة.');
      return;
    }
    try {
      await DatabaseService.instance.saveSettings({'school_name': text});
      if (mounted) showMessage(context, 'حُفظ اسم المدرسة.');
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر حفظ الاسم: $e');
    }
  }

  void change(String key, Object value) {
    ui.design = ui.design.change(key, value);
    ui.save();
  }

  Future<void> exportDesign(bool html) async {
    setState(() => busy = true);
    try {
      final content = html
          ? await DesignExportService.html(
              design: ui.design,
              schoolName: name.text,
              dark: ui.dark,
              fontScale: ui.fontScale,
            )
          : DesignExportService.encode(ui.design);
      final path = await FileSaveService().saveBytes(
        dialogTitle: html ? 'حفظ معاينة التصميم' : 'تصدير الألوان',
        fileName: html ? 'jadwali-my-design.html' : 'jadwali-colors.json',
        allowedExtensions: [html ? 'html' : 'json'],
        bytes: Uint8List.fromList(utf8.encode(content)),
      );
      if (mounted && path != null)
        showMessage(
          context,
          html
              ? 'حُفظ HTML بمظهرك؛ بيانات الجدول داخله تجريبية.'
              : 'حُفظ ملف الألوان.',
        );
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر التصدير: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> importColors() async {
    setState(() => busy = true);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
        withData: true,
      );
      if (result == null) return;
      final file = result.files.single;
      if (file.size > 20000)
        throw const FormatException('الملف أكبر من ملف ألوان متوقع.');
      final bytes = file.bytes ?? await File(file.path!).readAsBytes();
      final design = DesignExportService.decode(utf8.decode(bytes));
      ui.design = design;
      await ui.save();
      if (mounted) showMessage(context, 'استُوردت الألوان من ملف التصميم.');
    } catch (e) {
      if (mounted) showMessage(context, 'تعذر استيراد الألوان: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget title(String text) => Padding(
    padding: const EdgeInsets.only(top: 22, bottom: 10),
    child: Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
    ),
  );
  Widget slider(
    String key,
    String label,
    double value,
    double min,
    double max,
    int divisions,
  ) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const SizedBox(height: 12),
      Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 12))),
          Text('${value.round()}', style: const TextStyle(fontSize: 11)),
        ],
      ),
      Slider(
        key: ValueKey('design-$key'),
        value: value,
        min: min,
        max: max,
        divisions: divisions,
        label: '${value.round()}',
        onChanged: (v) => change(key, v),
      ),
    ],
  );
  Widget segments(String key, String value, List<(String, String)> options) =>
      Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final o in options)
            ChoiceChip(
              key: ValueKey('design-$key-${o.$1}'),
              label: Text(o.$2, style: const TextStyle(fontSize: 11)),
              selected: value == o.$1,
              onSelected: (_) => change(key, o.$1),
            ),
        ],
      );
  Widget color(String key, String label, Color value) => ListTile(
    contentPadding: EdgeInsets.zero,
    title: Text(label, style: const TextStyle(fontSize: 12)),
    trailing: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          DesignStyle.hex(value),
          textDirection: TextDirection.ltr,
          style: const TextStyle(fontSize: 10),
        ),
        const SizedBox(width: 8),
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: value,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Theme.of(context).dividerColor),
          ),
        ),
      ],
    ),
    onTap: () => _pickColor(key, label, value),
    key: ValueKey('design-color-$key'),
  );
  Future<void> _pickColor(String key, String label, Color value) async {
    final result = await showDialog<Color>(
      context: context,
      builder: (_) => _ColorDialog(title: label, color: value),
    );
    if (result != null) change(key, DesignStyle.hex(result));
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: ui,
    builder: (context, _) {
      final d = ui.design;
      return Dialog(
        alignment: MediaQuery.sizeOf(context).width > 900
            ? Alignment.centerLeft
            : Alignment.center,
        insetPadding: const EdgeInsets.all(10),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 390, maxHeight: 940),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 12, 8),
                child: Row(
                  children: [
                    const Icon(Icons.tune),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text(
                        'استوديو المظهر',
                        style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    IconButton(
                      key: const ValueKey('close-design-studio'),
                      tooltip: 'إغلاق التخصيص',
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SchoolHero(
                  key: const ValueKey('design-live-preview'),
                  design: d,
                  name: name.text,
                  preview: true,
                ),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: ListView(
                  key: const ValueKey('design-studio-scroll'),
                  controller: scroll,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: [
                    const Text(
                      'غيّر التفاصيل وشاهد النتيجة مباشرة.',
                      style: TextStyle(fontSize: 11),
                    ),
                    title('اسم المدرسة على البطاقة'),
                    TextField(
                      controller: name,
                      maxLength: 60,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        labelText: 'اسم المدرسة',
                        suffixIcon: IconButton(
                          tooltip: 'حفظ اسم المدرسة',
                          onPressed: _saveName,
                          icon: const Icon(Icons.check),
                        ),
                      ),
                    ),
                    title('ابدأ بثيم جاهز'),
                    LayoutBuilder(
                      builder: (context, c) => Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (var i = 0; i < DesignStyle.presets.length; i++)
                            SizedBox(
                              width: (c.maxWidth - 24) / 4,
                              child: InkWell(
                                key: ValueKey('design-preset-$i'),
                                onTap: () {
                                  ui.design = d.preset(i);
                                  ui.save();
                                },
                                borderRadius: BorderRadius.circular(13),
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(13),
                                    border: Border.all(
                                      color:
                                          d.a ==
                                              DesignStyle.parseColor(
                                                DesignStyle.presets[i].$3,
                                              )
                                          ? Theme.of(context)
                                                .colorScheme
                                                .primary
                                          : Theme.of(context).dividerColor,
                                    ),
                                  ),
                                  child: Column(
                                    children: [
                                      Container(
                                        height: 28,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(
                                            9,
                                          ),
                                          gradient: LinearGradient(
                                            colors: [
                                              DesignStyle.parseColor(
                                                DesignStyle.presets[i].$3,
                                              )!,
                                              DesignStyle.parseColor(
                                                DesignStyle.presets[i].$4,
                                              )!,
                                            ],
                                          ),
                                        ),
                                      ),
                                      Text(
                                        DesignStyle.presets[i].$1,
                                        style: const TextStyle(fontSize: 10),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    title('ألوانك الخاصة'),
                    color('accent', 'لون الأزرار والأيقونات', d.accent),
                    color('background', 'خلفية التطبيق — نهاري', d.background),
                    title('بطاقة المدرسة'),
                    segments('mode', d.mode, const [
                      ('gradient', 'تدرّج لوني'),
                      ('solid', 'لون واحد'),
                    ]),
                    color('a', 'لون البطاقة الأساسي', d.a),
                    color('b', 'لون نهاية التدرّج', d.b),
                    slider('angle', 'اتجاه التدرّج', d.angle, 0, 360, 72),
                    slider('radius', 'استدارة البطاقة', d.radius, 0, 48, 24),
                    title('لمسة على البطاقة'),
                    segments('pattern', d.pattern, const [
                      ('rings', 'دوائر'),
                      ('dots', 'نقاط'),
                      ('lines', 'خطوط'),
                      ('none', 'بسيطة'),
                    ]),
                    slider('texture', 'وضوح الزخرفة', d.texture, 0, 30, 30),
                    slider('shadow', 'عمق الظل', d.shadow, 0, 30, 30),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'حماية وضوح النص تلقائياً',
                        style: TextStyle(fontSize: 12),
                      ),
                      value: d.safe,
                      onChanged: (v) => change('safe', v),
                    ),
                    Text(
                      !d.safe
                          ? 'حماية وضوح النص متوقفة.'
                          : d.heroColors.$4
                          ? 'عُدّل سطوع الخلفية للحفاظ على قراءة النص.'
                          : 'ألوان البطاقة مناسبة لوضوح النص.',
                      style: const TextStyle(fontSize: 10),
                    ),
                    title('تفاصيل التطبيق'),
                    slider('round', 'حواف البطاقات', d.round, 8, 32, 12),
                    slider(
                      'density',
                      'المسافات الداخلية',
                      d.density,
                      85,
                      115,
                      6,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'حجم الخط · ${(ui.fontScale * 100).round()}%',
                      style: const TextStyle(fontSize: 12),
                    ),
                    Slider(
                      key: const ValueKey('design-font'),
                      value: ui.fontScale.clamp(.85, 1.3),
                      min: .85,
                      max: 1.3,
                      divisions: 9,
                      onChanged: (v) {
                        ui.fontScale = v;
                        ui.save();
                      },
                    ),
                    SwitchListTile(
                      key: const ValueKey('design-dark'),
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'الوضع الليلي',
                        style: TextStyle(fontSize: 12),
                      ),
                      value: ui.dark,
                      onChanged: (v) {
                        ui.dark = v;
                        ui.save();
                      },
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'حركات هادئة',
                        style: TextStyle(fontSize: 12),
                      ),
                      value: d.motion,
                      onChanged: (v) => change('motion', v),
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                        'وضع التركيز — تفاصيل أقل',
                        style: TextStyle(fontSize: 12),
                      ),
                      value: d.focus,
                      onChanged: (v) => change('focus', v),
                    ),
                    const Text(
                      'تُحفظ تفضيلات المظهر على الجهاز تلقائياً. اسم المدرسة يتطلب زر الحفظ. ألوان التقارير مستقلة عن ألوان الواجهة.',
                      style: TextStyle(fontSize: 10),
                    ),
                    Wrap(
                      spacing: 8,
                      children: [
                        TextButton(
                          onPressed: () {
                            ui.design = previous;
                            ui.save();
                          },
                          child: const Text('تراجع عن التخصيص'),
                        ),
                        TextButton(
                          key: const ValueKey('design-reset'),
                          onPressed: () {
                            ui.design = const DesignStyle();
                            ui.save();
                          },
                          child: const Text('المظهر الافتراضي'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 15),
                  ],
                ),
              ),
              const Divider(),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  alignment: WrapAlignment.center,
                  children: [
                    FilledButton(
                      onPressed: busy ? null : () => exportDesign(true),
                      child: const Text(
                        'تنزيل HTML',
                        style: TextStyle(fontSize: 11),
                      ),
                    ),
                    OutlinedButton(
                      onPressed: busy ? null : () => exportDesign(false),
                      child: const Text(
                        'تصدير الألوان',
                        style: TextStyle(fontSize: 11),
                      ),
                    ),
                    TextButton(
                      onPressed: busy ? null : importColors,
                      child: const Text(
                        'استيراد',
                        style: TextStyle(fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
  @override
  void dispose() {
    name.dispose();
    scroll.dispose();
    super.dispose();
  }
}

class _ColorDialog extends StatefulWidget {
  const _ColorDialog({required this.title, required this.color});
  final String title;
  final Color color;
  @override
  State<_ColorDialog> createState() => _ColorDialogState();
}

class _ColorDialogState extends State<_ColorDialog> {
  late HSVColor hsv = HSVColor.fromColor(widget.color);
  late final hex = TextEditingController(text: DesignStyle.hex(widget.color));
  String? error;
  void update(HSVColor value) {
    setState(() {
      hsv = value;
      hex.text = DesignStyle.hex(value.toColor());
      error = null;
    });
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.title),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 65,
            width: 280,
            decoration: BoxDecoration(
              color: hsv.toColor(),
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          const SizedBox(height: 15),
          TextField(
            key: const ValueKey('design-color-hex'),
            controller: hex,
            textDirection: TextDirection.ltr,
            decoration: InputDecoration(
              labelText: 'HEX',
              hintText: '#24776d',
              errorText: error,
            ),
            onChanged: (text) {
              final c = DesignStyle.parseColor(text);
              setState(() {
                error = c == null ? 'اكتب # ثم ست خانات لونية' : null;
                if (c != null) hsv = HSVColor.fromColor(c);
              });
            },
          ),
          const Text('درجة اللون'),
          Slider(
            value: hsv.hue,
            min: 0,
            max: 360,
            onChanged: (v) => update(hsv.withHue(v)),
          ),
          const Text('التشبّع'),
          Slider(
            value: hsv.saturation,
            onChanged: (v) => update(hsv.withSaturation(v)),
          ),
          const Text('السطوع'),
          Slider(value: hsv.value, onChanged: (v) => update(hsv.withValue(v))),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(
        key: const ValueKey('design-color-apply'),
        onPressed: error == null
            ? () => Navigator.pop(context, hsv.toColor())
            : null,
        child: const Text('تطبيق اللون'),
      ),
    ],
  );
  @override
  void dispose() {
    hex.dispose();
    super.dispose();
  }
}
