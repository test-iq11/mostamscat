import 'package:flutter/material.dart';

import '../../data/database_service.dart';
import '../../services/preflight_inspection_service.dart';
import '../../services/constraint_explanation_service.dart';

class ReadinessCard extends StatefulWidget {
  const ReadinessCard({super.key, required this.onNavigate});
  final ValueChanged<int> onNavigate;
  @override
  State<ReadinessCard> createState() => _ReadinessCardState();
}

class _ReadinessCardState extends State<ReadinessCard> {
  late final Future<List<(String, String, int, bool)>> _future = _load();
  Future<List<(String, String, int, bool)>> _load() async {
    final db = DatabaseService.instance;
    final version = await db.activeVersionId(await db.activeYearId());
    final input = <String, Object?>{
      'sections': await db.sectionsDetailed(),
      'requirements': await db.requirementsDetailed(),
      'teachers': await db.rows('teachers'),
      'subjects': await db.rows('subjects'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'days': await db.rows('school_days'),
      'slots': await db.rows('time_slots'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'teacherAvailability': await db.rows('teacher_availability'),
      'initialPlacements': await db.entriesDetailed(versionId: version),
    };
    List<Map<String, Object?>> rows(String k) =>
        (input[k] as List).cast<Map<String, Object?>>();
    input['lockedPlacements'] = rows('initialPlacements')
        .where((e) => e['is_locked'] == 1)
        .toList();
    final check = const PreflightInspectionService().inspect(
      sections: rows('sections'),
      requirements: rows('requirements'),
      teachers: rows('teachers'),
      subjects: rows('subjects'),
      qualifications: rows('qualifications'),
      teacherGrades: rows('teacherGrades'),
      teacherSubjectGrades: rows('teacherSubjectGrades'),
      days: rows('days'),
      slots: rows('slots'),
      currentEntries: rows('initialPlacements'),
      availability: rows('teacherAvailability'),
      subjectBlockedSlots: rows('subjectBlockedSlots'),
    );
    int route(String code) {
      if (code.contains('availability')) return 5;
      if (code.contains('teacher') || code.contains('qualification')) return 2;
      if (code.contains('blocked') || code.contains('subject_slot')) return 4;
      if (code.contains('requirement') ||
          code.contains('demand') ||
          code.contains('coverage'))
        return 3;
      if (code.contains('lock') || code.contains('pin')) return 1;
      return 12;
    }

    final result = <(String, String, int, bool)>[
      for (final finding in check.findings)
        (
          finding.title,
          '${finding.message}\n${finding.recommendation}',
          route(finding.code),
          finding.blocking,
        ),
      for (final proof
          in const ConstraintExplanationService()
              .explain(input)
              .where((p) => p.proven))
        (
          proof.title,
          '${proof.reason}\n${proof.suggestions.join('\n')}',
          route(proof.code),
          true,
        ),
    ];
    for (final section in rows('sections')) {
      if (!rows('requirements').any(
        (r) =>
            r['section_id'] == section['id'] &&
            (r['weekly_lessons'] as num? ?? 0) > 0,
      )) {
        result.add((
          'صف بلا حصص مطلوبة',
          '${section['grade_name'] ?? ''} ${section['name'] ?? ''}: حدد المواد وأعداد حصصها.',
          3,
          true,
        ));
      }
    }
    return result;
  }

  @override
  Widget build(BuildContext context) =>
      FutureBuilder<List<(String, String, int, bool)>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasError)
            return const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'تعذر فحص الجاهزية. أعد فتح إعداد الجدول للمحاولة.',
                ),
              ),
            );
          if (!snapshot.hasData)
            return const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Center(child: CircularProgressIndicator()),
              ),
            );
          final items = snapshot.data!;
          final blockers = items.where((i) => i.$4).length;
          return Card(
            child: ExpansionTile(
              key: const ValueKey('setup-readiness'),
              leading: Icon(
                blockers > 0
                    ? Icons.assignment_late_outlined
                    : Icons.fact_check_outlined,
              ),
              title: Text(
                blockers > 0
                    ? 'جاهزية البيانات: $blockers ملاحظات مانعة'
                    : 'فحص الجاهزية: لا عوائق مؤكدة',
              ),
              subtitle: Text(
                items.isEmpty
                    ? 'ابدأ البحث؛ الفحص الأولي لا يضمن وجود حل.'
                    : '${items.length} ملاحظات · افتح للتفاصيل والإصلاح',
              ),
              children: [
                for (final item in items)
                  ListTile(
                    title: Text(item.$1),
                    subtitle: Text(item.$2),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => widget.onNavigate(item.$3),
                  ),
              ],
            ),
          );
        },
      );
}
