import 'package:flutter/material.dart';
import '../../data/database_service.dart';
import '../../services/minimal_change_repair_service.dart';
import '../../services/repair_history_service.dart';

/// An explicit, versioned undo. The source is an archived timetable, not a
/// reverse patch applied to the live rows. Save checks the active version and
/// all its rows again inside one transaction before creating a new version.
Future<bool> showRepairUndoDialog({
  required BuildContext context,
  required Map<String, Object?> data,
}) async {
  final currentVersion = Map<String, Object?>.from(data['version'] as Map);
  final sourceId = const RepairHistoryService()
      .sourceVersionId(currentVersion['notes']);
  if (sourceId == null) return false;

  final db = DatabaseService.instance;
  final yearId = data['yearId'] as int?;
  final versionId = data['versionId'] as int?;
  if (yearId == null || versionId == null) return false;
  final sources = await db.rows('timetable_versions');
  final source = sources.where((row) =>
      row['id'] == sourceId && row['academic_year_id'] == yearId).firstOrNull;
  if (source == null) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('النسخة الأصلية للإصلاح غير موجودة في الأرشيف.')));
    }
    return false;
  }
  final stored = await (await db.database).query('timetable_entries',
      where: 'version_id=?', whereArgs: [sourceId], orderBy: 'id');
  final current = MinimalChangeRepairService.rows(data, 'entries');
  final preview = <Map<String, Object?>>[
    for (final row in stored) Map<String, Object?>.from(row),
  ];
  const scanner = MinimalChangeRepairService();
  final restoreIssues = scanner.scan(data, preview)
      .where((issue) => issue.severity == 'خطأ مانع').length;
  final nowIssues = scanner.scan(data, current)
      .where((issue) => issue.severity == 'خطأ مانع').length;
  // Do not undo into a different pinned-cell arrangement.
  const sameKeys = ['section_id', 'subject_id', 'teacher_id', 'room_id',
    'day_id', 'slot_id'];
  final pinsSafe = current.where((row) =>
      MinimalChangeRepairService.n(row['is_locked']) == 1).every((pinned) =>
    preview.any((row) => sameKeys.every((key) => pinned[key] == row[key])));
  if (!context.mounted) return false;
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('معاينة التراجع عن آخر إصلاح'),
      content: SingleChildScrollView(child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('ستُستعاد حصص النسخة «${source['name']}» كنسخة جديدة. '
              'ستظل النسختان الحالية والأصلية محفوظتين في الأرشيف.'),
          const SizedBox(height: 8),
          Text('حصص النسخة الأصلية: ${preview.length} · '
              'الحصص الحالية: ${current.length}'),
          Text('الأخطاء المانعة حاليًا: $nowIssues · '
              'بعد الاستعادة وفق الشروط الحالية: $restoreIssues'),
          if (restoreIssues > nowIssues) const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('تنبيه: الاستعادة قد تعيد أخطاء كانت قد أُصلحت. '
                'راجع الشروط قبل الاعتماد.',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          if (!pinsSafe) const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('لا يمكن التراجع لأن إحدى الحصص المقفلة '
                'ستتغير؛ افتح قفلها أولًا.',
                style: TextStyle(color: Colors.red)),
          ),
          const SizedBox(height: 8),
          const Text('لن يتغير شيء حتى تضغط «تأكيد التراجع». '
              'ستُراجع النسخة النشطة مرة أخرى وقت الحفظ.'),
        ],
      )),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء')),
        FilledButton(onPressed: pinsSafe
            ? () => Navigator.pop(dialogContext, true) : null,
            child: const Text('تأكيد التراجع كنسخة جديدة')),
      ],
    ),
  );
  if (confirmed != true) return false;
  final stripped = <Map<String, Object?>>[
    for (final row in preview)
      {
        for (final key in const [
          'section_id', 'subject_id', 'teacher_id', 'room_id', 'day_id',
          'slot_id', 'is_locked', 'grade_id', 'grade_name',
        ]) if (row.containsKey(key)) key: row[key],
      },
  ];
  await db.saveAsNewVersion(
    yearId: yearId,
    name: 'تراجع عن إصلاح: ${source['name']}',
    entries: stripped,
    activate: true,
    expectedActiveVersionId: versionId,
    expectedOriginalEntries: current,
    notes: 'تراجع يدوي بعد معاينة المستخدم إلى النسخة المحفوظة $sourceId '
        'من دون حذف أو تعديل النسخ السابقة.',
  );
  return true;
}
