import 'package:flutter/material.dart';

/// The content fits inside a scaled cell; tools have their own reserved space.
class WeeklyLessonContent extends StatelessWidget {
  const WeeklyLessonContent({
    super.key,
    required this.subject,
    required this.teacher,
    required this.time,
    required this.color,
  });
  final String subject, teacher, time;
  final Color color;
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final showTime = box.maxHeight >= 140;
      return Padding(
        padding: const EdgeInsets.fromLTRB(8, 32, 8, 25),
        child: Tooltip(
          message: '$subject\n$teacher\n$time',
          triggerMode: TooltipTriggerMode.manual,
          child: Center(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: SizedBox(
                width: (box.maxWidth - 16).clamp(1, double.infinity),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      subject,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: color,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      teacher,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 11, color: color),
                    ),
                    if (showTime)
                      Text(
                        time,
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 9,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    },
  );
}
