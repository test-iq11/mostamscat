import 'package:flutter/material.dart';

import '../../data/database_service.dart';
import '../../services/conflict_detection_service.dart';

/// One actionable, data-backed in-app notice. This is NOT an Android push
/// notification: the bell checks the saved school data each time it is opened.
class JadwaliNotice {
  const JadwaliNotice({
    required this.title,
    required this.message,
    required this.destination,
    required this.icon,
    required this.severity,
  });

  final String title;
  final String message;
  final int destination;
  final IconData icon;
  final String severity;
}

class JadwaliNotificationData {
  const JadwaliNotificationData(this.items, this.blockers, this.warnings);

  final List<JadwaliNotice> items;
  final int blockers;
  final int warnings;

  /// The status is derived entirely from the saved school summary and the
  /// same conflict detector used by the Conflicts screen.
  static JadwaliNotificationData fromCurrentStatus({
    required Map<String, Object?> summary,
    required bool hasActiveTimetable,
    required List<ConflictIssue> issues,
  }) {
    final items = <JadwaliNotice>[];
    final requiredLessons = (summary['الحصص المطلوبة'] as num?)?.toInt() ?? 0;
    final unplaced = (summary['الحصص المتبقية'] as num?)?.toInt() ?? 0;
    if (requiredLessons <= 0) {
      items.add(const JadwaliNotice(
        title: 'الحصص المطلوبة غير مكتملة',
        message: 'أدخل عدد حصص المواد لكل صف من إعداد الجدول.',
        destination: 13,
        icon: Icons.school_outlined,
        severity: 'تهيئة',
      ));
    } else if (!hasActiveTimetable) {
      items.add(const JadwaliNotice(
        title: 'لم يُنشأ جدول معتمد بعد',
        message: 'افتح التوزيع والحلول لإنشاء جدول ومراجعته.',
        destination: 7,
        icon: Icons.calendar_month_outlined,
        severity: 'تنبيه',
      ));
    } else if (unplaced > 0) {
      items.add(JadwaliNotice(
        title: '$unplaced حصة لم تُوزع بعد',
        message: 'من أصل $requiredLessons حصة مطلوبة. راجع التوزيع والقيود.',
        destination: 7,
        icon: Icons.event_busy_outlined,
        severity: 'تنبيه',
      ));
    }

    final blockers = issues.where((i) => i.severity == 'خطأ مانع').toList();
    final warnings = issues.where((i) => i.severity == 'تحذير').toList();
    // A short digest, not a fictitious issue count. Full details remain in
    // the dedicated conflict screen. The list is freshly generated on open.
    for (final issue in blockers.take(4)) {
      items.add(JadwaliNotice(
        title: issue.type,
        message: issue.message,
        destination: 6,
        icon: Icons.error_outline,
        severity: 'خطأ مانع',
      ));
    }
    for (final issue in warnings.take(3)) {
      items.add(JadwaliNotice(
        title: issue.type,
        message: issue.message,
        destination: 6,
        icon: Icons.warning_amber_outlined,
        severity: 'تحذير',
      ));
    }
    if (items.isEmpty) {
      items.add(JadwaliNotice(
        title: hasActiveTimetable ? 'لا توجد تنبيهات حرجة في الفحص الحالي' : 'البيانات تحتاج إلى الإعداد',
        message: hasActiveTimetable
            ? 'آخر فحص لم يرصد تعارضات مانعة أو حصصًا ناقصة. يمكنك فتح فحص التعارضات للمراجعة التفصيلية.'
            : 'أكمل بيانات المدرسة والحصص المطلوبة أولًا.',
        destination: hasActiveTimetable ? 6 : 13,
        icon: Icons.check_circle_outline,
        severity: 'معلومة',
      ));
    }
    return JadwaliNotificationData(items, blockers.length, warnings.length);
  }
}

class JadwaliNotificationRepository {
  const JadwaliNotificationRepository();

  Future<JadwaliNotificationData> load() async {
    final db = DatabaseService.instance;
    final summary = await db.summary();
    final yearId = await db.activeYearId();
    final versionId = await db.activeVersionId(yearId);
    if (versionId == null) {
      return JadwaliNotificationData.fromCurrentStatus(
        summary: summary, hasActiveTimetable: false, issues: const [],
      );
    }
    final issues = const ConflictDetectionService().scan(
      entries: await db.entriesDetailed(versionId: versionId),
      sections: await db.sectionsDetailed(),
      requirements: await db.requirementsDetailed(),
      slots: await db.rows('time_slots'),
      teachers: await db.rows('teachers'),
      qualifications: await db.rows('teacher_subjects'),
      days: await db.rows('school_days'),
      teacherGrades: await db.rows('teacher_grades'),
      teacherSubjectGrades: await db.rows('teacher_subject_grades'),
      subjectBlockedSlots: await db.rows('subject_blocked_slots'),
      teacherAvailability: await db.rows('teacher_availability'),
    );
    return JadwaliNotificationData.fromCurrentStatus(
      summary: summary, hasActiveTimetable: true, issues: issues,
    );
  }
}

/// Top-anchored overlay like the approved HTML bell panel; does not replace
/// system notifications, install background timers or modify school data.
class JadwaliNotificationPanel extends StatefulWidget {
  const JadwaliNotificationPanel({
    required this.onNavigate,
    this.repository = const JadwaliNotificationRepository(),
    super.key,
  });

  final ValueChanged<int> onNavigate;
  final JadwaliNotificationRepository repository;

  @override
  State<JadwaliNotificationPanel> createState() => _JadwaliNotificationPanelState();
}

class _JadwaliNotificationPanelState extends State<JadwaliNotificationPanel> {
  late Future<JadwaliNotificationData> _result;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() => _result = widget.repository.load();

  void _go(int destination) {
    Navigator.of(context).pop();
    widget.onNavigate(destination);
  }

  Color _tone(ColorScheme scheme, String severity) => switch (severity) {
    'خطأ مانع' => scheme.error,
    'تحذير' || 'تنبيه' => const Color(0xffb9782c),
    'تهيئة' => scheme.primary,
    _ => const Color(0xff168d7c),
  };

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final height = MediaQuery.sizeOf(context).height;
    final top = MediaQuery.paddingOf(context).top;
    return Dialog(
      alignment: Alignment.topCenter,
      insetPadding: EdgeInsets.fromLTRB(10, top + 54, 10, 12),
      backgroundColor: scheme.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 455, maxHeight: (height - top - 78).clamp(250.0, 690.0).toDouble()),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(children: [
              Icon(Icons.notifications_active_outlined, color: scheme.primary),
              const SizedBox(width: 9),
              const Expanded(child: Text('تنبيهات جدولي',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              IconButton(
                key: const ValueKey('notification-refresh'),
                tooltip: 'تحديث التنبيهات',
                onPressed: () => setState(_refresh),
                icon: const Icon(Icons.refresh),
              ),
              IconButton(tooltip: 'إغلاق', onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close)),
            ]),
          ),
          Divider(height: 1, color: scheme.outlineVariant),
          Flexible(child: FutureBuilder<JadwaliNotificationData>(
            future: _result,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Padding(padding: const EdgeInsets.all(18), child: Column(
                  mainAxisSize: MainAxisSize.min, children: [
                    Text('تعذّر فحص التنبيهات: ${snapshot.error}',
                      style: TextStyle(color: scheme.error)),
                    const SizedBox(height: 12),
                    OutlinedButton(onPressed: () => _go(6),
                      child: const Text('فتح فحص التعارضات')),
                  ],
                ));
              }
              if (!snapshot.hasData) {
                return const Center(child: Padding(padding: EdgeInsets.all(28),
                  child: CircularProgressIndicator()));
              }
              final result = snapshot.data!;
              return ListView(
                key: const ValueKey('live-notification-list'),
                shrinkWrap: true,
                padding: const EdgeInsets.all(12),
                children: [
                  Padding(padding: const EdgeInsets.fromLTRB(7, 0, 7, 12),
                    child: Text('فحص مباشر لبيانات المدرسة · ${result.blockers} أخطاء مانعة · ${result.warnings} تحذيرات',
                      style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant))),
                  for (final item in result.items)
                    Padding(padding: const EdgeInsets.only(bottom: 8), child: Material(
                      color: scheme.surfaceContainerLow,
                      borderRadius: BorderRadius.circular(15),
                      child: InkWell(
                        onTap: () => _go(item.destination),
                        borderRadius: BorderRadius.circular(15),
                        child: Padding(padding: const EdgeInsets.all(13), child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(item.icon, color: _tone(scheme, item.severity), size: 22),
                            const SizedBox(width: 10),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.title, style: TextStyle(color: scheme.onSurface,
                                  fontSize: 13, fontWeight: FontWeight.w800)),
                                const SizedBox(height: 3),
                                Text(item.message, maxLines: 4, overflow: TextOverflow.ellipsis,
                                  style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 11)),
                              ])),
                            Icon(Icons.chevron_left, color: scheme.onSurfaceVariant, size: 18),
                          ],
                        )),
                      ),
                    )),
                  const SizedBox(height: 5),
                  Text('التنبيهات تظهر داخل التطبيق عند فتح الجرس؛ ليست إشعارات دفع من Android.',
                    textAlign: TextAlign.center, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 10)),
                ],
              );
            },
          )),
          Padding(padding: const EdgeInsets.fromLTRB(12, 7, 12, 13),
            child: SizedBox(width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => _go(6),
                icon: const Icon(Icons.fact_check_outlined, size: 18),
                label: const Text('فتح فحص التعارضات'),
              )),
          ),
        ]),
      ),
    );
  }
}
