import 'package:flutter/material.dart';

import '../../data/database_service.dart';
import '../../core/interface_settings.dart';
import '../../core/smart_widgets.dart';
import '../../services/constraint_explanation_service.dart';
import '../../services/schedule_comparison_service.dart';
import '../../services/schedule_improvement_service.dart';
import '../timetable/schedule_search_dialog.dart';
import '../timetable/schedule_comparison_dialog.dart';
import '../timetable/constraint_explanation_dialog.dart';
import 'smart_scenario.dart';

class SmartWorkspacePage extends StatefulWidget {
  const SmartWorkspacePage({super.key, this.request, required this.onNavigate});
  final String? request;
  final ValueChanged<int> onNavigate;
  @override
  State<SmartWorkspacePage> createState() => _SmartWorkspacePageState();
}

class _SmartWorkspacePageState extends State<SmartWorkspacePage> {
  late Future<Map<String, Object?>> _future;
  SmartScenarioKind _kind = SmartScenarioKind.subjectPeriod;
  int? _subject, _slot, _teacher, _day;
  bool _busy = false, _recognized = false;
  String? _error;
  List<Map<String, Object?>>? _solution;
  Map<String, Object?>? _trial, _baseline;
  ScheduleQuality? _quality;
  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  List<Map<String, Object?>> _rows(Map<String, Object?> data, String k) =>
      (data[k] as List? ?? []).cast<Map<String, Object?>>();
  Future<Map<String, Object?>> _load() async {
    final db = DatabaseService.instance;
    final version = await db.activeVersionId(await db.activeYearId());
    final entries = version == null
        ? <Map<String, Object?>>[]
        : await db.entriesDetailed(versionId: version);
    final data = <String, Object?>{
      'sections': await db.sectionsDetailed(),
      'requirements': await db.requirementsDetailed(),
      'teachers': await db.rows('teachers', orderBy: 'name'),
      'subjects': await db.rows('subjects', orderBy: 'name'),
      'qualifications': await db.rows('teacher_subjects'),
      'teacherGrades': await db.rows('teacher_grades'),
      'teacherSubjectGrades': await db.rows('teacher_subject_grades'),
      'days': await db.rows('school_days', orderBy: 'position'),
      'slots': await db.rows('time_slots', orderBy: 'position'),
      'subjectBlockedSlots': await db.rows('subject_blocked_slots'),
      'teacherAvailability': await db.rows('teacher_availability'),
      'initialPlacements': entries,
      'lockedPlacements': entries.where((e) => e['is_locked'] == 1).toList(),
      'softPriorities': Map<String, int>.from(
        InterfaceSettings.instance.softPriorities,
      ),
    };
    data['subjectPreferences'] = data['subjects'];
    final slots = _rows(
      data,
      'slots',
    ).where((e) => e['kind'] == 'lesson' && e['is_available'] != 0).toList();
    final parsed = widget.request == null
        ? null
        : SmartScenario.fromRequest(
            widget.request!,
            _rows(data, 'subjects'),
            slots,
          );
    if (parsed != null) {
      _recognized = true;
      _kind = parsed.kind;
      _subject = parsed.subjectId;
      _slot = parsed.slotId;
    }
    _subject ??= _rows(data, 'subjects').firstOrNull?['id'] as int?;
    _slot ??= slots.firstOrNull?['id'] as int?;
    _teacher ??= _rows(data, 'teachers').firstOrNull?['id'] as int?;
    _day ??=
        _rows(data, 'days').where((e) => e['is_active'] != 0).firstOrNull?['id']
            as int?;
    return data;
  }

  void _invalidate() {
    _solution = null;
    _quality = null;
    _trial = null;
    _baseline = null;
    _error = null;
  }

  Future<void> _run(Map<String, Object?> data) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _invalidate();
    });
    try {
      if (_rows(
        data,
        'requirements',
      ).every((r) => (r['weekly_lessons'] as num? ?? 0) <= 0))
        throw StateError(
          'حدد الحصص المطلوبة للصفوف من إعداد الجدول قبل تجربة التوزيع.',
        );
      final scenario = SmartScenario(
        _kind,
        subjectId: _subject,
        slotId: _slot,
        teacherId: _teacher,
        dayId: _day,
      );
      final trial = scenario.applyTo(data);
      final proofs = const ConstraintExplanationService()
          .explain(trial)
          .where((e) => e.proven)
          .toList();
      if (proofs.isNotEmpty) {
        if (mounted)
          await showConstraintExplanations(context, proofs, input: trial);
        return;
      }
      if (!mounted) return;
      final results = await showScheduleSearchDialog(
        context,
        input: {...trial, 'nodeLimit': 600000, 'timeLimitMs': 30000},
        profiles: [scenario.profile],
      );
      if (!mounted || results == null || results.isEmpty) return;
      final valid = results.where((e) => e['complete'] == true).toList();
      if (valid.isEmpty) {
        setState(
          () => _error = 'لم يكتمل السيناريو ضمن هذه المحاولة. هذا لا يثبت استحالته. يمكنك مراجعة القيود أو استخدام بحث أوسع.',
        );
        return;
      }
      final entries = (valid.first['placements'] as List)
          .map((e) => Map<String, Object?>.from(e as Map))
          .toList();
      if (!ScheduleImprovementService.valid(trial, entries))
        throw StateError('لم تجتز النتيجة فحص القيود النهائي.');
      final quality = ScheduleComparisonService.evaluate(
        entries: entries,
        slots: _rows(data, 'slots'),
        days: _rows(data, 'days'),
        requirements: _rows(data, 'requirements'),
        before: _rows(data, 'initialPlacements'),
      );
      setState(() {
        _solution = entries;
        _trial = trial;
        _baseline = data;
        _quality = quality;
      });
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _preview() async {
    final data = _baseline, solution = _solution;
    if (data == null || solution == null) return;
    await showScheduleComparisonDialog(
      context,
      before: _rows(data, 'initialPlacements'),
      after: solution,
      sections: _rows(data, 'sections'),
      teachers: _rows(data, 'teachers'),
      subjects: _rows(data, 'subjects'),
      days: _rows(data, 'days'),
      slots: _rows(data, 'slots'),
      title: 'نتيجة السيناريو — قبل وبعد',
      readOnly: true,
      description: 'هذه نتيجة على نسخة تجريبية من بياناتك. لم يُحفظ الشرط أو الجدول؛ طبّق الشرط من إعداده ثم أعد البحث للمراجعة والحفظ.',
    );
  }

  Widget _select(
    String label,
    List<Map<String, Object?>> items,
    int? value,
    ValueChanged<int?> change,
  ) => Padding(
    padding: const EdgeInsets.only(top: 14),
    child: DropdownButtonFormField<int>(
      key: ValueKey('$label-$value'),
      initialValue: value,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: [
        for (final e in items)
          DropdownMenuItem(value: e['id'] as int, child: Text('${e['name']}')),
      ],
      onChanged: _busy
          ? null
          : (v) => setState(() {
              change(v);
              _invalidate();
            }),
    ),
  );
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, Object?>>(
    future: _future,
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return Center(
          child: Text('تعذر تحميل بيانات السيناريو: ${snapshot.error}'),
        );
      if (!snapshot.hasData)
        return const Center(child: CircularProgressIndicator());
      final data = snapshot.data!;
      return ListView(
        padding: const EdgeInsets.all(18),
        children: [
          SmartPanel(
            tint: true,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SmartBadge('مختبر ماذا لو؟'),
                const SizedBox(height: 14),
                const Text(
                  'جرّب القرار قبل أن يغيّر أسبوعك',
                  style: TextStyle(fontSize: 23, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 10),
                const Text(
                  'يبحث في نسخة من بيانات المدرسة الحالية. تبقى بياناتك والجدول المحفوظ كما هي أثناء التجربة.',
                ),
                if (widget.request != null) ...[
                  const SizedBox(height: 14),
                  Text(
                    'طلبك: ${widget.request}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  Text(
                    _recognized
                        ? 'تعرّفنا على المثال. راجع الخيارات أدناه قبل البحث.'
                        : 'لم نحدد معنى الطلب بثقة. اختر نوع التغيير والبيانات يدوياً أدناه.',
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 18),
          SmartPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                DropdownButtonFormField<SmartScenarioKind>(
                  key: ValueKey('scenario-kind-$_kind'),
                  initialValue: _kind,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'نوع التجربة'),
                  items: const [
                    DropdownMenuItem(
                      value: SmartScenarioKind.subjectPeriod,
                      child: Text('منع مادة من فترة'),
                    ),
                    DropdownMenuItem(
                      value: SmartScenarioKind.teacherDay,
                      child: Text('تفريغ يوم لمعلم'),
                    ),
                    DropdownMenuItem(
                      value: SmartScenarioKind.spacing,
                      child: Text('تحسين الفصل بين حصتي المادة'),
                    ),
                    DropdownMenuItem(
                      value: SmartScenarioKind.minimalChanges,
                      child: Text('أقل تغييرات على الجدول'),
                    ),
                  ],
                  onChanged: _busy
                      ? null
                      : (v) {
                          if (v != null)
                            setState(() {
                              _kind = v;
                              _invalidate();
                            });
                        },
                ),
                if (_kind == SmartScenarioKind.subjectPeriod) ...[
                  _select(
                    'المادة',
                    _rows(data, 'subjects'),
                    _subject,
                    (v) => _subject = v,
                  ),
                  _select(
                    'الفترة الممنوعة',
                    _rows(data, 'slots')
                        .where(
                          (e) =>
                              e['kind'] == 'lesson' && e['is_available'] != 0,
                        )
                        .toList(),
                    _slot,
                    (v) => _slot = v,
                  ),
                ],
                if (_kind == SmartScenarioKind.teacherDay) ...[
                  _select(
                    'المعلم',
                    _rows(data, 'teachers'),
                    _teacher,
                    (v) => _teacher = v,
                  ),
                  _select(
                    'يوم التفريغ',
                    _rows(
                      data,
                      'days',
                    ).where((e) => e['is_active'] != 0).toList(),
                    _day,
                    (v) => _day = v,
                  ),
                ],
                const SizedBox(height: 16),
                const Text(
                  'الأقفال والمنع والإتاحة شروط ملزمة. الفصل بين الحصتين رغبة مرنة ضمن الفترات المسموحة.',
                  style: TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  key: const ValueKey('run-smart-scenario'),
                  onPressed: _busy ? null : () => _run(data),
                  icon: const Icon(Icons.auto_awesome_outlined),
                  label: Text(
                    _busy ? 'جارٍ البحث…' : 'اختبار السيناريو دون حفظ',
                  ),
                ),
              ],
            ),
          ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                _error!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
          if (_quality != null) ...[
            const SmartHeading('النتيجة التي وصل إليها البحث'),
            SmartPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      SmartBadge('${_quality!.lessonCount} حصة'),
                      SmartBadge('${_quality!.changedLessons} حصص تغيّرت'),
                      SmartBadge('${_quality!.teacherGaps} فراغات للمعلمين'),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'نتيجة كاملة اجتازت فحص الشروط التجريبية. لم تتغير بياناتك.',
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: _preview,
                    icon: const Icon(Icons.compare_arrows),
                    label: const Text('معاينة التغييرات'),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton(
                    onPressed: () => widget.onNavigate(
                      _kind == SmartScenarioKind.subjectPeriod
                          ? 4
                          : _kind == SmartScenarioKind.teacherDay
                          ? 5
                          : 7,
                    ),
                    child: const Text('فتح الإعدادات للتطبيق الفعلي'),
                  ),
                ],
              ),
            ),
          ],
          const SmartHeading('الأدوات المرتبطة'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: () => widget.onNavigate(8),
                icon: const Icon(Icons.person_off_outlined),
                label: const Text('طوارئ اليوم والبدلاء'),
              ),
              OutlinedButton.icon(
                onPressed: () => widget.onNavigate(7),
                icon: const Icon(Icons.manage_search),
                label: const Text('توزيع الحصص'),
              ),
            ],
          ),
          if (_trial != null)
            const Padding(
              padding: EdgeInsets.only(top: 16),
              child: Text(
                'المعاينة مرتبطة ببيانات لحظة التجربة. أعد البحث بعد أي تعديل فعلي.',
                style: TextStyle(fontSize: 11),
              ),
            ),
        ],
      );
    },
  );
}
