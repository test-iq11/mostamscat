import 'dart:convert';

import 'smart_access_dialog.dart' show normalizeSmartText;

enum SmartScenarioKind { subjectPeriod, teacherDay, spacing, minimalChanges }

class SmartScenario {
  const SmartScenario(
    this.kind, {
    this.subjectId,
    this.slotId,
    this.teacherId,
    this.dayId,
  });
  final SmartScenarioKind kind;
  final int? subjectId, slotId, teacherId, dayId;
  static SmartScenario? fromRequest(
    String text,
    List<Map<String, Object?>> subjects,
    List<Map<String, Object?>> slots,
  ) {
    final query = normalizeSmartText(text);
    if (query == normalizeSmartText('باعد بين حصتي المادة'))
      return const SmartScenario(SmartScenarioKind.spacing);
    if (query == normalizeSmartText('أريد أقل تغييرات'))
      return const SmartScenario(SmartScenarioKind.minimalChanges);
    if (slots.isNotEmpty) {
      for (final subject in subjects) {
        if (query ==
            normalizeSmartText('أبعد ${subject['name']} عن الحصة الأولى'))
          return SmartScenario(
            SmartScenarioKind.subjectPeriod,
            subjectId: subject['id'] as int,
            slotId: slots.first['id'] as int,
          );
      }
    }
    return null;
  }

  Map<String, Object?> applyTo(Map<String, Object?> source) {
    final result = Map<String, Object?>.from(
      jsonDecode(jsonEncode(source)) as Map,
    );
    List<Map<String, Object?>> rows(String key) => (result[key] as List? ?? [])
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    switch (kind) {
      case SmartScenarioKind.subjectPeriod:
        if (subjectId == null || slotId == null)
          throw ArgumentError('اختر المادة والفترة.');
        if (!rows('subjects').any((e) => e['id'] == subjectId) ||
            !rows('slots').any(
              (e) =>
                  e['id'] == slotId &&
                  e['kind'] == 'lesson' &&
                  e['is_available'] != 0,
            ))
          throw ArgumentError('المادة أو الفترة لم تعد متاحة.');
        result['subjectBlockedSlots'] = [
          ...rows('subjectBlockedSlots').where(
            (e) => e['subject_id'] != subjectId || e['slot_id'] != slotId,
          ),
          {'subject_id': subjectId, 'slot_id': slotId},
        ];
      case SmartScenarioKind.teacherDay:
        if (teacherId == null || dayId == null)
          throw ArgumentError('اختر المعلم واليوم.');
        if (!rows('teachers').any((e) => e['id'] == teacherId) ||
            !rows('days').any((e) => e['id'] == dayId && e['is_active'] != 0))
          throw ArgumentError('المعلم أو يوم الدوام لم يعد متاحاً.');
        result['teacherAvailability'] = [
          ...rows(
            'teacherAvailability',
          ).where((e) => e['teacher_id'] != teacherId || e['day_id'] != dayId),
          for (final slot in rows('slots').where((e) => e['kind'] == 'lesson'))
            {
              'teacher_id': teacherId,
              'day_id': dayId,
              'slot_id': slot['id'],
              'is_available': 0,
            },
        ];
      case SmartScenarioKind.spacing:
        result['softPriorities'] = {
          ...Map<String, Object?>.from(result['softPriorities'] as Map? ?? {}),
          'spacing': 3,
        };
      case SmartScenarioKind.minimalChanges:
        break;
    }
    return result;
  }

  String get profile => kind == SmartScenarioKind.spacing
      ? 'balanced_subjects'
      : 'minimal_changes';
}
