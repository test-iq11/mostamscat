import 'package:flutter/material.dart';

import '../../data/database_service.dart';

String normalizeSmartText(String value) => value
    .trim()
    .toLowerCase()
    .replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '')
    .replaceAll(RegExp('[أإآٱ]'), 'ا')
    .replaceAll('ى', 'ي')
    .replaceAll('ة', 'ه')
    .replaceAll(RegExp(r'\s+'), ' ');

class SmartAccessTarget {
  const SmartAccessTarget(
    this.label,
    this.description,
    this.route, {
    this.teacherId,
    this.sectionId,
  });
  final String label, description;
  final int route;
  final int? teacherId, sectionId;
}

Future<void> showSmartAccess(
  BuildContext context, {
  required ValueChanged<int> onNavigate,
  ValueChanged<int>? onTeacher,
  ValueChanged<int>? onSection,
}) async {
  final target = await showDialog<SmartAccessTarget>(
    context: context,
    builder: (_) => const _SearchDialog(),
  );
  if (target == null || !context.mounted) return;
  if (target.teacherId != null && onTeacher != null) {
    onTeacher(target.teacherId!);
  } else if (target.sectionId != null && onSection != null) {
    onSection(target.sectionId!);
  } else {
    onNavigate(target.route);
  }
}

class _SearchDialog extends StatefulWidget {
  const _SearchDialog();
  @override
  State<_SearchDialog> createState() => _SearchDialogState();
}

class _SearchDialogState extends State<_SearchDialog> {
  final _query = TextEditingController();
  late final Future<List<SmartAccessTarget>> _future = _load();
  Future<List<SmartAccessTarget>> _load() async {
    final db = DatabaseService.instance;
    return [
      for (final e in await db.rows('teachers', orderBy: 'name'))
        SmartAccessTarget(
          '${e['name']}',
          'جدول المعلم',
          1,
          teacherId: e['id'] as int,
        ),
      for (final e in await db.sectionsDetailed())
        SmartAccessTarget(
          '${e['grade_name']} ${e['section_name'] ?? e['name']}',
          'جدول الصف',
          1,
          sectionId: e['id'] as int,
        ),
      for (final e in await db.rows('subjects', orderBy: 'name'))
        SmartAccessTarget('${e['name']}', 'إدارة المواد والقيود', 4),
      const SmartAccessTarget('الحصص المطلوبة', 'أعداد المواد لكل صف', 3),
      const SmartAccessTarget('التقارير', 'معاينة وحفظ وطباعة', 10),
      const SmartAccessTarget('النسخ الاحتياطية', 'حفظ واستعادة البيانات', 11),
      const SmartAccessTarget('توزيع الحصص', 'توزيع محلي دون إنترنت', 7),
      const SmartAccessTarget('طوارئ اليوم والغياب', 'إعداد خطة بدلاء', 8),
      const SmartAccessTarget('إعدادات التطبيق', 'الخط والوضع الليلي', 15),
      const SmartAccessTarget('ماذا لو؟', 'مختبر السيناريوهات', 16),
    ];
  }

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('الوصول الذكي'),
    content: SizedBox(
      width: 600,
      height: MediaQuery.sizeOf(context).height * .6,
      child: Column(
        children: [
          TextField(
            key: const ValueKey('smart-access-query'),
            controller: _query,
            autofocus: true,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              hintText: 'معلم، صف، مادة أو أداة…',
              prefixIcon: Icon(Icons.search),
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: FutureBuilder<List<SmartAccessTarget>>(
              future: _future,
              builder: (context, snapshot) {
                if (snapshot.hasError)
                  return const Center(
                    child: Text('تعذر تحميل البحث. أعد المحاولة.'),
                  );
                if (!snapshot.hasData)
                  return const Center(child: CircularProgressIndicator());
                final query = normalizeSmartText(_query.text);
                final items = snapshot.data!
                    .where(
                      (e) =>
                          normalizeSmartText('${e.label} ${e.description}')
                              .contains(query),
                    )
                    .toList();
                if (items.isEmpty)
                  return const Center(
                    child: Text('لا توجد نتائج. جرّب اسماً آخر.'),
                  );
                return ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, i) {
                    final item = items[i];
                    return ListTile(
                      title: Text(item.label),
                      subtitle: Text(item.description),
                      trailing: const Icon(Icons.chevron_left),
                      onTap: () => Navigator.pop(context, item),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إغلاق'),
      ),
    ],
  );
}
