import 'package:flutter/material.dart';

import 'design_style.dart';

ThemeData buildAppTheme({
  String style = 'calm',
  bool dark = false,
  DesignStyle design = const DesignStyle(),
}) {
  final primary = design.primary(dark), soft = design.soft(dark);
  final surface = dark ? const Color(0xff18243a) : Colors.white;
  final raised = dark ? const Color(0xff223149) : const Color(0xfff7f9fd);
  final background = dark ? const Color(0xff101828) : design.background;
  final ink = dark ? const Color(0xfff2f5ff) : const Color(0xff15233f);
  final muted = dark ? const Color(0xffb7c3d8) : const Color(0xff77839a);
  final line = dark ? const Color(0xff35425c) : const Color(0xffe9edf5);
  final scheme =
      ColorScheme.fromSeed(
        seedColor: primary,
        brightness: dark ? Brightness.dark : Brightness.light,
      ).copyWith(
        primary: primary,
        onPrimary: DesignStyle.foreground(primary),
        primaryContainer: soft,
        onPrimaryContainer: dark ? ink : primary,
        secondary: primary,
        surface: surface,
        surfaceContainer: surface,
        surfaceContainerLow: raised,
        surfaceContainerHigh: raised,
        surfaceContainerHighest: dark ? const Color(0xff2a3b57) : soft,
        onSurface: ink,
        onSurfaceVariant: muted,
        outlineVariant: line,
      );
  final border = OutlineInputBorder(
    borderRadius: BorderRadius.circular(13),
    borderSide: BorderSide(color: line),
  );
  return ThemeData(
    useMaterial3: true,
    fontFamily: 'JadwaliStudio',
    fontFamilyFallback: const ['JadwaliLatin'],
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    dialogTheme: DialogThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      foregroundColor: ink,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
    ),
    iconTheme: IconThemeData(color: primary),
    splashFactory: InkRipple.splashFactory,
    visualDensity: VisualDensity.standard,
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: dark ? const Color(0xff303a56) : const Color(0xff23345b),
      contentTextStyle: const TextStyle(color: Colors.white, fontFamily: 'JadwaliStudio'),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    listTileTheme: ListTileThemeData(
      iconColor: primary,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    dividerTheme: DividerThemeData(color: line, thickness: 1, space: 1),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0.5,
      shadowColor: const Color(0x1424365B),
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(design.round),
        side: BorderSide(color: line),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: raised,
      border: border,
      enabledBorder: border,
      focusedBorder: border.copyWith(
        borderSide: BorderSide(color: primary, width: 1.7),
      ),
      prefixIconColor: primary,
      suffixIconColor: muted,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: scheme.onPrimary,
        minimumSize: const Size(44, 46),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primary,
        minimumSize: const Size(44, 44),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: raised,
      selectedColor: soft,
      secondarySelectedColor: soft,
      labelStyle: TextStyle(
        fontFamily: 'JadwaliStudio',
        fontFamilyFallback: const ['JadwaliLatin'],
        color: ink,
      ),
      secondaryLabelStyle: TextStyle(color: primary),
      side: BorderSide(color: line),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(99)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      indicatorColor: soft,
    ),
    bottomSheetTheme: BottomSheetThemeData(backgroundColor: surface,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(25)))),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: primary, foregroundColor: scheme.onPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
    ),
    textTheme: TextTheme(
      headlineSmall: TextStyle(
        fontSize: 26,
        fontWeight: FontWeight.w700,
        color: ink,
      ),
      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: ink,
      ),
      titleMedium: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: ink,
      ),
      bodyLarge: TextStyle(fontSize: 15, height: 1.7, color: ink),
      bodyMedium: TextStyle(fontSize: 13, height: 1.7, color: ink),
      bodySmall: TextStyle(fontSize: 11, height: 1.7, color: muted),
    ),
  );
}
