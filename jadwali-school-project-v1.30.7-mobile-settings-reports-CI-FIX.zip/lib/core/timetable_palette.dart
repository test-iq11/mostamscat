/// One subject -> one stable accent in the editor and printable PDF.
/// Uses database subject ids, not row positions, so sorting does not recolor.
class TimetablePalette {
  const TimetablePalette._();
  static const int navy = 0xFF183B66;
  static const int paper = 0xFFF4F7FB;
  static const List<int> accents = <int>[
    0xFF8D6230,
    0xFF296DB1,
    0xFF8061B1,
    0xFF168470,
    0xFF288296,
    0xFFAD6746,
    0xFFAD5E89,
    0xFF71862D,
    0xFF6070B5,
    0xFF747A89,
    0xFFA5619B,
    0xFF6D849A,
  ];
  static const List<int> tints = <int>[
    0xFFFCF4E9,
    0xFFEDF5FE,
    0xFFF4EFFB,
    0xFFEAF6F1,
    0xFFEAF6F9,
    0xFFFCF1EB,
    0xFFFCEFF6,
    0xFFF4F8E8,
    0xFFEEF1FF,
    0xFFF1F3F7,
    0xFFFBEFFA,
    0xFFEDF3F7,
  ];
  static int index(int subjectId) =>
      (subjectId.abs() + accents.length - 1) % accents.length;
  static int accent(int subjectId) => accents[index(subjectId)];
  static int tint(int subjectId) => tints[index(subjectId)];
}
