import 'dart:convert';

import 'package:flutter/services.dart';

import '../core/design_style.dart';

class DesignExportService {
  static String encode(DesignStyle design) =>
      const JsonEncoder.withIndent('  ')
          .convert({'format': 'jadwali-design-v2', 'theme': design.toMap()});
  static DesignStyle decode(String source) {
    if (source.length > 20000)
      throw const FormatException('ملف الألوان أكبر من الحد المسموح.');
    final value = jsonDecode(source);
    if (value is! Map ||
        value['format'] != 'jadwali-design-v2' ||
        value['theme'] is! Map) {
      throw const FormatException('اختر ملف ألوان مصدّراً من استوديو المظهر.');
    }
    return DesignStyle.fromMap(value['theme'] as Map);
  }

  static Future<String> html({
    required DesignStyle design,
    required String schoolName,
    required bool dark,
    required double fontScale,
  }) async {
    final source = await rootBundle.loadString('assets/design/studio.html');
    final data =
        jsonEncode({
              'theme': design.toMap(),
              'name': schoolName,
              'dark': dark,
              'font': fontScale * 100,
            })
            .replaceAll('<', r'\u003c')
            .replaceAll('>', r'\u003e')
            .replaceAll('&', r'\u0026');
    return source.replaceFirst(
      '</head>',
      '<script data-design-bootstrap="true">window.JADWALI_DESIGN=$data;</script></head>',
    );
  }
}
