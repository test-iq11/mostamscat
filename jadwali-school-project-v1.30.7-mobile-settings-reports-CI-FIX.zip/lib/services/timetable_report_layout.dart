import '../core/timetable_ordering.dart';
/// Shared week-grid layout used by PDF, Word, Excel and CSV exports.
/// Weekdays are rows and periods are columns, ordered from right to left.
class TimetableReportLayout {
  TimetableReportLayout({
    required List<Map<String, Object?>> entries,
    required List<Map<String, Object?>> sections,
    required List<Map<String, Object?>> days,
    required List<Map<String, Object?>> slots,
  })  : entries = List<Map<String, Object?>>.unmodifiable(entries),
        sections = List<Map<String, Object?>>.unmodifiable(_orderedSections(sections, entries)),
        days = List<Map<String, Object?>>.unmodifiable(
          _ordered(days.where((d) => _asInt(d['is_active'], fallback: 1) == 1).toList()),
        ),
        slots = List<Map<String, Object?>>.unmodifiable(_ordered(slots.where((s) => s['kind'] == 'lesson' && _asInt(s['is_available'], fallback: 1) == 1).toList())) {
    final entryMap = <String, Map<String, Object?>>{};
    for (final entry in entries) {
      entryMap['${_asInt(entry['section_id'])}:${_asInt(entry['day_id'])}:${_asInt(entry['slot_id'])}'] = entry;
    }
    _entryByCell = entryMap;
  }

  final List<Map<String, Object?>> entries;
  final List<Map<String, Object?>> sections;
  final List<Map<String, Object?>> days;
  final List<Map<String, Object?>> slots;
  late final Map<String, Map<String, Object?>> _entryByCell;

  static List<Map<String, Object?>> _ordered(List<Map<String, Object?>> values) {
    final result = List<Map<String, Object?>>.from(values);
    result.sort((a, b) => TimetableOrdering.compare(a, b));
    return result;
  }

  static List<Map<String, Object?>> _orderedSections(
    List<Map<String, Object?>> input,
    List<Map<String, Object?>> entries,
  ) {
    final result = List<Map<String, Object?>>.from(input);
    if (result.isEmpty) {
      final seen = <int>{};
      for (final entry in entries) {
        final id = _asInt(entry['section_id']);
        if (seen.add(id)) {
          result.add({
            'id': id,
            'grade_name': entry['grade_name'] ?? entry['section_grade_name'] ?? '',
            'section_name': entry['section_name'] ?? 'الشعبة $id',
            'grade_position': entry['grade_position'] ?? 0,
            'stage_position': entry['stage_position'] ?? 0,
          });
        }
      }
    }
    // sectionsDetailed() already returns the official stage/grade/section order.
    // Sort only when the source explicitly includes the order fields.
    if (result.any((s) => s.containsKey('stage_position') || s.containsKey('grade_position'))) {
      result.sort((a, b) {
        var c = _asInt(a['stage_position']).compareTo(_asInt(b['stage_position']));
        if (c != 0) return c;
        c = _asInt(a['grade_position']).compareTo(_asInt(b['grade_position']));
        if (c != 0) return c;
        c = _asInt(a['grade_id']).compareTo(_asInt(b['grade_id']));
        if (c != 0) return c;
        return '${a['section_name'] ?? ''}'.compareTo('${b['section_name'] ?? ''}');
      });
    }
    return result;
  }

  /// Single authoritative cell lookup used by the editor-style PDF.
  Map<String, Object?>? entryAt(int sectionId, int dayId, int slotId) =>
      _entryByCell['$sectionId:$dayId:$slotId'];

  String sectionTitle(Map<String, Object?> section) {
    final grade = _shortGradeName(section['grade_name'] ?? section['section_grade_name']);
    final name = '${section['section_name'] ?? 'الشعبة ${section['id']}'}'.trim();
    final parts = <String>[if (grade.isNotEmpty) 'الصف $grade', if (name.isNotEmpty) 'الشعبة $name'];
    return 'جدول ${parts.join('، ')}';
  }

  /// Uses left-to-right marks around clock values so Arabic RTL rendering does
  /// not reverse values such as 08:00 and 08:45 in PDF/Word.
  String periodLabel(Map<String, Object?> slot) {
    final name = '${slot['name'] ?? 'الحصة'}'.trim();
    final start = _normalTime(slot['start_time']);
    final end = _normalTime(slot['end_time']);
    if (start.isEmpty && end.isEmpty) return name;
    final range = start.isNotEmpty && end.isNotEmpty
        ? '\u200E$start\u200E إلى \u200E$end\u200E'
        : '\u200E${start.isNotEmpty ? start : end}\u200E';
    return '$name\n$range';
  }

  String lessonCell(Map<String, Object?> section, Map<String, Object?> day, Map<String, Object?> slot) {
    final entry = _entryByCell['${_asInt(section['id'])}:${_asInt(day['id'])}:${_asInt(slot['id'])}'];
    if (entry == null) return '';
    final subject = '${entry['subject_name'] ?? 'مادة'}'.trim();
    final teacher = '${entry['teacher_name'] ?? ''}'.trim();
    final room = '${entry['room_name'] ?? ''}'.trim();
    return [subject, if (teacher.isNotEmpty) teacher, if (room.isNotEmpty) room].join('\n');
  }

  /// عنوان العمود يميّز الصف والشعبة في التقرير الشامل.
  String sectionColumnTitle(Map<String, Object?> section) {
    final grade = _shortGradeName(section['grade_name'] ?? section['section_grade_name']);
    final name = '${section['section_name'] ?? 'الشعبة ${section['id']}'}'.trim();
    return [if (grade.isNotEmpty) 'الصف $grade', if (name.isNotEmpty) 'الشعبة $name'].join('\n');
  }

  /// محتوى خلية واحدة: كل حصص هذه الشعبة في هذا اليوم، مع اسم الفترة ووقتها.
  /// بهذا يصبح التقرير الشامل مصفوفة (الأيام صفوف، والصفوف/الشعب أعمدة).
  String sectionDayCell(Map<String, Object?> section, Map<String, Object?> day) {
    final sectionId = _asInt(section['id']);
    final dayId = _asInt(day['id']);
    final lessons = <String>[];
    for (final slot in slots) {
      final entry = _entryByCell['$sectionId:$dayId:${_asInt(slot['id'])}'];
      if (entry == null) continue;
      final periodName = '${slot['name'] ?? 'الحصة'}'.trim();
      final start = _normalTime(slot['start_time']);
      final end = _normalTime(slot['end_time']);
      final time = start.isNotEmpty && end.isNotEmpty
          ? ' ($start-$end)'
          : start.isNotEmpty
              ? ' ($start)'
              : end.isNotEmpty
                  ? ' ($end)'
                  : '';
      final subject = '${entry['subject_name'] ?? 'مادة'}'.trim();
      final teacher = '${entry['teacher_name'] ?? ''}'.trim();
      final room = '${entry['room_name'] ?? ''}'.trim();
      lessons.add('$periodName$time: $subject${teacher.isNotEmpty ? '\n$teacher' : ''}${room.isNotEmpty ? '\n$room' : ''}');
    }
    return lessons.join('\n\n');
  }

  /// Flat matrix rows consumed by Word, Excel and CSV: one weekday per row,
  /// and one grade/section per column. The first column is the day label.
  List<List<String>> rowsForAllSections() {
    if (sections.isEmpty) return <List<String>>[['اليوم']];
    return <List<String>>[
      <String>['اليوم', ...sections.map(sectionColumnTitle)],
      ...days.map((day) => <String>[
        '${day['name'] ?? ''}',
        ...sections.map((section) => sectionDayCell(section, day)),
      ]),
    ];
  }

  static String _normalTime(Object? value) {
    var result = '${value ?? ''}'.trim();
    if (result.isEmpty) return '';
    const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
    const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
    final converted = StringBuffer();
    for (final rune in result.runes) {
      final char = String.fromCharCode(rune);
      final arabicIndex = arabicDigits.indexOf(char);
      final persianIndex = persianDigits.indexOf(char);
      if (arabicIndex >= 0) {
        converted.write(arabicIndex);
      } else if (persianIndex >= 0) {
        converted.write(persianIndex);
      } else {
        converted.write(char);
      }
    }
    result = converted.toString();
    final match = RegExp(r'^(\d{1,2}):(\d{2})$').firstMatch(result);
    if (match != null) return '${match.group(1)!.padLeft(2, '0')}:${match.group(2)}';
    return result;
  }

  static String _shortGradeName(Object? value) => (value?.toString() ?? '')
      .replaceFirst(RegExp(r'^\s*الصف\s+'), '')
      .replaceFirst(RegExp(r'\s+الابتدائي\s*$'), '')
      .trim();

  static int _asInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
