/// Availability restrictions are additive. Null scope means all grades/subjects.
/// Unknown scope is deliberately optimistic for aggregate capacity bounds.
class TeacherAvailabilityPolicy {
  TeacherAvailabilityPolicy(List<Map<String, Object?>> rows) {
    for (final row in rows) {
      if (_n(row['is_available'], 1) != 0) continue;
      final key =
          '${_n(row['teacher_id'])}:${_n(row['day_id'])}:${_n(row['slot_id'])}';
      (_blocked[key] ??= []).add((_n(row['grade_id']), _n(row['subject_id'])));
    }
  }
  final Map<String, List<(int, int)>> _blocked = {};
  static bool isGlobal(Map<String, Object?> row) =>
      _n(row['grade_id']) == 0 && _n(row['subject_id']) == 0;

  bool isAvailable({
    required int teacherId,
    required int dayId,
    required int slotId,
    int? gradeId,
    int? subjectId,
  }) {
    for (final scope
        in _blocked['$teacherId:$dayId:$slotId'] ?? const <(int, int)>[]) {
      if ((scope.$1 == 0 || scope.$1 == gradeId) &&
          (scope.$2 == 0 || scope.$2 == subjectId))
        return false;
    }
    return true;
  }
}

int _n(Object? value, [int fallback = 0]) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
