/// Pure metadata helpers for reversible minimal repairs. An archived timetable
/// is never overwritten: undo creates ANOTHER version after user confirmation.
class RepairHistoryService {
  const RepairHistoryService();

  static const String _sourceKey = '[JADWALI_MIN_REPAIR_SOURCE:';

  String note({required int sourceVersionId, required int moved,
      required int remaining, required String reason}) =>
      '$_sourceKey$sourceVersionId] الإصلاح الذكي: نُقلت $moved حصص '
      'وبقي $remaining تعارض مانع. $reason. النسخة السابقة محفوظة.';

  int? sourceVersionId(Object? notes) {
    final match = RegExp(r'\[JADWALI_MIN_REPAIR_SOURCE:(\d+)\]')
        .firstMatch('$notes');
    final id = match == null ? null : int.tryParse(match.group(1)!);
    return id != null && id > 0 ? id : null;
  }
}
