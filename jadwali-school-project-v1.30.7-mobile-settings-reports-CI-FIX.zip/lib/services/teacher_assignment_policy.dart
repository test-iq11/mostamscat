/// مصدر موحّد لقواعد إسناد المعلم للمادة والصف.
///
/// القاعدة الحديثة هي (المعلم + المادة + الصف). إذا كانت للمعلم أي قواعد حديثة
/// لمواد أخرى ولم توجد قاعدة للمادة المطلوبة، نفشل بشكل آمن ولا نفترض أن كل الصفوف
/// مسموحة. نحتفظ بالتوافق القديم فقط عندما لا توجد قواعد حديثة للمعلم مطلقاً.
class TeacherAssignmentPolicy {
  TeacherAssignmentPolicy({
    required List<Map<String, Object?>> qualifications,
    required List<Map<String, Object?>> teacherGrades,
    required List<Map<String, Object?>> teacherSubjectGrades,
  }) {
    for (final row in qualifications) {
      _qualified.add(_pair(_asInt(row['teacher_id']), _asInt(row['subject_id'])));
    }
    for (final row in teacherGrades) {
      (_legacyGrades[_asInt(row['teacher_id'])] ??= <int>{})
          .add(_asInt(row['grade_id']));
    }
    for (final row in teacherSubjectGrades) {
      final teacherId = _asInt(row['teacher_id']);
      final subjectId = _asInt(row['subject_id']);
      (_subjectGrades[_pair(teacherId, subjectId)] ??= <int>{})
          .add(_asInt(row['grade_id']));
      _teachersWithSubjectRules.add(teacherId);
      _hasAnySubjectGradeRules = true;
    }
  }

  final Set<String> _qualified = <String>{};
  final Map<int, Set<int>> _legacyGrades = <int, Set<int>>{};
  final Map<String, Set<int>> _subjectGrades = <String, Set<int>>{};
  final Set<int> _teachersWithSubjectRules = <int>{};
  bool _hasAnySubjectGradeRules = false;

  static String _pair(int teacherId, int subjectId) => '$teacherId:$subjectId';

  static int _asInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }

  bool isSubjectQualified(int teacherId, int subjectId) =>
      _qualified.contains(_pair(teacherId, subjectId));

  /// هل يجوز للمعلم تدريس هذه المادة في صف الشعبة الحالي؟
  bool isGradeAllowed(int teacherId, int subjectId, int gradeId) {
    if (gradeId <= 0) return false;

    final subjectRules = _subjectGrades[_pair(teacherId, subjectId)];
    if (subjectRules != null && subjectRules.isNotEmpty) {
      return subjectRules.contains(0) || subjectRules.contains(gradeId);
    }

    // وجود إعدادات حديثة للمعلم يعني أن غياب إعداد هذه المادة هو خطأ إعداد،
    // لا إذن ضمنياً بتدريسها في كل الصفوف.
    if (_teachersWithSubjectRules.contains(teacherId)) return false;

    // توافق مع بيانات الإصدارات القديمة التي كانت تحدد الصف للمعلم لا للمادة.
    final legacy = _legacyGrades[teacherId];
    if (legacy != null && legacy.isNotEmpty) return legacy.contains(gradeId);

    // إذا كان النظام يستخدم قواعد الصفوف للمادة، فإن عدم وجود قاعدة لهذا
    // المعلم/المادة لا يمنح إذناً ضمنياً، حتى لو كان هذا المعلم لم تُضبط قواعده بعد.
    if (_hasAnySubjectGradeRules) return false;

    // في قواعد البيانات القديمة جداً لم يكن تقييد الصف موجوداً أصلاً.
    return true;
  }

  /// يعيد رسالة رفض عربية، أو null إذا كان الإسناد مسموحاً.
  String? violation({
    required int teacherId,
    required int subjectId,
    required int gradeId,
    String? teacherName,
    String? subjectName,
    String? gradeName,
    String? sectionName,
  }) {
    final teacher = (teacherName ?? '').trim().isEmpty
        ? 'المعلم $teacherId'
        : teacherName!.trim();
    final subject = (subjectName ?? '').trim().isEmpty
        ? 'المادة $subjectId'
        : subjectName!.trim();
    final grade = (gradeName ?? '').trim().isEmpty
        ? (gradeId > 0 ? 'رقم $gradeId' : 'غير محدد')
        : gradeName!.trim();
    final section = (sectionName ?? '').trim();

    if (!isSubjectQualified(teacherId, subjectId)) {
      return '$teacher غير مسجل ضمن المعلمين المؤهلين لمادة $subject${section.isEmpty ? '' : ' في الشعبة $section'}.';
    }
    if (gradeId <= 0) {
      return 'تعذر تحديد الصف الفعلي لمادة $subject${section.isEmpty ? '' : ' في الشعبة $section'}؛ لا يمكن إسناد الحصة قبل تصحيح الصف.';
    }
    if (!isGradeAllowed(teacherId, subjectId, gradeId)) {
      return '$teacher غير مسموح له بتدريس مادة $subject في الصف $grade${section.isEmpty ? '' : '، الشعبة $section'}.';
    }
    return null;
  }
}
