import 'auto_scheduler_service.dart';
import 'constraint_explanation_service.dart';
import 'schedule_improvement_service.dart';

/// Read-only bounded trials, never edits data. Success proves feasibility under
/// the proposed relaxation, not impossibility of the original input or global minimality.
List<ConstraintExplanation> suggestConstraintRelief(
  Map<String, Object?> input,
) {
  final clock = Stopwatch()..start();
  final candidates = <(String, int, String)>[];
  String name(String collection, Object? id) =>
      rows(input[collection])
          .where((e) => e['id'] == id)
          .map((e) => '${e['name'] ?? id}')
          .firstOrNull ??
      '$id';
  for (final key in [
    'subjectBlockedSlots',
    'teacherAvailability',
    'lockedPlacements',
  ]) {
    final values = rows(input[key]);
    for (var i = 0; i < values.length && candidates.length < 18; i++) {
      final e = values[i];
      if (key == 'teacherAvailability' &&
          number(e['is_available'], fallback: 1) != 0)
        continue;
      final label = switch (key) {
        'subjectBlockedSlots' =>
          'السماح للمادة ${name('subjects', e['subject_id'])} في ${name('slots', e['slot_id'])}',
        'teacherAvailability' =>
          'إتاحة المعلم ${name('teachers', e['teacher_id'])} يوم ${name('days', e['day_id'])} في ${name('slots', e['slot_id'])}',
        _ =>
          'فك قفل حصة المادة ${name('subjects', e['subject_id'])} للشعبة ${e['section_id']} يوم ${name('days', e['day_id'])} في ${name('slots', e['slot_id'])}',
      };
      candidates.add((key, i, label));
    }
  }
  final attempts = [
    for (var i = 0; i < candidates.length; i++) [i],
    for (var i = 0; i < candidates.length; i++)
      for (var j = i + 1; j < candidates.length; j++) [i, j],
  ];
  var checked = 0;
  for (final choice in attempts) {
    if (checked >= 36 || clock.elapsedMilliseconds >= 8000) break;
    checked++;
    final trial = Map<String, Object?>.from(input);
    for (final key in [
      'subjectBlockedSlots',
      'teacherAvailability',
      'lockedPlacements',
    ]) {
      final values = rows(input[key]);
      final removed = choice
          .where((i) => candidates[i].$1 == key)
          .map((i) => candidates[i].$2)
          .toSet();
      trial[key] = [
        for (var i = 0; i < values.length; i++)
          if (!removed.contains(i)) values[i],
      ];
    }
    final result = const AutoSchedulerService(nodeLimit: 12000).generate(
      sections: rows(trial['sections']),
      requirements: rows(trial['requirements']),
      teachers: rows(trial['teachers']),
      qualifications: rows(trial['qualifications']),
      teacherGrades: rows(trial['teacherGrades']),
      teacherSubjectGrades: rows(trial['teacherSubjectGrades']),
      days: rows(trial['days']),
      slots: rows(trial['slots']),
      subjectBlockedSlots: rows(trial['subjectBlockedSlots']),
      teacherAvailability: rows(trial['teacherAvailability']),
      lockedPlacements: rows(trial['lockedPlacements']),
      initialPlacements: rows(trial['initialPlacements']),
      feasibilityOnly: true,
      timeLimit: const Duration(milliseconds: 250),
    );
    if (result.complete &&
        ScheduleImprovementService.valid(trial, result.placements)) {
      return [
        ConstraintExplanation(
          code: 'verified_relief',
          title: 'تعديل مقترح اجتاز تجربة توزيع',
          reason:
              'وجدنا جدولاً كاملاً بعد تخفيف ${choice.length} شرط. لم تتغير بياناتك. هذا أول اقتراح ناجح ضمن تجربة محدودة ($checked محاولات)، وليس إثباتاً أن هذه الشروط ضرورية أو أنها أقل تعديل ممكن عالمياً.',
          suggestions: choice.map((i) => candidates[i].$3).toList(),
          proven: false,
        ),
      ];
    }
  }
  return [
    ConstraintExplanation(
      code: 'relief_budget',
      title: 'لم نجد تخفيفاً ناجحاً ضمن وقت التجربة',
      reason:
          'فُحصت $checked تجارب على شروط المنع والإتاحة والأقفال. عدم العثور على حل هنا لا يثبت استحالة الجدول.',
      suggestions: [
        'راجع أسباب السعة والتأهيل المذكورة في الفحص.',
        'جرّب وقت بحث أطول أو راجع أكثر من شرط مرتبط بالمادة نفسها.',
      ],
      proven: false,
    ),
  ];
}
