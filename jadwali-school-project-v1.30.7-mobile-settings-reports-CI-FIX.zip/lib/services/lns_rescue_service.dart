import 'auto_scheduler_service.dart';
import 'schedule_improvement_service.dart';

/// Ruin-and-recreate rescue for a *partial* board.
/// Releases progressively larger neighborhoods (scarce teacher, conflicting
/// section, then the whole week) while preserving user-locked placements.
/// It never changes the database, and never downgrades the best candidate.
class LnsRescueService {
  const LnsRescueService();

  SchedulerResult rescue({
    required Map<String, Object?> input,
    required SchedulerResult seed,
    int nodeLimit = 24000,
    Duration timeLimit = const Duration(seconds: 15),
    void Function(SchedulerResult result, int round)? onImproved,
  }) {
    if (seed.complete || seed.placements.isEmpty) return seed;
    final clock = Stopwatch()..start();
    final requirements = _rows(input['requirements']);
    final sections = _rows(input['sections']);
    final teachers = _rows(input['teachers']);
    final qualifications = _rows(input['qualifications']);
    final grades = _rows(input['teacherGrades']);
    final subjectGrades = _rows(input['teacherSubjectGrades']);
    final days = _rows(input['days']);
    final slots = _rows(input['slots']);
    final unavailable = _rows(input['teacherAvailability'] ?? input['availability']);
    final blocks = _rows(input['subjectBlockedSlots']);
    final originalLocks = _rows(input['lockedPlacements']);
    final lockKeys = originalLocks.map(ScheduleImprovementService.identity).toSet();
    var best = seed;

    final expected = <String, int>{};
    for (final req in requirements) {
      final key = '${_num(req['section_id'])}:${_num(req['subject_id'])}';
      expected[key] = (expected[key] ?? 0) + _num(req['weekly_lessons']);
    }
    List<Map<String, Object?>> missing(List<Map<String, Object?>> board) {
      final actual = <String, int>{};
      for (final row in board) {
        final key = '${_num(row['section_id'])}:${_num(row['subject_id'])}';
        actual[key] = (actual[key] ?? 0) + 1;
      }
      return requirements.where((r) {
        final key = '${_num(r['section_id'])}:${_num(r['subject_id'])}';
        return (actual[key] ?? 0) < (expected[key] ?? 0);
      }).toList();
    }

    for (var round = 0; round < 3; round++) {
      if (clock.elapsed >= timeLimit || best.complete) break;
      final deficits = missing(best.placements);
      final difficultSections = deficits.map((r) => _num(r['section_id'])).toSet();
      final difficultSubjects = deficits.map((r) => _num(r['subject_id'])).toSet();
      final difficultTeachers = <int>{};
      for (final q in qualifications) {
        if (difficultSubjects.contains(_num(q['subject_id']))) {
          difficultTeachers.add(_num(q['teacher_id']));
        }
      }
      // Round 1: free rows belonging to missing sections and scarce teachers.
      // Round 2: also free sections affected by those teachers.
      // Round 3: restart the entire search, retaining only explicit locks.
      final widerSections = <int>{...difficultSections};
      if (round >= 1) {
        for (final row in best.placements) {
          if (difficultTeachers.contains(_num(row['teacher_id']))) {
            widerSections.add(_num(row['section_id']));
          }
        }
      }
      final pinned = best.placements.where((row) {
        if (lockKeys.contains(ScheduleImprovementService.identity(row))) return true;
        if (round == 2) return false;
        return !widerSections.contains(_num(row['section_id'])) &&
            !difficultTeachers.contains(_num(row['teacher_id']));
      }).toList();
      // Exact identities are checked when locking, and a user lock cannot be
      // removed even if an incomplete board did not happen to include it.
      final pinnedKeys = pinned.map(ScheduleImprovementService.identity).toSet();
      for (final lock in originalLocks) {
        if (pinnedKeys.add(ScheduleImprovementService.identity(lock))) {
          pinned.add(lock);
        }
      }
      final remaining = timeLimit - clock.elapsed;
      if (remaining <= Duration.zero) break;
      final candidate = AutoSchedulerService(
        nodeLimit: ((nodeLimit * (round + 1)) ~/ 3).clamp(200, 100000).toInt(),
      ).generate(
        sections: sections,
        requirements: requirements,
        teachers: teachers,
        qualifications: qualifications,
        teacherGrades: grades,
        teacherSubjectGrades: subjectGrades,
        subjectBlockedSlots: blocks,
        days: days,
        slots: slots,
        teacherAvailability: unavailable,
        initialPlacements: best.placements,
        lockedPlacements: pinned,
        preference: 'minimal_changes',
        feasibilityOnly: true,
        timeLimit: remaining > const Duration(seconds: 6)
            ? const Duration(seconds: 6) : remaining,
      );
      // A complete board must pass the independent validator. Partial boards
      // can improve the retained bound but may never be silently 'approved'.
      final improved = (candidate.placements.length > best.placements.length) &&
          (!candidate.complete || ScheduleImprovementService.valid(input, candidate.placements));
      if (improved) {
        best = candidate;
        onImproved?.call(best, round + 1);
      }
    }
    return best;
  }
}

List<Map<String, Object?>> _rows(Object? value) => value is List
    ? value.map((row) => Map<String, Object?>.from(row as Map)).toList()
    : <Map<String, Object?>>[];

int _num(Object? v) => v is num ? v.toInt() : int.tryParse('$v') ?? 0;
