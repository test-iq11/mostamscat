import 'dart:convert';

/// Shared grade/day period limits, used by scheduling, repair, reports, and
/// conflict checks. Stored day IDs are database IDs, not day-of-week indices.
class SchoolTimetablePolicy {
  const SchoolTimetablePolicy._();

  static bool isSixthGrade(Map<String, Object?> section) {
    final name = _normalize(section['grade_name'] ?? section['grade'] ?? section['name']);
    if (name.contains('السادس') || name.contains('سادس') ||
        name == '6' || name == '٦' || name == 'sixth' ||
        name == 'sixth grade' || name == 'grade 6' || name == 'grade6' ||
        name.contains('الصف 6') || name.contains('الصف ٦')) return true;
    final position = _int(section['grade_position'], fallback: -1);
    return name.isEmpty && position == 5;
  }

  static bool isSunday(Map<String, Object?> day) {
    final name = _normalize(day['name']);
    if (name.isNotEmpty) {
      return name == 'الاحد' || name.startsWith('الاحد ') || name == 'sunday';
    }
    return _int(day['id'], fallback: -1) == 1 ||
        _int(day['position'], fallback: -1) == 0;
  }

  /// An explicit value of zero is valid: that grade has no lessons that day.
  /// Missing overrides retain the previous six-period scheduling semantics.
  static int? configuredDayLimit({
    required Map<String, Object?> section,
    required Map<String, Object?> day,
  }) {
    final raw = section['daily_limits_json'];
    if (raw == null || '$raw'.trim().isEmpty) return null;
    try {
      final decoded = raw is Map ? raw : jsonDecode('$raw');
      if (decoded is! Map) return null;
      final key = '${_int(day['id'], fallback: -1)}';
      if (!decoded.containsKey(key)) return null;
      final value = _int(decoded[key], fallback: -1);
      return value >= 0 && value <= 7 ? value : null;
    } catch (_) {
      return null;
    }
  }

  /// Effective per-grade, per-weekday limit including any user overrides.
  /// Seven is the maximum supported active lesson rank in this project.
  static int dailyLimit({
    required Map<String, Object?> section,
    required Map<String, Object?> day,
    required List<Map<String, Object?>> activeDays,
    required List<Map<String, Object?>> lessonSlots,
    required int weeklyDemand,
  }) {
    final explicit = configuredDayLimit(section: section, day: day);
    final count = lessonSlots.length < 7 ? lessonSlots.length : 7;
    final normal = normalDailyLimit(
        section: section, lessonSlotCount: lessonSlots.length);
    // Preserve the established safety rule for the special sixth-grade Sunday:
    // its seventh period is available only if the weekly demand cannot fit
    // the other configured days plus six ordinary Sunday periods.
    if (isSixthGrade(section) && isSunday(day) &&
        (explicit == 7 || (explicit == null && normal >= 6)) &&
        count >= 7) {
      final ordinaryWeekly = activeDays.fold<int>(0, (sum, candidateDay) {
        final candidateOverride = configuredDayLimit(
            section: section, day: candidateDay);
        return sum + ((candidateOverride ?? normal).clamp(0, 6).toInt());
      });
      return weeklyDemand > ordinaryWeekly ? 7 : 6;
    }
    if (explicit != null) return explicit.clamp(0, count).toInt();
    return normal;
  }

  /// Explicit weekday settings define the available school periods. Legacy
  /// max_daily_lessons is a count quota, not a requirement to start at period 1.
  static int periodLimit({
    required Map<String, Object?> section,
    required Map<String, Object?> day,
    required List<Map<String, Object?>> activeDays,
    required List<Map<String, Object?>> lessonSlots,
    required int weeklyDemand,
  }) => dailyLimit(
    section: configuredDayLimit(section: section, day: day) != null
        ? section : {...section, 'max_daily_lessons': 6},
    day: day, activeDays: activeDays, lessonSlots: lessonSlots,
    weeklyDemand: weeklyDemand,
  );

  static bool canUseSeventhPeriod({
    required Map<String, Object?> section,
    required Map<String, Object?> day,
    required List<Map<String, Object?>> activeDays,
    required List<Map<String, Object?>> lessonSlots,
    required int weeklyDemand,
  }) => dailyLimit(
    section: section, day: day, activeDays: activeDays,
    lessonSlots: lessonSlots, weeklyDemand: weeklyDemand,
  ) >= 7;

  static int normalDailyLimit({
    required Map<String, Object?> section,
    required int lessonSlotCount,
  }) {
    final configured = _int(section['max_daily_lessons'], fallback: 6);
    final effective = configured > 0 && configured < lessonSlotCount
        ? configured : lessonSlotCount;
    return effective < 6 ? effective : 6;
  }

  static int weeklyCapacity({
    required Map<String, Object?> section,
    required List<Map<String, Object?>> activeDays,
    required List<Map<String, Object?>> lessonSlots,
    required int weeklyDemand,
  }) => activeDays.fold<int>(0, (total, day) => total + dailyLimit(
    section: section, day: day, activeDays: activeDays,
    lessonSlots: lessonSlots, weeklyDemand: weeklyDemand,
  ));

  static String _normalize(Object? value) {
    var text = (value ?? '').toString().trim().toLowerCase();
    text = text.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '');
    text = text.replaceAll(RegExp(r'[أإآٱ]'), 'ا');
    text = text.replaceAll('ى', 'ي');
    return text.trim();
  }

  static int _int(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
