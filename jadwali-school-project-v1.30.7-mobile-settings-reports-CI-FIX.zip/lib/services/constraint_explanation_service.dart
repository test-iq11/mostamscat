import 'teacher_availability_policy.dart';
import '../core/timetable_ordering.dart';
import 'conflict_detection_service.dart';
import 'required_repeat_policy.dart';
import 'school_timetable_policy.dart';
import 'teacher_assignment_policy.dart';
import 'teacher_capacity_flow.dart';
import 'teacher_timetable_capacity.dart';
import 'mandatory_period_capacity.dart';

/// A verified capacity contradiction, or a clearly labelled search advisory.
/// These explanations do not claim to identify a minimal unsatisfiable core.
class ConstraintExplanation {
  ConstraintExplanation({
    required this.code,
    required this.title,
    required this.reason,
    required List<String> suggestions,
    List<int> affectedSectionIds = const [],
    List<int> affectedTeacherIds = const [],
    this.proven = true,
  }) : suggestions = List.unmodifiable(suggestions),
       affectedSectionIds = List.unmodifiable(affectedSectionIds.toSet()),
       affectedTeacherIds = List.unmodifiable(affectedTeacherIds.toSet());

  final String code;
  final String title;
  final String reason;
  final List<String> suggestions;
  final List<int> affectedSectionIds;
  final List<int> affectedTeacherIds;
  final bool proven;

  Map<String, Object?> toMap() => {
    'code': code,
    'title': title,
    'reason': reason,
    'suggestions': suggestions,
    'affectedSectionIds': affectedSectionIds,
    'affectedTeacherIds': affectedTeacherIds,
    'proven': proven,
  };

  factory ConstraintExplanation.fromMap(Map<String, Object?> row) =>
      ConstraintExplanation(
        code: '${row['code'] ?? ''}',
        title: '${row['title'] ?? ''}',
        reason: '${row['reason'] ?? ''}',
        suggestions: (row['suggestions'] as List? ?? const [])
            .map((s) => '$s')
            .toList(),
        affectedSectionIds: (row['affectedSectionIds'] as List? ?? const [])
            .map(_int)
            .toList(),
        affectedTeacherIds: (row['affectedTeacherIds'] as List? ?? const [])
            .map(_int)
            .toList(),
        proven: row['proven'] == true,
      );
}

class ConstraintExplanationService {
  const ConstraintExplanationService();

  /// Accepts the scheduler's input collections. Optional searchLimitReached
  /// adds an advisory; exhaustion alone never becomes an impossibility proof.
  List<ConstraintExplanation> explain(Map<String, Object?> input) {
    final sections = _rows(input['sections']);
    final requirements = _rows(input['requirements']);
    final teachers = _rows(input['teachers']);
    final qualifications = _rows(input['qualifications']);
    final teacherGrades = _rows(input['teacherGrades']);
    final teacherSubjectGrades = _rows(input['teacherSubjectGrades']);
    final blockedRows = _rows(input['subjectBlockedSlots']);
    final availability = _rows(
      input['teacherAvailability'] ?? input['availability'],
    );
    final locks = _rows(input['lockedPlacements']);
    final days =
        _rows(input['days'])
            .where((r) => _int(r['is_active'], fallback: 1) == 1)
            .toList()
          ..sort(TimetableOrdering.compare);
    final slots =
        _rows(input['slots'])
            .where(
              (r) =>
                  r['kind'] == 'lesson' &&
                  _int(r['is_available'], fallback: 1) == 1,
            )
            .toList()
          ..sort(TimetableOrdering.compare);
    final sectionById = {for (final r in sections) _int(r['id']): r};
    final teacherById = {for (final r in teachers) _int(r['id']): r};
    final blocked = {
      for (final row in blockedRows)
        '${_int(row['subject_id'])}:${_int(row['slot_id'])}',
    };
    final availabilityPolicy = TeacherAvailabilityPolicy(availability);
    final policy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
    );
    final explanations = <ConstraintExplanation>[];
    final seen = <String>{};
    void add(ConstraintExplanation item) {
      if (seen.add(item.code)) explanations.add(item);
    }

    for (final shortage in const MandatoryPeriodCapacity().inspect(input)) {
      add(
        ConstraintExplanation(
          code: 'mandatory_period_${shortage['dayId']}_${shortage['slotId']}',
          title:
              'نقص معلمين متزامنين: ${shortage['dayName']}، ${shortage['slotName']}',
          reason:
              'تحتاج ${shortage['required']} شعب إلى حصص متزامنة في هذه الفترة لأن خاناتها الأسبوعية ممتلئة، لكن التأهيل والإتاحة وقيود المواد تسمح بإسناد ${shortage['capacity']} فقط. نقل الحصص بين الأيام وحده لا يزيل هذا النقص.',
          suggestions: [
            'راجع منع المواد في هذه الفترة أو إتاحة المعلمين ومؤهلاتهم الفعلية.',
            'راجع عدد الحصص المطلوبة والخانات المسموحة للصفوف. لا يُغيَّر أي شرط تلقائياً.',
          ],
          affectedSectionIds: (shortage['sectionIds'] as List).cast<int>(),
          affectedTeacherIds: (shortage['teacherIds'] as List).cast<int>(),
        ),
      );
    }
    final positive = requirements
        .where((r) => _int(r['weekly_lessons']) > 0)
        .toList();
    final sectionDemand = <int, int>{};
    for (final req in positive) {
      final id = _int(req['section_id']);
      sectionDemand[id] =
          (sectionDemand[id] ?? 0) + _int(req['weekly_lessons']);
    }
    if (positive.isNotEmpty && days.isEmpty) {
      add(
        ConstraintExplanation(
          code: 'no_active_days',
          title: 'لا توجد أيام دوام',
          reason: 'توجد حصص مطلوبة ولا يوجد يوم دوام مفعّل لوضعها فيه.',
          suggestions: ['فعّل يوم دوام واحداً على الأقل من إعدادات المدرسة.'],
        ),
      );
    }
    if (positive.isNotEmpty && slots.isEmpty) {
      add(
        ConstraintExplanation(
          code: 'no_lesson_slots',
          title: 'لا توجد فترات تدريس متاحة',
          reason:
              'توجد حصص مطلوبة ولكن جميع الفترات معطلة أو ليست حصصاً دراسية.',
          suggestions: ['فعّل فترة من نوع «حصة دراسية» أو أضف فترات الدوام.'],
        ),
      );
    }
    for (final entry in sectionDemand.entries) {
      final section = sectionById[entry.key];
      if (section == null) {
        add(
          ConstraintExplanation(
            code: 'unknown_section:${entry.key}',
            title: 'متطلب مربوط بشعبة غير موجودة',
            reason:
                'توجد ${entry.value} حصة مطلوبة للشعبة رقم ${entry.key}، لكنها غير مسجلة.',
            suggestions: ['صحح شعبة المتطلب أو أعد إنشاء الشعبة قبل التوزيع.'],
            affectedSectionIds: [entry.key],
          ),
        );
        continue;
      }
      final capacity = SchoolTimetablePolicy.weeklyCapacity(
        section: section,
        activeDays: days,
        lessonSlots: slots,
        weeklyDemand: entry.value,
      );
      if (entry.value > capacity) {
        add(
          ConstraintExplanation(
            code: 'section_capacity:${entry.key}',
            title: 'متطلبات الشعبة تتجاوز خاناتها',
            reason:
                '${_sectionLabel(section)} تحتاج ${entry.value} حصة، والمتاح وفق أيام الدوام والفترات والحد اليومي $capacity فقط؛ النقص ${entry.value - capacity}.',
            suggestions: [
              'خفض المتطلبات بمقدار ${entry.value - capacity} حصة على الأقل إن كانت مسجلة خطأً.',
              'أو أتح أياماً وفترات إضافية يسمح بها نظام المدرسة؛ السابعة تبقى استثناء السادس يوم الأحد.',
            ],
            affectedSectionIds: [entry.key],
          ),
        );
      }
    }

    final eligibleByRequirement = <List<int>>[];
    final mandatory = <int, int>{};
    final mandatorySections = <int, Set<int>>{};
    for (final req in positive) {
      final sectionId = _int(req['section_id']);
      final subjectId = _int(req['subject_id']);
      final section = sectionById[sectionId];
      final eligible =
          teachers
              .where(
                (teacher) =>
                    section != null &&
                    policy.isSubjectQualified(_int(teacher['id']), subjectId) &&
                    policy.isGradeAllowed(
                      _int(teacher['id']),
                      subjectId,
                      _int(section['grade_id']),
                    ),
              )
              .map((t) => _int(t['id']))
              .toSet()
              .toList()
            ..sort();
      eligibleByRequirement.add(eligible);
      if (section == null) continue;
      final subjectName = '${req['subject_name'] ?? 'المادة $subjectId'}';
      final label = '${_sectionLabel(section)}، $subjectName';
      final weekly = _int(req['weekly_lessons']);
      if (eligible.isEmpty) {
        final subjectQualified = teachers
            .where((t) => policy.isSubjectQualified(_int(t['id']), subjectId))
            .map((t) => _int(t['id']))
            .toList();
        add(
          ConstraintExplanation(
            code: 'no_qualified_teacher:$sectionId:$subjectId',
            title: 'لا يوجد معلم مؤهل لهذا الصف والمادة',
            reason:
                '$label: المطلوب $weekly حصص، ولا يوجد معلم يحقق اختصاص المادة وصلاحية تدريس الصف معاً.',
            suggestions: subjectQualified.isEmpty
                ? ['أضف معلماً مؤهلاً للمادة وحدد صفوفه المسموحة.']
                : [
                    'راجع صفوف تدريس هذه المادة لدى المعلمين المؤهلين لها؛ لا يكفي السماح بالصف لمادة أخرى.',
                  ],
            affectedSectionIds: [sectionId],
            affectedTeacherIds: subjectQualified,
          ),
        );
      } else if (eligible.length == 1) {
        final id = eligible.single;
        mandatory[id] = (mandatory[id] ?? 0) + weekly;
        (mandatorySections[id] ??= <int>{}).add(sectionId);
      }
      if (days.isEmpty || slots.isEmpty) continue;
      final lateRepeat = RequiredRepeatPolicy.allowsLatePeriodRepeat(
        requirement: req,
        section: section,
        activeDays: days,
        sectionWeeklyDemand: sectionDemand[sectionId] ?? 0,
        lessonSlots: slots,
        subjectBlockedSlots: blockedRows,
      );
      final repeatAllowed = _int(req['allow_same_day']) == 1;
      final configuredDaily = _int(req['max_daily_lessons'], fallback: 2);
      final subjectDaily = repeatAllowed
          ? (configuredDaily > 0 ? configuredDaily : 1)
          : (lateRepeat ? 2 : 1);
      var ruleUpper = 0;
      var availableUpper = 0;
      final unreachableDays = <String>[];
      for (final day in days) {
        final dayLimit = SchoolTimetablePolicy.dailyLimit(
          section: section, day: day, activeDays: days,
          lessonSlots: slots,
          weeklyDemand: sectionDemand[sectionId] ?? 0,
        );
        final possibleRanks = <int>[];
        final teacherRanks = <int>[];
        for (var rank = 0; rank < slots.length; rank++) {
          if (rank >= SchoolTimetablePolicy.periodLimit(
              section: section, day: day, activeDays: days,
              lessonSlots: slots,
              weeklyDemand: sectionDemand[sectionId] ?? 0)) continue;
          final slotId = _int(slots[rank]['id']);
          if (blocked.contains('$subjectId:$slotId')) continue;
          possibleRanks.add(rank);
          if (eligible.any(
            (id) => availabilityPolicy.isAvailable(
              teacherId: id,
              dayId: _int(day['id']),
              slotId: slotId,
              gradeId: _int(section['grade_id']),
              subjectId: subjectId,
            ),
          ))
            teacherRanks.add(rank);
        }
        int dailyUpper(List<int> ranks) {
          var limit = ranks.length < subjectDaily ? ranks.length : subjectDaily;
          final dayQuota = dayLimit;
          if (limit > dayQuota) limit = dayQuota;
          if (!repeatAllowed &&
              lateRepeat &&
              limit > 1 &&
              (!ranks.any((r) => r < 5) || !ranks.any((r) => r >= 5)))
            limit = 1;
          return limit;
        }

        ruleUpper += dailyUpper(possibleRanks);
        availableUpper += dailyUpper(teacherRanks);
        if (teacherRanks.isEmpty && eligible.isNotEmpty)
          unreachableDays.add('${day['name'] ?? day['id']}');
      }
      if (weekly > ruleUpper) {
        final necessaryRepeatMissing =
            !repeatAllowed && weekly > days.length && !lateRepeat;
        add(
          ConstraintExplanation(
            code: 'subject_period_capacity:$sectionId:$subjectId',
            title: necessaryRepeatMissing
                ? 'التكرار الضروري لا يملك فترة مسموحة'
                : 'الفترات المسموحة لا تكفي للمادة',
            reason:
                '$label: المطلوب $weekly حصص في ${days.length} أيام، لكن الحد الممكن بالقواعد والفترات الحالية $ruleUpper فقط.'
                '${necessaryRepeatMissing ? ' التكرار العادي ممنوع، والاستثناء يحتاج فترة مبكرة مع السادسة أو السابعة المسموحة.' : ''}',
            suggestions: necessaryRepeatMissing
                ? [
                    'أتح السادسة أو السابعة إذا كانت مسموحة للشعبة واجعلها غير ممنوعة للمادة، مع فترة مبكرة متاحة.',
                    'أو اسمح بالتكرار العادي لهذه المادة إذا كانت سياسة المدرسة تسمح بذلك.',
                  ]
                : [
                    'أتح فترة إضافية لهذه المادة أو صحح الحد اليومي/المتطلب الأسبوعي إذا كان مسجلاً خطأً.',
                  ],
            affectedSectionIds: [sectionId],
            affectedTeacherIds: eligible,
          ),
        );
      } else if (eligible.isNotEmpty && weekly > availableUpper) {
        add(
          ConstraintExplanation(
            code: 'subject_teacher_availability:$sectionId:$subjectId',
            title: 'إتاحة معلمي المادة لا تغطي المطلوب',
            reason:
                '$label: المطلوب $weekly حصص، واتحاد خانات إتاحة المعلمين المؤهلين يسمح بحد أقصى $availableUpper فقط قبل احتساب أي تعارض مع الشعب الأخرى.',
            suggestions: [
              'أتح ${weekly - availableUpper} خانة مناسبة إضافية على الأقل أو أضف معلماً مؤهلاً بديلاً لهذه المادة والصف.',
            ],
            affectedSectionIds: [sectionId],
            affectedTeacherIds: eligible,
          ),
        );
      }
      if (weekly >= 5 && (weekly < days.length || unreachableDays.isNotEmpty)) {
        add(
          ConstraintExplanation(
            code: 'daily_coverage:$sectionId:$subjectId',
            title: 'لا يمكن تغطية جميع أيام الدوام',
            reason: weekly < days.length
                ? '$label: قاعدة المواد ذات خمس حصص أو أكثر تتطلب الظهور في كل يوم، لكن $weekly حصص لا تغطي ${days.length} أيام.'
                : '$label: لا توجد خانة ومعلم مؤهل متاحان في ${unreachableDays.join('، ')}، مع اشتراط حصة في كل يوم.',
            suggestions: [
              'راجع متطلب المادة وأيام الدوام، أو أتح معلماً مؤهلاً وفترة مسموحة في اليوم الناقص.',
            ],
            affectedSectionIds: [sectionId],
            affectedTeacherIds: eligible,
          ),
        );
      }
    }

    // Capacity is deliberately optimistic: it ignores inter-subject and
    // inter-section collisions. Insufficiency proves a conflict; sufficiency does not
    // prove that the complete timetable exists.
    final teacherCapacity = const TeacherTimetableCapacity().calculate(
      teachers: teachers,
      sections: sections,
      requirements: positive,
      qualifications: qualifications,
      teacherGrades: teacherGrades,
      teacherSubjectGrades: teacherSubjectGrades,
      days: days,
      slots: slots,
      subjectBlockedSlots: blockedRows,
      teacherAvailability: availability,
    );
    for (final teacher in teachers) {
      final id = _int(teacher['id']);
      final needed = mandatory[id] ?? 0;
      final mandatoryRequirements = <Map<String, Object?>>[
        for (var i = 0; i < positive.length; i++)
          if (eligibleByRequirement[i].length == 1 &&
              eligibleByRequirement[i].single == id)
            positive[i],
      ];
      final mandatoryCapacity = const TeacherTimetableCapacity().calculate(
        teachers: [teacher],
        sections: sections,
        requirements: mandatoryRequirements,
        qualifications: qualifications,
        teacherGrades: teacherGrades,
        teacherSubjectGrades: teacherSubjectGrades,
        days: days,
        slots: slots,
        subjectBlockedSlots: blockedRows,
        teacherAvailability: availability,
        sectionWeeklyDemand: sectionDemand,
      )[id]!;
      if (needed > mandatoryCapacity) {
        add(
          ConstraintExplanation(
            code: 'mandatory_teacher_capacity:$id',
            title: 'خانات المعلم الوحيد لا تكفي',
            reason:
                '${teacher['name'] ?? 'المعلم $id'} هو الوحيد المؤهل لمتطلبات مجموعها $needed حصة، بينما الفترات المسموحة لمواده وصفوفه والنصاب والإتاحة وحد الحصص المتتالية تسمح بحد أقصى $mandatoryCapacity حصة؛ النقص ${needed - mandatoryCapacity}.',
            suggestions: [
              'أضف معلماً مؤهلاً بديلاً لبعض هذه الشعب.',
              'أو أتح فترة ممنوعة لمادة يدرّسها، أو صحح النصاب/الإتاحة/حد التتابع إذا كانت مسجلة خطأً؛ زيادة النصاب وحدها لا تضيف خانات زمنية.',
            ],
            affectedSectionIds: (mandatorySections[id] ?? const <int>{})
                .toList(),
            affectedTeacherIds: [id],
          ),
        );
      }
    }
    if (positive.isNotEmpty &&
        days.isNotEmpty &&
        slots.isNotEmpty &&
        eligibleByRequirement.every((ids) => ids.isNotEmpty)) {
      final total = positive.fold<int>(
        0,
        (sum, r) => sum + _int(r['weekly_lessons']),
      );
      final maximum = TeacherCapacityFlow.maximum(
        demand: positive.map((r) => _int(r['weekly_lessons'])).toList(),
        eligibleTeachers: eligibleByRequirement,
        capacity: teacherCapacity,
      );
      if (maximum < total) {
        final involvedTeachers =
            eligibleByRequirement.expand((ids) => ids).toSet().toList()..sort();
        add(
          ConstraintExplanation(
            code: 'shared_teacher_capacity',
            title: 'سعة المعلمين المشتركين أقل من المتطلبات',
            reason:
                'حتى مع تجاهل تعارضات الخانات، يمكن إسناد $maximum من أصل $total حصة فقط إلى المعلمين المؤهلين ضمن الأنصبة والإتاحة. توجد فجوة لا تقل عن ${total - maximum} حصة. هذا الحد يأخذ اختصاص المادة وصلاحية تدريس الصف في الحسبان.',
            suggestions: [
              'أضف معلماً بديلاً مؤهلاً للمواد والصفوف المقيدة، أو راجع أنصبة وإتاحة المعلمين المرتبطين بها.',
            ],
            affectedSectionIds: positive
                .map((r) => _int(r['section_id']))
                .toSet()
                .toList(),
            affectedTeacherIds: involvedTeachers,
          ),
        );
      }
    }

    if (locks.isNotEmpty) {
      final reqKeys = {
        for (final r in requirements)
          '${_int(r['section_id'])}:${_int(r['subject_id'])}',
      };
      for (final lock in locks) {
        final sectionId = _int(lock['section_id']);
        final teacherId = _int(lock['teacher_id']);
        if (!sectionById.containsKey(sectionId) ||
            !reqKeys.contains('$sectionId:${_int(lock['subject_id'])}') ||
            !teacherById.containsKey(teacherId)) {
          add(
            ConstraintExplanation(
              code:
                  'lock_unknown:$sectionId:$teacherId:${_int(lock['subject_id'])}',
              title: 'حصة مثبتة مرتبطة ببيانات غير موجودة',
              reason:
                  'الحصة المثبتة للشعبة $sectionId لا تطابق شعبة ومتطلباً ومعلمًا مسجلين معاً.',
              suggestions: ['ألغ تثبيت هذه الحصة أو صحح بياناتها قبل البحث.'],
              affectedSectionIds: [sectionId],
              affectedTeacherIds: [teacherId],
            ),
          );
        }
      }
      // A stale database ID must never hide two contradictory pinned rows.
      final lockRows = locks
          .map((row) => Map<String, Object?>.from(row)..remove('id'))
          .toList();
      final lockIssues = const ConflictDetectionService().scan(
        entries: lockRows,
        requirements: requirements,
        sections: sections,
        slots: _rows(input['slots']),
        teachers: teachers,
        qualifications: qualifications,
        days: _rows(input['days']),
        teacherGrades: teacherGrades,
        teacherSubjectGrades: teacherSubjectGrades,
        subjectBlockedSlots: blockedRows,
        teacherAvailability: availability,
      );
      const ignoredPartial = {
        'نقص الحصص',
        'توزيع المادة على كل أيام الأسبوع',
        'تكرار توقيت المادة في أيام متتالية',
        'الحصص المطلوبة تتجاوز سعة الشعبة',
      };
      for (final issue in lockIssues) {
        if (ignoredPartial.contains(issue.type)) continue;
        add(
          ConstraintExplanation(
            code:
                'locked:${issue.type}:${issue.sectionId}:${issue.teacherId}:${issue.dayId}:${issue.slotId}:${issue.subjectId}',
            title: 'تثبيت يمنع الحل: ${issue.type}',
            reason: issue.message,
            suggestions: [
              'ألغ تثبيت إحدى الحصص المرتبطة أو عدل القيد الذي يتعارض معها؛ لن يحركها البحث وهي مثبتة.',
              if (issue.suggestion != null) issue.suggestion!,
            ],
            affectedSectionIds: [if (issue.sectionId != null) issue.sectionId!],
            affectedTeacherIds: [if (issue.teacherId != null) issue.teacherId!],
          ),
        );
      }
      for (final req in positive.where((r) => _int(r['weekly_lessons']) >= 5)) {
        final sectionId = _int(req['section_id']),
            subjectId = _int(req['subject_id']);
        final same = locks
            .where(
              (e) =>
                  _int(e['section_id']) == sectionId &&
                  _int(e['subject_id']) == subjectId,
            )
            .toList();
        final missingDays = days
            .where((d) => !same.any((e) => _int(e['day_id']) == _int(d['id'])))
            .length;
        final remaining = _int(req['weekly_lessons']) - same.length;
        if (remaining >= 0 && remaining < missingDays) {
          add(
            ConstraintExplanation(
              code: 'locked_daily_coverage:$sectionId:$subjectId',
              title: 'التثبيت يمنع توزيع المادة على كل الأيام',
              reason:
                  'بعد تثبيت ${same.length} حصص لهذه المادة، تبقى $remaining حصص لتغطية $missingDays أيام فارغة. لا يمكن بلوغ التغطية اليومية المطلوبة دون تحرير حصة مثبتة.',
              suggestions: ['ألغ تثبيت حصة من يوم به تكرار، ثم أعد التوزيع.'],
              affectedSectionIds: [sectionId],
              affectedTeacherIds: same
                  .map((e) => _int(e['teacher_id']))
                  .toList(),
            ),
          );
        }
      }
    }
    if (input['searchLimitReached'] == true) {
      add(
        ConstraintExplanation(
          code: 'search_limit',
          title: 'انتهت مدة البحث دون إثبات الاستحالة',
          reason: 'لم يعثر البحث المحدود على جدول كامل. هذه النتيجة لا تثبت أن الشروط متناقضة، وقد تنجح مواصلة البحث أو ترتيب آخر.',
          suggestions: [
            'واصل البحث مدة أطول مع الاحتفاظ بأفضل نتيجة.',
            'راجع الحصص المثبتة والإتاحة والفترات الممنوعة، واختر تحرير قيد محدد عند الحاجة.',
          ],
          proven: false,
        ),
      );
    }
    return List.unmodifiable(explanations);
  }
}

List<Map<String, Object?>> _rows(Object? value) => (value as List? ?? const [])
    .whereType<Map>()
    .map((row) => Map<String, Object?>.from(row))
    .toList();
int _int(Object? value, {int fallback = 0}) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
String _sectionLabel(Map<String, Object?> row) {
  final grade = '${row['grade_name'] ?? ''}'.trim();
  return '${grade.isEmpty ? '' : '$grade، '}الشعبة ${row['section_name'] ?? row['name'] ?? row['id']}';
}
