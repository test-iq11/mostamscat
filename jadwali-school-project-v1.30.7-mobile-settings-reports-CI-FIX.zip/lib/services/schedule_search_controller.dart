import 'dart:async';
import 'dart:isolate';

import 'auto_scheduler_service.dart';
import 'schedule_improvement_service.dart';
import 'unified_schedule_service.dart';

/// A top-level isolate entry point can be injected for lifecycle tests.
typedef ScheduleSearchWorker = void Function(List<Object?> arguments);

/// Runs a synchronous search off the UI isolate. Stopping kills only this
/// worker, retaining its last published best board for independent approval.
class ScheduleSearchController {
  ScheduleSearchController({ScheduleSearchWorker? worker})
    : _worker = worker ?? _runScheduleSearch;

  final ScheduleSearchWorker _worker;
  final _events = StreamController<Map<String, Object?>>.broadcast();
  final _clock = Stopwatch();
  Isolate? _isolate;
  ReceivePort? _port;
  StreamSubscription<dynamic>? _subscription;
  Completer<List<Map<String, Object?>>>? _pending;
  Map<String, Object?>? _input;
  Map<String, Object?>? _bestSnapshot;
  List<String> _profiles = const ['minimal_changes'];
  List<Map<String, Object?>> _solutions = [];
  int _generation = 0;
  int _nodeBudget = 600000;
  bool _running = false;
  bool _disposed = false;

  Stream<Map<String, Object?>> get events => _events.stream;
  bool get isRunning => _running;
  int get elapsedMilliseconds => _clock.elapsedMilliseconds;
  List<Map<String, Object?>> get bestSolutions =>
      _solutions.map(_copyMap).toList();

  Future<List<Map<String, Object?>>> start(
    Map<String, Object?> input, {
    List<String> profiles = const ['minimal_changes'],
  }) {
    if (_disposed) throw StateError('أُغلق البحث بالفعل.');
    if (_running) throw StateError('يوجد بحث جارٍ بالفعل.');
    _input = _copyMap(input);
    _profiles = profiles.where(_profileLabels.containsKey).toSet().toList();
    if (_profiles.isEmpty) _profiles = ['minimal_changes'];
    _nodeBudget = _int(input['nodeLimit'], fallback: 600000).clamp(1, 2000000);
    _solutions = [];
    _bestSnapshot = null;
    _running = true;
    _clock
      ..reset()
      ..start();
    final token = ++_generation;
    final pending = Completer<List<Map<String, Object?>>>();
    _pending = pending;
    final port = ReceivePort();
    _port = port;
    _subscription = port.listen((message) => _receive(message, token));
    _emit({
      'type': 'starting',
      'bestCount': 0,
      'requestedCount': _requestedCount,
      'elapsedMs': 0,
    });
    unawaited(_spawn(port.sendPort, token));
    return pending.future;
  }

  Future<void> _spawn(SendPort output, int token) async {
    try {
      final isolate = await Isolate.spawn<List<Object?>>(
        _worker,
        [
          output,
          {'input': _input, 'profiles': _profiles, 'nodeLimit': _nodeBudget},
        ],
        onError: output,
        onExit: output,
        errorsAreFatal: true,
        debugName: 'jadwali-schedule-search',
      );
      if (!_running || token != _generation || _disposed) {
        isolate.kill(priority: Isolate.immediate);
      } else {
        _isolate = isolate;
      }
    } catch (error, stack) {
      if (_running && token == _generation) _fail(error, stack);
    }
  }

  void _receive(dynamic message, int token) {
    if (!_running || token != _generation || _disposed) return;
    if (message == null) {
      // Normal workers send `done` before exiting on this same port.
      _fail(
        StateError('انتهت عملية البحث دون إعادة نتيجة.'),
        StackTrace.current,
      );
      return;
    }
    if (message is List && message.length >= 2) {
      _fail(
        StateError('${message[0]}'),
        StackTrace.fromString('${message[1]}'),
      );
      return;
    }
    if (message is! Map) return;
    final event = Map<String, Object?>.from(message);
    event['elapsedMs'] = _clock.elapsedMilliseconds;
    switch (event['type']) {
      case 'progress':
        final entries = _rows(event['placements']);
        if (_bestSnapshot == null ||
            entries.length >= _rows(_bestSnapshot!['placements']).length) {
          _bestSnapshot = _copyMap(event);
        }
        final retained = _bestSnapshot;
        _emit(
          retained != null &&
                  _rows(retained['placements']).length > entries.length
              ? {
                  ...event,
                  'placements': retained['placements'],
                  'bestCount': _rows(retained['placements']).length,
                }
              : event,
        );
      case 'solution':
        final solution = _copyMap(event)..remove('type');
        final previous = _solutions
            .where((value) => value['profile'] == solution['profile'])
            .firstOrNull;
        final keepPrevious =
            previous != null &&
            ((previous['complete'] == true && solution['complete'] != true) ||
                (previous['complete'] != true &&
                    solution['complete'] != true &&
                    _rows(previous['placements']).length >
                        _rows(solution['placements']).length));
        if (!keepPrevious) {
          _solutions.removeWhere(
            (value) => value['profile'] == solution['profile'],
          );
          _solutions.add(solution);
        }
        _emit(event);
      case 'done':
        _finish(stopped: false);
      default:
        _emit(event);
    }
  }

  /// Stops promptly even while the worker is inside a synchronous search loop.
  Future<List<Map<String, Object?>>> stop() async {
    if (_running) _finish(stopped: true);
    return bestSolutions;
  }

  /// Starts a wider attempt from the best board; it does not resume an old tree.
  Future<List<Map<String, Object?>>> continueSearch({
    int? nodeLimit,
    Duration? timeLimit,
  }) {
    if (_input == null) throw StateError('ابدأ البحث أولاً.');
    if (_running) throw StateError('أوقف المحاولة الحالية قبل المتابعة.');
    final input = _copyMap(_input!);
    Map<String, Object?>? best;
    for (final solution in _solutions) {
      if (best == null ||
          _rows(solution['placements']).length >
              _rows(best['placements']).length)
        best = solution;
    }
    if (best != null) input['initialPlacements'] = _rows(best['placements']);
    input['nodeLimit'] = (nodeLimit ?? _nodeBudget * 2).clamp(1, 2000000);
    if (timeLimit != null) input['timeLimitMs'] = timeLimit.inMilliseconds;
    final retained = bestSolutions;
    final attempt = start(input, profiles: _profiles);
    // A wider attempt must not discard an already reviewed safe incumbent if
    // it is stopped before its first progress event or finds fewer lessons.
    _solutions = retained;
    return attempt;
  }

  int get _requestedCount => _rows(_input?['requirements']).fold<int>(
    0,
    (sum, row) => sum + _int(row['weekly_lessons']).clamp(0, 1000),
  );

  Map<String, Object?>? _stoppedSnapshot() {
    final snapshot = _bestSnapshot;
    if (snapshot == null) return null;
    final entries = _rows(snapshot['placements']);
    final input = _input!;
    // Stop is not proof of infeasibility. Only call a board complete if the
    // same independent checks used by the scheduler have accepted it.
    final complete = ScheduleImprovementService.valid(input, entries);
    final profile =
        '${snapshot['preference'] ?? snapshot['profile'] ?? _profiles.first}';
    return {
      'profile': profile,
      'label': _profileLabels[profile] ?? profile,
      'placements': entries,
      'requestedCount': _requestedCount,
      'unscheduled': complete
          ? <String>[]
          : <String>[
              'أُوقف البحث بطلبك؛ احتُفظ بأفضل توزيع منشور للمراجعة أو المتابعة.',
            ],
      'dailySpreadIssues': <String>[],
      'exploredNodes': _int(snapshot['exploredNodes']),
      'searchLimitReached': false,
      'complete': complete,
      'stopped': true,
    };
  }

  void _finish({required bool stopped}) {
    if (!_running) return;
    if (stopped) {
      final candidate = _stoppedSnapshot();
      if (candidate != null) {
        final profile = candidate['profile'];
        final previous = _solutions
            .where((value) => value['profile'] == profile)
            .firstOrNull;
        if (previous == null ||
            _rows(candidate['placements']).length >
                _rows(previous['placements']).length) {
          _solutions.removeWhere((value) => value['profile'] == profile);
          _solutions.add(candidate);
        }
      }
    }
    _running = false;
    _clock.stop();
    _isolate?.kill(priority: Isolate.immediate);
    _isolate = null;
    _port?.close();
    _port = null;
    unawaited(_subscription?.cancel() ?? Future<void>.value());
    _subscription = null;
    final pending = _pending;
    _pending = null;
    _emit({
      'type': stopped ? 'stopped' : 'done',
      'solutions': bestSolutions,
      'elapsedMs': _clock.elapsedMilliseconds,
    });
    if (pending != null && !pending.isCompleted)
      pending.complete(bestSolutions);
  }

  void _fail(Object error, StackTrace stack) {
    if (!_running) return;
    final pending = _pending;
    _pending = null;
    _finish(stopped: false);
    _emit({
      'type': 'error',
      'message': '$error',
      'elapsedMs': _clock.elapsedMilliseconds,
    });
    if (pending != null && !pending.isCompleted)
      pending.completeError(error, stack);
  }

  void _emit(Map<String, Object?> event) {
    if (!_disposed && !_events.isClosed) _events.add(_copyMap(event));
  }

  Future<void> dispose() async {
    if (_disposed) return;
    if (_running) _finish(stopped: true);
    _disposed = true;
    await _events.close();
  }
}

const _profileLabels = {
  'minimal_changes': 'أقل تغييرات على الجدول الحالي',
  'teacher_gaps': 'أقل فراغات للمعلمين',
  'balanced_subjects': 'توازن توقيت المواد',
};

void _runScheduleSearch(List<Object?> arguments) {
  final output = arguments[0] as SendPort;
  final options = Map<String, Object?>.from(arguments[1] as Map);
  final input = Map<String, Object?>.from(options['input'] as Map);
  final profiles = (options['profiles'] as List).cast<String>();
  List<Map<String, Object?>>? feasibleSeed;
  for (var index = 0; index < profiles.length; index++) {
    final profile = profiles[index];
    output.send({
      'type': 'profile',
      'profile': profile,
      'profileIndex': index,
      'profileCount': profiles.length,
      'label': _profileLabels[profile],
    });
    final result = feasibleSeed != null
        ? SchedulerResult(
            placements: feasibleSeed,
            unscheduled: const [],
            requestedCount: feasibleSeed.length,
            exploredNodes: 0,
            searchLimitReached: false,
          )
        : const UnifiedScheduleService().generate(
            input: input,
            nodeLimit: _int(options['nodeLimit'], fallback: 600000),
            timeLimit: Duration(
              milliseconds: _int(
                input['timeLimitMs'],
                fallback: 60000,
              ).clamp(1, 3600000),
            ),
            onProgress: (progress) => output.send({
              ...progress,
              'type': 'progress',
              'profile': profile,
              'profileIndex': index,
              'profileCount': profiles.length,
            }),
          );
    // Publish the valid incumbent before bounded quality improvement begins.
    output.send({
      'type': 'solution',
      'profile': profile,
      'label': _profileLabels[profile],
      'placements': result.placements,
      'unscheduled': result.unscheduled,
      'requestedCount': result.requestedCount,
      'exploredNodes': result.exploredNodes,
      'searchLimitReached': result.searchLimitReached,
      'provenInfeasible': result.provenInfeasible,
      'dailySpreadIssues': result.dailySpreadIssues,
      'complete': result.complete,
    });
    if (result.complete &&
        ScheduleImprovementService.valid(input, result.placements)) {
      feasibleSeed ??= result.placements;
      output.send({
        'type': 'progress',
        'phase': 'optimizing',
        'complete': true,
        'placements': result.placements,
        'bestCount': result.placements.length,
        'requestedCount': result.requestedCount,
        'profile': profile,
      });
      void publish(List<Map<String, Object?>> board) => output.send({
        'type': 'solution',
        'profile': profile,
        'label': _profileLabels[profile],
        'placements': board,
        'unscheduled': <String>[],
        'dailySpreadIssues': <String>[],
        'requestedCount': result.requestedCount,
        'exploredNodes': result.exploredNodes,
        'searchLimitReached': false,
        'complete': true,
      });
      final improved = const ScheduleImprovementService().improve(
        input: input,
        seed: result.placements,
        profile: profile,
        timeLimit: Duration(
          milliseconds: _int(
            input['improvementTimeMs'],
            fallback: 8000,
          ).clamp(1, 30000),
        ),
        onImproved: (board, _) => publish(board),
      );
      publish(improved);
    }
  }
  output.send({'type': 'done'});
}

List<Map<String, Object?>> _rows(Object? value) => value is List
    ? value.map((row) => Map<String, Object?>.from(row as Map)).toList()
    : <Map<String, Object?>>[];

Map<String, Object?> _copyMap(Map<String, Object?> value) => {
  for (final entry in value.entries) entry.key: _copyValue(entry.value),
};
Object? _copyValue(Object? value) {
  if (value is Map)
    return {
      for (final entry in value.entries)
        '${entry.key}': _copyValue(entry.value),
    };
  if (value is List) return value.map(_copyValue).toList();
  return value;
}

int _int(Object? value, {int fallback = 0}) =>
    value is num ? value.toInt() : int.tryParse('$value') ?? fallback;
