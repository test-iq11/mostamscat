import 'conflict_detection_service.dart';
import 'teacher_availability_policy.dart';

typedef RepairRow = Map<String, Object?>;

/// A proposal is only an in-memory draft. Nothing is changed until the user
/// reviews it and the database independently validates the new version.
class MinimalRepairOption {
  const MinimalRepairOption({
    required this.placements,
    required this.moved,
    required this.remainingBlockers,
    required this.reason,
    this.batchTitle,
  });
  final List<RepairRow> placements;
  final List<int> moved;
  final int remainingBlockers;
  final String reason;
  final String? batchTitle;
  int get unchanged => placements.length - moved.length;
  String get title => batchTitle ?? (moved.length == 1
      ? 'نقل حصة واحدة'
      : moved.length == 2
      ? 'تبديل مباشر بين حصتين'
      : moved.length == 3
      ? 'تبديل دائري بين ثلاث حصص'
      : 'سلسلة تبديل من ${moved.length} حصص');
}

class MinimalRepairSearchResult {
  const MinimalRepairSearchResult(this.options, this.diagnostics, this.explored,
      {this.limitReached = false});
  final List<MinimalRepairOption> options;
  final List<String> diagnostics;
  final int explored;
  /// A bounded search stopping is NOT a proof of impossibility.
  final bool limitReached;
}

class _RepairBeamState {
  const _RepairBeamState(this.placements, this.blockers, this.moved, this.trace);
  final List<RepairRow> placements;
  final int blockers;
  final List<int> moved;
  final String trace;
}


/// An incremental, bounded, lexicographically least-change search.
/// It keeps identities, teachers, subjects, sections, rooms and pins intact;
/// only day and period can move. Global school rules are checked by the SAME
/// ConflictDetectionService used by the normal editor, not by an approximation.
class MinimalChangeRepairService {
  const MinimalChangeRepairService();

  static int n(Object? value) => value is num ? value.toInt() : int.tryParse('$value') ?? 0;
  static List<RepairRow> rows(Map<String, Object?> data, String key) =>
      (data[key] as List? ?? const []).map((e) => Map<String, Object?>.from(e as Map)).toList();

  List<ConflictIssue> scan(Map<String, Object?> data, List<RepairRow> entries) =>
      const ConflictDetectionService().scan(
        entries: entries,
        sections: rows(data, 'sections'),
        requirements: rows(data, 'requirements'),
        teachers: rows(data, 'teachers'),
        qualifications: rows(data, 'qualifications'),
        teacherGrades: rows(data, 'teacherGrades'),
        teacherSubjectGrades: rows(data, 'teacherSubjectGrades'),
        days: rows(data, 'days'),
        slots: rows(data, 'slots'),
        subjectBlockedSlots: rows(data, 'subjectBlockedSlots'),
        teacherAvailability: rows(data, 'availability'),
        enforceQualifications: true,
      );

  static String signature(ConflictIssue issue) =>
      '${issue.type}|${issue.sectionId}|${issue.teacherId}|${issue.subjectId}|${issue.dayId}|${issue.slotId}';

  static Map<String, int> _hardCounts(List<ConflictIssue> issues) {
    final result = <String, int>{};
    for (final issue in issues.where((i) => i.severity == 'خطأ مانع')) {
      final key = signature(issue);
      result[key] = (result[key] ?? 0) + 1;
    }
    return result;
  }

  /// Capacity is an upper bound (not a proof that a solution exists):
  /// its deficit IS a proof that the fixed assignment cannot fit.
  List<String> capacityDiagnostics(Map<String, Object?> data, {int? teacherId}) {
    final entries = rows(data, 'entries');
    final days = rows(data, 'days').where((d) => n(d['is_active'] ?? 1) != 0);
    final slots = rows(data, 'slots').where((s) =>
        s['kind'] == 'lesson' && n(s['is_available'] ?? 1) != 0);
    final sections = {for (final s in rows(data, 'sections')) n(s['id']): s};
    final teachers = {for (final t in rows(data, 'teachers')) n(t['id']): t};
    final blocked = {for (final b in rows(data, 'subjectBlockedSlots'))
      '${n(b['subject_id'])}:${n(b['slot_id'])}'};
    final availability = TeacherAvailabilityPolicy(rows(data, 'availability'));
    final result = <String>[];
    final ids = teacherId != null && teacherId > 0
        ? <int>{teacherId}
        : entries.map((e) => n(e['teacher_id'])).where((id) => id > 0).toSet();
    for (final id in ids) {
      final assigned = entries.where((e) => n(e['teacher_id']) == id).toList();
      if (assigned.isEmpty) continue;
      final availableCells = <String>{};
      for (final entry in assigned) {
        final gradeId = n(sections[n(entry['section_id'])]?['grade_id'] ?? entry['grade_id']);
        for (final day in days) {
          for (final slot in slots) {
            final dayId = n(day['id']);
            final slotId = n(slot['id']);
            if (blocked.contains('${n(entry['subject_id'])}:$slotId')) continue;
            if (availability.isAvailable(
              teacherId: id, dayId: dayId, slotId: slotId,
              gradeId: gradeId, subjectId: n(entry['subject_id']),
            )) availableCells.add('$dayId:$slotId');
          }
        }
      }
      final teacherName = teachers[id]?['name'] ?? 'المعلم $id';
      if (assigned.length > availableCells.length) {
        final difference = assigned.length - availableCells.length;
        result.add('المعلم $teacherName مُسند إليه ${assigned.length} حصص، لكن الإتاحة وقيود مواده تسمح بحد أقصى ${availableCells.length} فترات مختلفة. يلزم توفير $difference فترة إضافية على الأقل، أو إعادة إسناد $difference حصة لمعلم مؤهل آخر. لن تُغيَّر شروطك تلقائياً.');
      }
      final load = n(teachers[id]?['weekly_load']);
      if (load > 0 && assigned.length > load) {
        result.add('المعلم $teacherName مُسند إليه ${assigned.length} حصص بينما نصابه المسجل $load. راجع الإسناد أو صحّح النصاب من إدارة البيانات؛ لن يغيّره الإصلاح.');
      }
    }
    return result;
  }

  /// Joint, bounded, least-disruption repair for *related or independent*
  /// blocking issues. A beam keeps alternatives instead of committing the
  /// first greedy repair. Every transition strictly reduces blocking issues,
  /// never adds a new blocker/warning and never moves a pinned lesson.
  /// Nothing is written to the database by this search.
  MinimalRepairSearchResult findAffected({
    required Map<String, Object?> data,
    int maxRounds = 6,
    int beamWidth = 3,
    int maxExplored = 2400,
  }) {
    final original = rows(data, 'entries');
    final initialIssues = scan(data, original)
        .where((i) => i.severity == 'خطأ مانع').toList();
    final diagnostics = <String>[
      ...capacityDiagnostics(data),
      ...feasibilityDiagnostics(data),
    ];
    if (initialIssues.isEmpty) {
      return MinimalRepairSearchResult(const [], [
        ...diagnostics,
        'الجدول الحالي لا يحتوي أخطاء مانعة مكتشفة؛ لا حاجة لتغيير الحصص.',
      ], 0);
    }
    if (maxRounds <= 0 || beamWidth <= 0 || maxExplored <= 0) {
      return MinimalRepairSearchResult(const [], [
        ...diagnostics, 'لم يبدأ البحث لأن حد البحث المحدد يساوي صفراً.',
      ], 0, limitReached: true);
    }
    final initialBlockers = initialIssues.length;
    final first = _RepairBeamState(original, initialBlockers, const [], '');
    var beam = <_RepairBeamState>[first];
    final finalists = <_RepairBeamState>[];
    final visited = <String>{_boardKey(original)};
    var explored = 0;
    var hitLimit = false;
    var exhausted = false;

    int compare(_RepairBeamState a, _RepairBeamState b) {
      final errors = a.blockers.compareTo(b.blockers);
      if (errors != 0) return errors;
      final changes = a.moved.length.compareTo(b.moved.length);
      if (changes != 0) return changes;
      return a.trace.length.compareTo(b.trace.length);
    }

    for (var round = 0; round < maxRounds; round++) {
      if (explored >= maxExplored) { hitLimit = true; break; }
      final next = <_RepairBeamState>[];
      for (final state in beam) {
        if (state.blockers == 0) {
          finalists.add(state);
          continue;
        }
        final issues = scan(data, state.placements)
            .where((i) => i.severity == 'خطأ مانع').toList();
        final targets = _issueCandidateIndices(issues, state.placements);
        if (targets.isEmpty) continue;
        for (final target in targets.take(4)) {
          final remaining = maxExplored - explored;
          if (remaining <= 0) { hitLimit = true; break; }
          // Respect the total mobile CPU budget; the single-lesson solver
          // itself explores moves, exchanges and 3/4-lesson cycles.
          final result = find(
            data: {...data, 'entries': state.placements},
            targetEntryId: n(state.placements[target]['id']),
            maxEvaluations: remaining < 110 ? remaining : 110,
            maxOptions: 3,
          );
          explored += result.explored;
          for (final option in result.options) {
            if (option.remainingBlockers >= state.blockers) continue;
            final key = _boardKey(option.placements);
            if (!visited.add(key)) continue;
            final changed = <int>[
              for (var i = 0; i < original.length; i++)
                if (original[i]['day_id'] != option.placements[i]['day_id'] ||
                    original[i]['slot_id'] != option.placements[i]['slot_id']) i,
            ];
            final trace = [
              if (state.trace.isNotEmpty) state.trace,
              'الجولة ${round + 1}: ${option.reason}',
            ].join(' ');
            next.add(_RepairBeamState(
              option.placements, option.remainingBlockers, changed, trace,
            ));
          }
        }
        if (explored >= maxExplored) { hitLimit = true; break; }
      }
      if (next.isEmpty) {
        exhausted = true;
        break;
      }
      next.sort(compare);
      finalists.addAll(next);
      // Retain several different candidates; committing the first found
      // change would often exclude a smaller combined repair later.
      beam = next.take(beamWidth).toList();
      if (beam.every((s) => s.blockers == 0)) break;
    }
    if (!exhausted && explored < maxExplored &&
        beam.any((s) => s.blockers > 0) && maxRounds > 0) {
      hitLimit = true;
    }
    finalists.removeWhere((s) => s.moved.isEmpty || s.blockers >= initialBlockers);
    finalists.sort(compare);
    final distinct = <String>{};
    final options = <MinimalRepairOption>[];
    for (final candidate in finalists) {
      if (!distinct.add(_boardKey(candidate.placements))) continue;
      options.add(MinimalRepairOption(
        placements: candidate.placements,
        moved: candidate.moved,
        remainingBlockers: candidate.blockers,
        batchTitle: 'إصلاح جماعي يحرك ${candidate.moved.length} حصص',
        reason: 'بحث جماعي مترابط: ${candidate.trace} '
            'النتائج مرتبة بحسب إزالة الأخطاء أولاً، ثم أقل حصص متغيرة.',
      ));
      if (options.length >= 4) break;
    }
    if (options.isEmpty) diagnostics.add(
      'لم يصل البحث المحدود إلى إصلاح آمن. قد تكون القيود مستحيلة أو يحتاج الحل بحثاً أوسع؛ لا يُعد ذلك إثباتاً للاستحالة.',
    );
    if (hitLimit) diagnostics.add(
      'وصل البحث إلى الحد المخصص لأداء الهاتف. النتائج أفضل ما عُثر عليه ضمن الحد، وليست ضماناً للحل الأمثل عالمياً.',
    );
    return MinimalRepairSearchResult(options, diagnostics, explored,
        limitReached: hitLimit);
  }

  static String _boardKey(List<RepairRow> board) => board.map((e) =>
      '${n(e['id'])}:${n(e['day_id'])}:${n(e['slot_id'])}').join('|');

  /// Prefer precisely implicated unlocked lessons, first the matching cell,
  /// then the related teacher/section. Do not try unrelated lessons first.
  static List<int> _issueCandidateIndices(
      List<ConflictIssue> issues, List<RepairRow> board) {
    final scores = <int, int>{};
    for (final issue in issues) {
      for (var i = 0; i < board.length; i++) {
        final e = board[i];
        if (n(e['is_locked']) == 1) continue;
        final sameTeacher = issue.teacherId != null &&
            n(e['teacher_id']) == issue.teacherId;
        final sameSection = issue.sectionId != null &&
            n(e['section_id']) == issue.sectionId;
        final sameCell = issue.dayId != null && issue.slotId != null &&
            n(e['day_id']) == issue.dayId &&
            n(e['slot_id']) == issue.slotId;
        final exact = (issue.sectionId == null || sameSection) &&
            (issue.teacherId == null || sameTeacher) &&
            (issue.subjectId == null || n(e['subject_id']) == issue.subjectId) &&
            (issue.dayId == null || n(e['day_id']) == issue.dayId) &&
            (issue.slotId == null || n(e['slot_id']) == issue.slotId);
        // A conflict may name only one of two colliding lessons. If that
        // lesson is pinned, offer the movable peer on the same teacher/section
        // and period instead of declaring the issue unrepairable.
        if (!exact && !(sameCell && (sameTeacher || sameSection))) continue;
        final priority = issue.type == 'المعلم غير متاح في الفترة' ? 120 :
            issue.type == 'المادة في فترة ممنوعة' ? 110 :
            issue.type == 'تعارض المعلم' ? 100 :
            issue.type == 'تعارض الشعبة' ? 90 : 65;
        final score = (exact ? priority : 40) +
            (sameTeacher ? 8 : 0) + (sameSection ? 8 : 0) +
            (sameCell ? 6 : 0);
        if (score > (scores[i] ?? 0)) scores[i] = score;
      }
    }
    return scores.keys.toList()..sort((a, b) =>
        (scores[b] ?? 0).compareTo(scores[a] ?? 0));
  }

  /// Necessary capacity conditions only: a deficit proves infeasibility with
  /// the registered lessons, but no deficit does NOT prove schedulability.
  /// These checks never modify a teacher's availability or school rules.
  List<String> feasibilityDiagnostics(Map<String, Object?> data) {
    final days = rows(data, 'days').where((d) => n(d['is_active'] ?? 1) != 0).toList();
    final slots = rows(data, 'slots').where((s) =>
        s['kind'] == 'lesson' && n(s['is_available'] ?? 1) != 0).toList();
    final sections = {for (final s in rows(data, 'sections')) n(s['id']): s};
    final blocked = {for (final b in rows(data, 'subjectBlockedSlots'))
      '${n(b['subject_id'])}:${n(b['slot_id'])}'};
    final demand = <int, int>{};
    final subjectDemand = <String, int>{};
    for (final r in rows(data, 'requirements')) {
      final section = n(r['section_id']);
      final subject = n(r['subject_id']);
      final count = n(r['weekly_lessons']);
      if (section <= 0 || subject <= 0 || count <= 0) continue;
      demand[section] = (demand[section] ?? 0) + count;
      subjectDemand['$section:$subject'] =
          (subjectDemand['$section:$subject'] ?? 0) + count;
    }
    final notes = <String>[];
    final availableAll = days.length * slots.length;
    for (final required in demand.entries) {
      if (required.value <= availableAll) continue;
      final name = sections[required.key]?['section_name'] ?? sections[required.key]?['name'] ?? 'الشعبة ${required.key}';
      final missing = required.value - availableAll;
      notes.add('عجز مؤكد في $name: المطلوب ${required.value} حصة أسبوعياً '
          'لكن الدوام يوفر $availableAll خانات فقط. يلزم $missing خانة إضافية على الأقل '
          'أو تخفيض المتطلبات رسمياً؛ لن تُغيَّر الشروط تلقائياً.');
    }
    for (final item in subjectDemand.entries) {
      final parts = item.key.split(':');
      final sectionId = int.parse(parts[0]);
      final subjectId = int.parse(parts[1]);
      final possible = days.length * slots.where((slot) =>
          !blocked.contains('$subjectId:${n(slot['id'])}')).length;
      if (item.value <= possible) continue;
      final name = sections[sectionId]?['section_name'] ?? sections[sectionId]?['name'] ?? 'الشعبة $sectionId';
      notes.add('عجز مؤكد للمادة $subjectId في $name: مطلوب ${item.value} حصص، '
          'لكن حظر فتراتها يترك $possible خانات ممكنة فقط. '
          'راجع الحظر أو المتطلبات دون تغيير آلي.');
    }
    return notes;
  }

  MinimalRepairSearchResult find({
    required Map<String, Object?> data,
    required int targetEntryId,
    int maxEvaluations = 850,
    int maxOptions = 5,
  }) {
    final board = rows(data, 'entries');
    final index = board.indexWhere((e) => n(e['id']) == targetEntryId);
    if (index < 0 || maxEvaluations <= 0) {
      return const MinimalRepairSearchResult([], ['لم يتم العثور على الحصة في النسخة النشطة.'], 0);
    }
    final target = board[index];
    final diagnostics = capacityDiagnostics(data, teacherId: n(target['teacher_id']));
    if (n(target['is_locked']) == 1) {
      return MinimalRepairSearchResult(const [], [
        'الحصة مقفلة؛ افتح قفلها من الجدول أولاً. لن يتحرك أي موضع مقفل.',
        ...diagnostics,
      ], 0);
    }
    final baseline = scan(data, board);
    final baselineCounts = _hardCounts(baseline);
    final baselineTotal = baselineCounts.values.fold<int>(0, (a, b) => a + b);
    if (baselineTotal == 0) {
      return MinimalRepairSearchResult(const [], [
        'لم يكتشف الفاحص أي تعارض مانع في النسخة الحالية. يمكن مراجعة التحذيرات دون نقل الحصة.',
        ...diagnostics,
      ], 0);
    }
    final days = rows(data, 'days').where((e) => n(e['is_active'] ?? 1) != 0).toList();
    final slots = rows(data, 'slots').where((e) =>
        e['kind'] == 'lesson' && n(e['is_available'] ?? 1) != 0).toList();
    final cells = <(int, int)>[
      for (final day in days) for (final slot in slots) (n(day['id']), n(slot['id'])),
    ];
    final grades = {for (final s in rows(data, 'sections')) n(s['id']): n(s['grade_id'])};
    final blocked = {for (final b in rows(data, 'subjectBlockedSlots'))
      '${n(b['subject_id'])}:${n(b['slot_id'])}'};
    final availability = TeacherAvailabilityPolicy(rows(data, 'availability'));
    bool legalCell(int i, (int, int) cell) {
      final e = board[i];
      return !blocked.contains('${n(e['subject_id'])}:${cell.$2}') &&
        availability.isAvailable(
          teacherId: n(e['teacher_id']), dayId: cell.$1, slotId: cell.$2,
          gradeId: grades[n(e['section_id'])] ?? n(e['grade_id']),
          subjectId: n(e['subject_id']),
        );
    }
    (int, int) at(int i) => (n(board[i]['day_id']), n(board[i]['slot_id']));
    final proposals = <MinimalRepairOption>[];
    final seen = <String>{};
    var evaluated = 0;

    // Candidate maps carry the complete original row, modifying only the cell.
    // Reject any NEW blocking rule, even if another old problem disappears.
    void consider(Map<int, (int, int)> changes, String explanation) {
      if (evaluated >= maxEvaluations) return;
      final changed = changes.keys.where((i) => changes[i] != at(i)).toList()..sort();
      if (changed.isEmpty || changed.any((i) => n(board[i]['is_locked']) == 1)) return;
      if (!changed.contains(index)) return;
      if (changed.any((i) => !legalCell(i, changes[i]!))) return;
      final fingerprint = changed.map((i) => '$i:${changes[i]!.$1}:${changes[i]!.$2}').join('|');
      if (!seen.add(fingerprint)) return;
      evaluated++;
      final candidate = <RepairRow>[
        for (var i = 0; i < board.length; i++)
          if (changes.containsKey(i))
            {...board[i], 'day_id': changes[i]!.$1, 'slot_id': changes[i]!.$2}
          else
            Map<String, Object?>.from(board[i]),
      ];
      final candidateIssues = scan(data, candidate);
      final afterCounts = _hardCounts(candidateIssues);
      final afterTotal = afterCounts.values.fold<int>(0, (a, b) => a + b);
      if (afterTotal >= baselineTotal) return;
      for (final issue in afterCounts.entries) {
        if (issue.value > (baselineCounts[issue.key] ?? 0)) return;
      }
      // Do not introduce new workload or daily-warning violations either.
      bool protectedWarning(ConflictIssue i) => i.severity == 'تحذير' &&
          i.type != 'تكرار توقيت المادة في أيام متتالية';
      Map<String, int> warningCounts(List<ConflictIssue> found) {
        final counts = <String, int>{};
        for (final issue in found.where(protectedWarning)) {
          final key = signature(issue);
          counts[key] = (counts[key] ?? 0) + 1;
        }
        return counts;
      }
      final beforeWarnings = warningCounts(baseline);
      final afterWarnings = warningCounts(candidateIssues);
      if (afterWarnings.entries.any((e) => e.value > (beforeWarnings[e.key] ?? 0))) return;
      proposals.add(MinimalRepairOption(
        placements: candidate, moved: changed,
        remainingBlockers: afterTotal, reason: explanation,
      ));
      // Keep only top proposals; each draft contains a full school timetable.
      if (proposals.length > 16) {
        proposals.sort((a, b) {
          final size = a.moved.length.compareTo(b.moved.length);
          return size != 0 ? size : a.remainingBlockers.compareTo(b.remainingBlockers);
        });
        proposals.removeRange(12, proposals.length);
      }
    }

    final occupiedSameSection = <String>{
      for (final e in board.where((e) => e['section_id'] == target['section_id']))
        '${n(e['day_id'])}:${n(e['slot_id'])}',
    };
    // Stage 1: one-lesson move into a free cell. The global scanner also
    // rejects hidden teacher/room conflicts and daily distribution violations.
    for (final cell in cells) {
      if (evaluated >= maxEvaluations) break;
      if (occupiedSameSection.contains('${cell.$1}:${cell.$2}')) continue;
      if (!legalCell(index, cell)) continue;
      consider({index: cell}, 'لا يشغل صفّ هذه الحصة الموضع الجديد؛ يظل سائر الجدول ثابتاً.');
    }

    // Explore affected teacher / section first, then widen to other sections.
    final peers = <int>[
      for (var i = 0; i < board.length; i++) if (i != index && n(board[i]['is_locked']) != 1) i,
    ]..sort((a, b) {
      int rank(int i) {
        final e = board[i];
        return (e['section_id'] == target['section_id'] ? 0 : 1000) +
          (e['teacher_id'] == target['teacher_id'] ? 0 : 100) +
          (e['day_id'] == target['day_id'] ? 0 : 10) + i;
      }
      return rank(a).compareTo(rank(b));
    });
    final viable = peers.where((i) => legalCell(index, at(i))).toList();

    // Stage 2: direct exchange. Reserve evaluations for 3/4-lesson cycles
    // rather than letting hundreds of pair candidates exhaust the budget.
    for (final other in viable) {
      if (evaluated >= (maxEvaluations * 11 ~/ 20)) break;
      if (!legalCell(other, at(index))) continue;
      consider({index: at(other), other: at(index)},
        'تبديل متبادل بين موضعين؛ لم تتغير المواد أو المعلمون أو الغرف أو الحصص المثبتة.');
    }

    // Stage 3: displacing cycles, including chains crossing other sections.
    // Limited to mobile-safe search budgets, with full validation at the end.
    for (final a in viable.take(32)) {
      if (evaluated >= (maxEvaluations * 4 ~/ 5)) break;
      for (final b in peers) {
        if (evaluated >= (maxEvaluations * 4 ~/ 5)) break;
        if (b == a || !legalCell(a, at(b)) || !legalCell(b, at(index))) continue;
        consider({index: at(a), a: at(b), b: at(index)},
          'سلسلة ثلاثية: الأولى إلى مكان الثانية، والثانية إلى الثالثة، والثالثة إلى الأولى.');
      }
    }
    // Stage 4: widen only when small fixes were not found.
    if ((proposals.isEmpty || proposals.every((o) => o.remainingBlockers > 0)) &&
        evaluated < maxEvaluations) {
      for (final a in viable.take(14)) {
        for (final b in peers.take(35)) {
          if (evaluated >= maxEvaluations) break;
          if (a == b || !legalCell(a, at(b))) continue;
          for (final c in peers.take(35)) {
            if (evaluated >= maxEvaluations) break;
            if (c == a || c == b || !legalCell(b, at(c)) || !legalCell(c, at(index))) continue;
            consider({index: at(a), a: at(b), b: at(c), c: at(index)},
              'سلسلة تبادلات أوسع بعد تعذر النقل والتبديل الأقصر.');
          }
        }
      }
    }
    proposals.sort((a, b) {
      final moved = a.moved.length.compareTo(b.moved.length);
      return moved != 0 ? moved : a.remainingBlockers.compareTo(b.remainingBlockers);
    });
    // Do not offer multiple copies of the same changed cells or identical
    // location mappings. The first options are always the smallest edits.
    return MinimalRepairSearchResult(proposals.take(maxOptions).toList(), [
      ...diagnostics,
      if (proposals.isEmpty)
        'لم يُعثر على إصلاح يزيل مخالفة دون إضافة مخالفة جديدة ضمن $evaluated احتمالاً. راجع إتاحة المعلم وقيود المادة أو جرّب تعديل شروطك يدوياً ثم أعد الفحص.',
    ], evaluated);
  }
}
