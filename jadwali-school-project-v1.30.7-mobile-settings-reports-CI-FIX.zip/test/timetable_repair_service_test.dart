import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/timetable_repair_service.dart';

void main() {
  const service = TimetableRepairService();
  final slots = <Map<String, Object?>>[
    {'id': 1, 'kind': 'lesson', 'is_available': 1},
    {'id': 2, 'kind': 'lesson', 'is_available': 1},
  ];
  List<Map<String, Object?>> cycle() => [
    {'section_id': 1, 'teacher_id': 1, 'subject_id': 1, 'day_id': 1, 'slot_id': 1},
    {'section_id': 1, 'teacher_id': 2, 'subject_id': 2, 'day_id': 1, 'slot_id': 2},
    {'section_id': 2, 'teacher_id': 2, 'subject_id': 3, 'day_id': 1, 'slot_id': 1},
    {'section_id': 2, 'teacher_id': 1, 'subject_id': 4, 'day_id': 1, 'slot_id': 2},
  ];
  bool clashFree(List<Map<String, Object?>> entries) {
    final teacherCells = <String>{};
    final sectionCells = <String>{};
    return entries.every((e) =>
        teacherCells.add('${e['teacher_id']}:${e['day_id']}:${e['slot_id']}') &&
        sectionCells.add('${e['section_id']}:${e['day_id']}:${e['slot_id']}'));
  }

  test('repairs newly unavailable teacher times by exchanging connected lessons', () {
    final original = <Map<String, Object?>>[
      {'section_id': 1, 'teacher_id': 1, 'subject_id': 1, 'day_id': 1, 'slot_id': 1},
      {'section_id': 1, 'teacher_id': 2, 'subject_id': 2, 'day_id': 1, 'slot_id': 2},
    ];
    final unavailable = <Map<String, Object?>>[
      {'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
    ];
    final repaired = service.repair(
      initialPlacements: original,
      blockedSlots: const [], slots: slots,
      teacherAvailability: unavailable,
      isOtherwiseValid: clashFree,
    );
    expect(repaired, isNotNull);
    expect(repaired, hasLength(2));
    expect(repaired!.where((e) => e['teacher_id'] == 1 &&
      e['day_id'] == 1 && e['slot_id'] == 1), isEmpty);
    expect(clashFree(repaired), isTrue);
    expect(original.first['slot_id'], 1, reason: 'Do not mutate the seed.');
  });

  test('rejects availability repairs when both periods are prohibited', () {
    final repaired = service.repair(
      initialPlacements: cycle(), blockedSlots: const [], slots: slots,
      teacherAvailability: [
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 2, 'is_available': 0},
      ],
      isOtherwiseValid: clashFree,
      maxNodes: 50,
    );
    expect(repaired, isNull);
  });

  test('repairs a period restriction by exchanging all four connected lessons', () {
    final initial = cycle();
    final repaired = service.repair(
      initialPlacements: initial,
      blockedSlots: [{'subject_id': 1, 'slot_id': 1}],
      slots: slots,
      isOtherwiseValid: clashFree,
    );
    expect(repaired, isNotNull);
    expect(repaired!.map((e) => e['slot_id']), [2, 1, 2, 1]);
    expect(clashFree(repaired), isTrue);
    expect(initial.map((e) => e['slot_id']), [1, 2, 1, 2],
        reason: 'Repair must not mutate the currently active timetable.');
  });

  test('rejects a swap when the caller reports another hard constraint', () {
    final repaired = service.repair(
      initialPlacements: cycle(),
      blockedSlots: [{'subject_id': 1, 'slot_id': 1}],
      slots: slots,
      isOtherwiseValid: (entries) => clashFree(entries) &&
          entries.singleWhere((e) => e['subject_id'] == 2)['slot_id'] == 2,
    );
    expect(repaired, isNull);
  });

  test('combines independent exchanges on different school days', () {
    final initial = [
      ...cycle(),
      for (final entry in cycle()) {
        ...entry, 'day_id': 5, 'subject_id': (entry['subject_id'] as int) + 10,
      },
    ];
    final repaired = service.repair(
      initialPlacements: initial,
      blockedSlots: [
        {'subject_id': 1, 'slot_id': 1},
        {'subject_id': 11, 'slot_id': 1},
      ],
      slots: slots,
      isOtherwiseValid: clashFree,
    );
    expect(repaired, hasLength(8));
    expect(repaired!.where((e) => e['subject_id'] == 1 || e['subject_id'] == 11)
        .every((e) => e['slot_id'] == 2), isTrue);
    expect(clashFree(repaired), isTrue);
  });

  test('does not search disabled periods or ignore a zero effort budget', () {
    expect(service.repair(
      initialPlacements: cycle(),
      blockedSlots: [{'subject_id': 1, 'slot_id': 1}],
      slots: [slots.first, {...slots.last, 'is_available': 0}],
      isOtherwiseValid: clashFree,
    ), isNull);
    expect(service.repair(
      initialPlacements: cycle(),
      blockedSlots: [{'subject_id': 1, 'slot_id': 1}],
      slots: slots,
      maxNodes: 0,
      isOtherwiseValid: clashFree,
    ), isNull);
  });
}
