import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/teacher_timetable_capacity.dart';

void main() {
  test('calendar capacity agrees with exhaustive enumeration of gaps and run limits', () {
    for (var allowed = 0; allowed < 64; allowed++) {
      for (var run = 0; run <= 6; run++) {
        var exact = 0;
        for (var chosen = 0; chosen < 64; chosen++) {
          if (chosen & ~allowed != 0) continue;
          var consecutive = 0, count = 0;
          var valid = true;
          for (var slot = 0; slot < 6; slot++) {
            if ((chosen & (1 << slot)) != 0) {
              count++; consecutive++;
              if (run > 0 && consecutive > run) valid = false;
            } else { consecutive = 0; }
          }
          if (valid && count > exact) exact = count;
        }
        final capacity = const TeacherTimetableCapacity().calculate(
          teachers: [{'id': 1, 'weekly_load': 20, 'max_daily_lessons': 6, 'max_consecutive_lessons': run}],
          sections: [{'id': 1, 'grade_id': 1, 'max_daily_lessons': 6}],
          requirements: [{'section_id': 1, 'subject_id': 1, 'weekly_lessons': 6}],
          qualifications: [{'teacher_id': 1, 'subject_id': 1}], teacherGrades: [], teacherSubjectGrades: [],
          days: [{'id': 1, 'name': 'الأحد', 'is_active': 1}],
          slots: [for (var s = 0; s < 6; s++) {'id': s + 1, 'position': s, 'kind': 'lesson', 'is_available': 1}],
          subjectBlockedSlots: [for (var s = 0; s < 6; s++) if ((allowed & (1 << s)) == 0) {'subject_id': 1, 'slot_id': s + 1}],
          teacherAvailability: [],
        );
        expect(capacity[1], exact, reason: 'allowed=$allowed, run=$run');
      }
    }
  });
  test('weekly demand still allows Sunday period seven when examining only mandatory subjects', () {
    final capacity = const TeacherTimetableCapacity().calculate(
      teachers: [{'id': 1, 'weekly_load': 30, 'max_daily_lessons': 7, 'max_consecutive_lessons': 0}],
      sections: [{'id': 1, 'grade_id': 1, 'grade_name': 'السادس', 'max_daily_lessons': 6}],
      requirements: [{'section_id': 1, 'subject_id': 1, 'weekly_lessons': 1}],
      qualifications: [{'teacher_id': 1, 'subject_id': 1}], teacherGrades: [], teacherSubjectGrades: [],
      days: [{'id': 1, 'name': 'الأحد', 'is_active': 1}],
      slots: [for (var s = 0; s < 7; s++) {'id': s + 1, 'position': s, 'kind': 'lesson'}],
      subjectBlockedSlots: [for (var s = 1; s <= 6; s++) {'subject_id': 1, 'slot_id': s}],
      teacherAvailability: [], sectionWeeklyDemand: {1: 7},
    );
    expect(capacity[1], 1);
  });
}
