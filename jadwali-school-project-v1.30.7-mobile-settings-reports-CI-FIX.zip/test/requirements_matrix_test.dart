import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/core/editor_navigation_guard.dart';
import 'package:iraqi_school_timetable/features/data_management/requirements_matrix.dart';

class _Paths extends PathProviderPlatform {
  _Paths(this.path);
  final String path;
  @override
  Future<String> getApplicationSupportPath() async => path;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory dir;
  late PathProviderPlatform paths;
  late int sectionId, subjectId, secondId;
  setUpAll(() async {
    dir = await Directory.systemTemp.createTemp('jadwali-matrix-');
    paths = PathProviderPlatform.instance;
    PathProviderPlatform.instance = _Paths(dir.path);
    final db = await DatabaseService.instance.database;
    final grade = (await db.query('grades')).first['id'];
    sectionId = await db.insert('sections', {'grade_id': grade, 'name': 'أ'});
    final subjects = await db.query('subjects');
    subjectId = subjects.first['id'] as int;
    secondId = subjects[1]['id'] as int;
    await db.insert('section_subject_requirements', {
      'section_id': sectionId,
      'subject_id': subjectId,
      'weekly_lessons': 5,
      'max_daily_lessons': 1,
      'allow_same_day': 0,
    });
  });
  tearDownAll(() async {
    await DatabaseService.instance.close();
    PathProviderPlatform.instance = paths;
    await dir.delete(recursive: true);
  });
  testWidgets(
    'Arabic counts save atomically and preserve daily rules; invalid cells prevent all edits',
    (tester) async {
      final storage = DatabaseService.instance;
      late List<Map<String, Object?>> sections, subjects, requirements;
      await tester.runAsync(() async {
        sections = await storage.sectionsDetailed();
        subjects = (await storage.rows('subjects'))
            .where((s) => [subjectId, secondId].contains(s['id']))
            .toList();
        requirements = await storage.requirementsDetailed();
      });
      final guard = EditorNavigationGuard();
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: RequirementsMatrix(
              navigationGuard: guard,
              sections: sections,
              subjects: subjects,
              requirements: requirements,
              onChanged: () {},
              onRules: (_, _, _) async {},
            ),
          ),
        ),
      );
      final first = find.byKey(ValueKey('requirement-$sectionId-$subjectId'));
      final second = find.byKey(ValueKey('requirement-$sectionId-$secondId'));
      await tester.enterText(first, '٧');
      await tester.enterText(second, 'خطأ');
      final leaving = guard.beforeLeave!();
      await tester.pumpAndSettle();
      await tester.tap(find.text('البقاء'));
      await tester.pumpAndSettle();
      expect(await leaving, isFalse);
      expect(
        find.byKey(ValueKey('requirement-$sectionId-$subjectId')),
        findsOneWidget,
      );
      await tester.tap(find.text('حفظ المتطلبات'));
      await tester.pump();
      await tester.runAsync(() async {
        final rows = await storage.requirementsDetailed();
        expect(rows.single['weekly_lessons'], 5);
      });
      await tester.enterText(second, '٢');
      await tester.tap(find.text('حفظ المتطلبات'));
      for (var i = 0; i < 15; i++) {
        await tester.runAsync(
          () => Future<void>.delayed(const Duration(milliseconds: 30)),
        );
        await tester.pump(const Duration(milliseconds: 100));
      }
      await tester.runAsync(() async {
        final rows = await storage.requirementsDetailed();
        final original = rows.singleWhere((r) => r['subject_id'] == subjectId);
        expect(original['weekly_lessons'], 7);
        expect(original['max_daily_lessons'], 1);
        expect(original['allow_same_day'], 0);
        expect(
          rows.singleWhere(
            (r) => r['subject_id'] == secondId,
          )['weekly_lessons'],
          2,
        );
      });
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'mobile counts keep Arabic input and unsaved navigation guard at large text size',
    (tester) async {
      tester.view.physicalSize = const Size(320, 740);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final guard = EditorNavigationGuard();
      await tester.pumpWidget(
        MaterialApp(
          home: MediaQuery(
            data: const MediaQueryData(
              size: Size(320, 740),
              textScaler: TextScaler.linear(1.3),
            ),
            child: Scaffold(
              body: RequirementsMatrix(
                sections: const [
                  {'id': 1, 'grade_name': 'الأول', 'section_name': 'أ'},
                ],
                subjects: const [
                  {'id': 1, 'name': 'الرياضيات'},
                ],
                requirements: const [
                  {'section_id': 1, 'subject_id': 1, 'weekly_lessons': 5},
                ],
                onChanged: () {},
                onRules: (_, _, _) async {},
                navigationGuard: guard,
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.byTooltip('زيادة الحصص'));
      await tester.pump();
      expect(find.text('إجمالي الصف: 6 حصة'), findsOneWidget);
      await tester.enterText(
        find.byKey(const ValueKey('requirement-1-1')),
        '٧',
      );
      await tester.pump();
      expect(find.text('إجمالي الصف: 7 حصة'), findsOneWidget);
      final leave = guard.beforeLeave!();
      await tester.pumpAndSettle();
      expect(find.text('تعديلات غير محفوظة'), findsWidgets);
      await tester.tap(find.text('البقاء'));
      await tester.pumpAndSettle();
      expect(await leave, isFalse);
      expect(tester.takeException(), isNull);
    },
  );
}
