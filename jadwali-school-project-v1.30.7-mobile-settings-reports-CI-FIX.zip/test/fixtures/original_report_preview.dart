import 'package:flutter/material.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';
class OriginalReferenceTimetablePreview extends StatelessWidget {
  const OriginalReferenceTimetablePreview({
    required this.layout,
    required this.school,
    required this.number,
    required this.date,
    required this.manager,
    super.key,
  });
  final ReferenceTimetableLayout layout;
  final String school, number, date, manager;
  Widget _cell(
    String text,
    double width,
    double height, {
    bool shade = false,
    Color? fill,
    bool rotate = false,
  }) => Container(
    width: width,
    height: height,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: fill ?? (shade ? const Color(0xFFE6E6E6) : Colors.white),
      border: Border.all(color: Colors.black54, width: .5),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: rotate
        ? RotatedBox(
            quarterTurns: 3,
            child: Text(
              text,
              style: TextStyle(color: Colors.black, fontSize: 12),
            ),
          )
        : Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black, fontSize: 11),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
  );
  @override
  Widget build(BuildContext context) => Column(
    children: [
      for (final group in layout.classGroups)
        Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  SizedBox(
                    width: 96 + group.length * 152 + (group.length - 1) * 12,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'إدارة مدرسة: $school',
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'جدول الدروس الاسبوعي رقم ($number)',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            'يعمل بموجبه اعتباراً من تاريخ $date',
                            textAlign: TextAlign.end,
                            style: TextStyle(color: Colors.black),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 14),
                  Row(
                    children: [
                      _cell('الأيام', 60, 64),
                      _cell('الدرس', 36, 64, shade: true),
                      for (var gi = 0; gi < group.length; gi++) ...[
                        if (gi > 0) SizedBox(width: 12),
                        Column(
                          children: [
                            _cell(
                              group[gi] == null
                                  ? ''
                                  : layout.sectionTitle(group[gi]!),
                              152,
                              32,
                            ),
                            Row(
                              children: [
                                _cell('المادة', 76, 32, shade: true),
                                _cell('المعلم', 76, 32, shade: true),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                  for (final day in layout.days) ...[
                    if (day != layout.days.first) SizedBox(height: 12),
                    Row(
                      children: [
                        _cell(
                          '${day['name']}',
                          60,
                          layout.periodsForDay(day, group).length * 36.0,
                          rotate: true,
                          fill: Color(layout.dayColor(day)),
                        ),
                        Column(
                          children: [
                            for (final slot in layout.periodsForDay(day, group))
                              _cell(
                                ReferenceTimetableLayout.arabic(
                                  layout.lessonNumber(slot),
                                ),
                                36,
                                36,
                                fill: Color(layout.dayColor(day)),
                              ),
                          ],
                        ),
                        for (var gi = 0; gi < group.length; gi++) ...[
                          if (gi > 0) SizedBox(width: 12),
                          Column(
                            children: [
                              for (final slot in layout.periodsForDay(
                                day,
                                group,
                              ))
                                Row(
                                  children: [
                                    _cell(
                                      layout.cellText(
                                        group[gi],
                                        day,
                                        slot,
                                        teacher: false,
                                      ),
                                      76,
                                      36,
                                      fill: Color(layout.dayColor(day)),
                                    ),
                                    _cell(
                                      layout.cellText(
                                        group[gi],
                                        day,
                                        slot,
                                        teacher: true,
                                      ),
                                      76,
                                      36,
                                      fill: Color(layout.dayColor(day)),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ],
                  SizedBox(height: 12),
                  Text(
                    'مدير المدرسة: $manager',
                    style: TextStyle(color: Colors.black),
                  ),
                ],
              ),
            ),
          ),
        ),
    ],
  );
}
