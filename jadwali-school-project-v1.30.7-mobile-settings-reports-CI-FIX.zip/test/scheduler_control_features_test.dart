import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';

void main() {
  final sections = <Map<String, Object?>>[
    {'id': 1, 'grade_id': 1, 'max_daily_lessons': 2},
  ];
  final requirements = <Map<String, Object?>>[
    {'section_id': 1, 'subject_id': 1, 'weekly_lessons': 2, 'allow_same_day': 0},
  ];
  final teachers = <Map<String, Object?>>[
    {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 2},
  ];
  final qualifications = <Map<String, Object?>>[
    {'teacher_id': 1, 'subject_id': 1},
  ];
  final days = <Map<String, Object?>>[
    {'id': 1, 'position': 1, 'is_active': 1},
    {'id': 2, 'position': 2, 'is_active': 1},
  ];
  final slots = <Map<String, Object?>>[
    {'id': 1, 'position': 1, 'kind': 'lesson', 'is_available': 1},
    {'id': 2, 'position': 2, 'kind': 'lesson', 'is_available': 1},
  ];
  final fixed = <String, Object?>{
    'section_id': 1, 'subject_id': 1, 'teacher_id': 1,
    'day_id': 2, 'slot_id': 2, 'room_id': 7,
  };
  SchedulerResult run({
    List<Map<String, Object?>>? locks,
    List<Map<String, Object?>> seed = const [],
    List<Map<String, Object?>> blocks = const [],
    Duration? timeLimit,
    void Function(Map<String, Object?>)? onProgress,
    String preference = 'minimal_changes',
  }) => const AutoSchedulerService(nodeLimit: 1000).generate(
    sections: sections, requirements: requirements, teachers: teachers,
    qualifications: qualifications, days: days, slots: slots,
    lockedPlacements: locks ?? [fixed], initialPlacements: seed,
    subjectBlockedSlots: blocks, timeLimit: timeLimit,
    onProgress: onProgress, preference: preference,
  );

  test('cold search retains a late fixed cell and fills earlier free days', () {
    final result = run();
    expect(result.complete, isTrue);
    expect(result.placements, contains(equals(fixed)));
    expect(result.placements.map((e) => e['day_id']).toSet(), {1, 2});
  });

  test('a saved schedule cannot override a different locked placement', () {
    final result = run(seed: [
      {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
      {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 2, 'slot_id': 1},
    ]);
    expect(result.complete, isTrue);
    expect(result.placements, contains(equals(fixed)));
  });

  test('contradictory locks produce an explicit incomplete result', () {
    final result = run(locks: [fixed, {...fixed}]);
    expect(result.complete, isFalse);
    expect(result.placements, isEmpty);
    expect(result.unscheduled.join(' '), contains('الحصص المثبتة'));
  });

  test('a blocked fixed lesson is reported instead of silently moved', () {
    final result = run(blocks: [{'subject_id': 1, 'slot_id': 2}]);
    expect(result.complete, isFalse);
    expect(result.placements, isEmpty);
    expect(result.unscheduled.join(' '), contains('فترة ممنوعة'));
  });

  test('malformed locks with unknown days are rejected without throwing', () {
    final result = run(locks: [{...fixed, 'day_id': 900}]);
    expect(result.complete, isFalse);
    expect(result.placements, isEmpty);
    expect(result.unscheduled, isNotEmpty);
  });

  test('zero time budget retains valid locks as a safe partial result', () {
    final result = run(timeLimit: Duration.zero);
    expect(result.complete, isFalse);
    expect(result.placements, contains(equals(fixed)));
    expect(result.searchLimitReached, isTrue);
  });

  test('progress starts and finishes with isolated placement snapshots', () {
    final events = <Map<String, Object?>>[];
    final result = run(onProgress: (event) {
      events.add(event);
      if (event['phase'] == 'done') {
        final rows = event['placements'] as List;
        (rows.first as Map)['teacher_id'] = 999;
      }
    });
    expect(events.first['phase'], 'starting');
    expect(events.last['phase'], 'done');
    expect(events.last['complete'], isTrue);
    expect(result.complete, isTrue);
    expect(result.placements.every((row) => row['teacher_id'] == 1), isTrue);
    expect(events.last['bestCount'], 2);
  });

  test('each preference keeps fixed placements and all hard constraints', () {
    for (final profile in ['minimal_changes', 'teacher_gaps', 'balanced_subjects']) {
      final events = <Map<String, Object?>>[];
      final result = run(preference: profile, onProgress: events.add);
      expect(result.complete, isTrue, reason: profile);
      expect(result.placements, contains(equals(fixed)), reason: profile);
      expect(events.last['preference'], profile);
    }
  });

  test('a fixed late repeat can receive its required early partner', () {
    final lateLock = <String, Object?>{
      'section_id': 1, 'subject_id': 1, 'teacher_id': 1,
      'day_id': 1, 'slot_id': 6, 'room_id': null,
    };
    final result = const AutoSchedulerService(nodeLimit: 2000).generate(
      sections: [{'id': 1, 'grade_id': 1, 'max_daily_lessons': 6}],
      requirements: [{'section_id': 1, 'subject_id': 1, 'weekly_lessons': 6, 'allow_same_day': 0}],
      teachers: [{'id': 1, 'weekly_load': 6, 'max_daily_lessons': 2}],
      qualifications: qualifications,
      days: [for (var day = 1; day <= 5; day++) {'id': day, 'position': day, 'is_active': 1}],
      slots: [for (var slot = 1; slot <= 6; slot++) {'id': slot, 'position': slot, 'kind': 'lesson', 'is_available': 1}],
      lockedPlacements: [lateLock],
      teacherAvailability: [
        for (var day = 2; day <= 5; day++)
          {'teacher_id': 1, 'day_id': day, 'slot_id': 6, 'is_available': 0},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements, contains(equals(lateLock)));
    expect(result.placements.where((e) => e['day_id'] == 1), hasLength(2));
  });

  test('a timed-out preference search retains a valid complete saved timetable', () {
    final seed = <Map<String, Object?>>[
      {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
      {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 2, 'slot_id': 2, 'room_id': 7},
    ];
    final result = run(seed: seed, preference: 'teacher_gaps', timeLimit: Duration.zero);
    expect(result.complete, isTrue);
    expect(result.placements, contains(equals(fixed)));
  });

  test('teacher gaps profile improves a flexible saved timetable with a gap', () {
    final reqs = <Map<String, Object?>>[
      for (var subject = 1; subject <= 3; subject++)
        {'section_id': subject, 'subject_id': subject, 'weekly_lessons': 1, 'allow_same_day': 0},
    ];
    final seed = <Map<String, Object?>>[
      {'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
      {'section_id': 2, 'subject_id': 2, 'teacher_id': 1, 'day_id': 1, 'slot_id': 3},
      {'section_id': 3, 'subject_id': 3, 'teacher_id': 1, 'day_id': 2, 'slot_id': 3},
    ];
    SchedulerResult generate(String profile) => const AutoSchedulerService(nodeLimit: 2000).generate(
      sections: [for (var section = 1; section <= 3; section++) {'id': section, 'grade_id': 1, 'max_daily_lessons': 3}],
      requirements: reqs,
      teachers: [{'id': 1, 'weekly_load': 3, 'max_daily_lessons': 3}],
      qualifications: [for (var subject = 1; subject <= 3; subject++) {'teacher_id': 1, 'subject_id': subject}],
      days: days,
      slots: [for (var slot = 1; slot <= 3; slot++) {'id': slot, 'position': slot, 'kind': 'lesson', 'is_available': 1}],
      initialPlacements: seed, preference: profile,
    );
    int gapCount(SchedulerResult result) {
      var total = 0;
      for (final day in [1, 2]) {
        final positions = result.placements.where((e) => e['day_id'] == day).map((e) => e['slot_id'] as int).toList()..sort();
        if (positions.isNotEmpty) total += positions.last - positions.first + 1 - positions.length;
      }
      return total;
    }
    final minimal = generate('minimal_changes');
    final compact = generate('teacher_gaps');
    expect(minimal.complete, isTrue);
    expect(compact.complete, isTrue);
    expect(gapCount(minimal), 1);
    expect(gapCount(compact), 0);
  });

  test('balanced profile redistributes a flexible saved concentrated day', () {
    final reqs = <Map<String, Object?>>[
      for (var subject = 1; subject <= 3; subject++)
        {'section_id': 1, 'subject_id': subject, 'weekly_lessons': 1, 'allow_same_day': 0},
    ];
    final staff = <Map<String, Object?>>[
      for (var teacher = 1; teacher <= 3; teacher++)
        {'id': teacher, 'weekly_load': 1, 'max_daily_lessons': 3},
    ];
    final quals = <Map<String, Object?>>[
      for (var teacher = 1; teacher <= 3; teacher++)
        {'teacher_id': teacher, 'subject_id': teacher},
    ];
    final lessonSlots = <Map<String, Object?>>[
      for (var slot = 1; slot <= 3; slot++)
        {'id': slot, 'position': slot, 'kind': 'lesson', 'is_available': 1},
    ];
    final seed = <Map<String, Object?>>[
      for (var subject = 1; subject <= 3; subject++)
        {'section_id': 1, 'subject_id': subject, 'teacher_id': subject, 'day_id': 1, 'slot_id': subject},
    ];
    SchedulerResult generate(String profile) => const AutoSchedulerService(nodeLimit: 2000).generate(
      sections: [{'id': 1, 'grade_id': 1, 'max_daily_lessons': 3}],
      requirements: reqs, teachers: staff, qualifications: quals,
      days: days, slots: lessonSlots, initialPlacements: seed, preference: profile,
    );
    final minimal = generate('minimal_changes');
    final balanced = generate('balanced_subjects');
    expect(minimal.complete, isTrue);
    expect(balanced.complete, isTrue);
    expect(minimal.placements.map((r) => r['day_id']).toSet(), {1});
    expect(balanced.placements.map((r) => r['day_id']).toSet(), {1, 2});
  });
  test('balanced preference honors configured priority for a demanding subject', () {
    final result = const AutoSchedulerService(nodeLimit: 2000).generate(
      sections: [{'id': 1, 'grade_id': 1, 'max_daily_lessons': 2}],
      requirements: [for (final subject in [2, 3])
        {'section_id': 1, 'subject_id': subject, 'weekly_lessons': 1, 'allow_same_day': 0}],
      teachers: [for (final teacher in [2, 3]) {'id': teacher, 'weekly_load': 1, 'max_daily_lessons': 2}],
      qualifications: [for (final id in [2, 3]) {'teacher_id': id, 'subject_id': id}],
      days: [{'id': 1, 'position': 1, 'is_active': 1}], slots: slots,
      preference: 'balanced_subjects',
      subjectPreferences: [{'id': 2, 'morning_priority': 1}, {'id': 3, 'morning_priority': 3}],
    );
    expect(result.complete, isTrue);
    expect(result.placements.singleWhere((e) => e['subject_id'] == 3)['slot_id'], 1);
  });

}
