import 'package:flutter/services.dart';

import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/features/timetable/timetable_page.dart';
import 'package:iraqi_school_timetable/services/lesson_swap_service.dart';
import 'package:iraqi_school_timetable/core/theme.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';

class _TestPaths extends PathProviderPlatform {
  _TestPaths(this.directory);
  final String directory;
  @override
  Future<String> getApplicationSupportPath() async => directory;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory directory;
  late PathProviderPlatform previousPaths;
  setUpAll(() async {
    directory = await Directory.systemTemp.createTemp('jadwali-ui-');
    previousPaths = PathProviderPlatform.instance;
    PathProviderPlatform.instance = _TestPaths(directory.path);
    SharedPreferences.setMockInitialValues({});
    final input = jsonDecode(
      File('test/fixtures/backup_school_181.json').readAsStringSync(),
    ) as Map;
    List<Map<String, Object?>> rows(String key) => (input[key] as List)
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    final storage = DatabaseService.instance;
    final db = await storage.database;
    await db.transaction((txn) async {
      await txn.delete('time_slots');
      for (final slot in rows('slots')) {
        await txn.insert('time_slots', slot);
      }
      final known = (await txn.query('subjects')).map((s) => s['id']).toSet();
      for (final req in rows('requirements')) {
        if (known.add(req['subject_id']))
          await txn.insert('subjects', {
            'id': req['subject_id'],
            'name': 'مادة ${req['subject_id']}',
          });
      }
      for (final section in rows('sections')) {
        await txn.insert('sections', {
          'id': section['id'],
          'grade_id': section['grade_id'],
          'name': section['section_name'],
          'max_daily_lessons': 6,
        });
      }
      for (final t in rows('teachers')) {
        await txn.insert('teachers', t);
      }
      for (final q in rows('qualifications')) {
        await txn.insert('teacher_subjects', q);
      }
      for (final q in rows('teacherSubjectGrades')) {
        await txn.insert('teacher_subject_grades', q);
      }
      for (final r in rows('requirements')) {
        await txn.insert('section_subject_requirements', {
          for (final k in [
            'section_id',
            'subject_id',
            'weekly_lessons',
            'max_daily_lessons',
            'allow_same_day',
          ])
            k: r[k],
        });
      }
    });
    await storage.saveAsNewVersion(
      yearId: (await storage.activeYearId())!,
      name: 'الجدول النشط',
      entries: rows('initialPlacements'),
      requireComplete: true,
    );
  });
  tearDownAll(() async {
    await DatabaseService.instance.close();
    PathProviderPlatform.instance = previousPaths;
    await directory.delete(recursive: true);
  });
  Future<void> settle(WidgetTester tester) async {
    // Text fields may keep scheduling cursor frames; wait on data readiness,
    // not the absence of every animation in the application.
    for (var i = 0; i < 80; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump(const Duration(milliseconds: 100));
      if (i >= 4 &&
          find
              .byWidgetPredicate(
                (w) => w is CircularProgressIndicator && w.value == null,
              )
              .evaluate()
              .isEmpty)
        break;
    }
    expect(
      find.byWidgetPredicate(
        (w) => w is CircularProgressIndicator && w.value == null,
      ),
      findsNothing,
    );
  }

  for (final width in [320.0, 390.0, 1280.0]) {
    testWidgets('touch swap, late restriction and undo at $width', (
      tester,
    ) async {
      tester.view.physicalSize = Size(width, 900);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final input = Map<String, Object?>.from(
        jsonDecode(
          File('test/fixtures/backup_school_181.json').readAsStringSync(),
        ) as Map,
      );
      final entries = (await tester.runAsync(
        () => DatabaseService.instance.entriesDetailed(),
      ))!;
      input['entries'] = entries;
      Map<String, Object?>? a, b;
      for (final first in entries) {
        for (final second in entries) {
          if (first['id'] == second['id'] ||
              first['section_id'] != second['section_id'] ||
              first['day_id'] != second['day_id'] ||
              first['subject_id'] == second['subject_id'])
            continue;
          if (const LessonSwapService().validate(input, first, second) ==
              null) {
            a = first;
            b = second;
            break;
          }
        }
        if (a != null) break;
      }
      expect(a, isNotNull);
      final first = a!, second = b!;
      for (final font in [
        ('JadwaliStudio', 'assets/fonts/UI-Regular.ttf'),
        ('JadwaliLatin', 'assets/fonts/UI-Latin.ttf'),
        ('MaterialIcons', 'fonts/MaterialIcons-Regular.otf'),
      ]) {
        await (FontLoader(font.$1)..addFont(rootBundle.load(font.$2))).load();
      }
      final capture = GlobalKey();
      await tester.pumpWidget(
        MaterialApp(
          theme: buildAppTheme(),
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: RepaintBoundary(
              key: capture,
              child: TimetablePage(
                onChanged: () {},
                focusTarget: {
                  'sectionId': first['section_id'] as int,
                  'dayId': first['day_id'] as int,
                  'token': 1,
                },
              ),
            ),
          ),
        ),
      );
      await settle(tester);
      Finder lesson(Map<String, Object?> e) => find.byKey(
        ValueKey('lesson-${e['section_id']}-${e['day_id']}-${e['slot_id']}'),
      );
      Future<void> reveal(Map<String, Object?> entry) async {
        final scroll = find
            .descendant(
              of: find.byKey(const ValueKey('daily-lessons')),
              matching: find.byType(Scrollable),
            )
            .first;
        tester.state<ScrollableState>(scroll).position.jumpTo(0);
        await tester.pump();
        await tester.scrollUntilVisible(lesson(entry), 100, scrollable: scroll);
      }

      await reveal(first);
      await tester.tap(lesson(first));
      await tester.pump();
      expect(find.text('إلغاء'), findsOneWidget);
      await reveal(second);
      await tester.tap(lesson(second));
      await settle(tester);
      final swapped = (await tester.runAsync(
        () => DatabaseService.instance.entriesDetailed(),
      ))!;
      expect(
        swapped.singleWhere((r) => r['id'] == first['id'])['subject_id'],
        second['subject_id'],
      );
      expect(find.text('إلغاء'), findsNothing);
      await tester.pumpAndSettle();
      await tester.tap(find.text('تراجع'));
      await settle(tester);
      final restored = (await tester.runAsync(
        () => DatabaseService.instance.entriesDetailed(),
      ))!;
      expect(
        restored.singleWhere((r) => r['id'] == first['id'])['subject_id'],
        first['subject_id'],
      );
      await reveal(first);
      await tester.tap(lesson(first));
      await tester.pump();
      await tester.runAsync(() async {
        await (await DatabaseService.instance.database).insert(
          'subject_blocked_slots',
          {'subject_id': first['subject_id'], 'slot_id': second['slot_id']},
        );
      });
      await reveal(second);
      await tester.tap(lesson(second));
      await settle(tester);
      expect(find.text('هذا التبديل غير متاح'), findsOneWidget);
      await tester.tap(find.text('اختيار حصة أخرى'));
      await settle(tester);
      expect(find.text('إلغاء'), findsOneWidget);
      await tester.runAsync(() async {
        await (await DatabaseService.instance.database).delete(
          'subject_blocked_slots',
        );
      });
      await tester.pumpAndSettle();
      await tester.runAsync(() async {
        final boundary =
            capture.currentContext!.findRenderObject() as RenderRepaintBoundary;
        final image = await boundary.toImage();
        final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
        await Directory('build/touch-swap-preview').create(recursive: true);
        await File('build/touch-swap-preview/$width.png')
            .writeAsBytes(bytes!.buffer.asUint8List());
        image.dispose();
      });
      await tester.tap(find.text('إلغاء'));
      await tester.pump();
      await reveal(first);
      await tester.longPress(lesson(first));
      await settle(tester);
      expect(
        (await tester.runAsync(
          () => DatabaseService.instance.entriesDetailed(),
        ))!.singleWhere((r) => r['id'] == first['id'])['is_locked'],
        1,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('تراجع'));
      await settle(tester);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
      await tester.pump(const Duration(seconds: 2));
    });
  }
}
