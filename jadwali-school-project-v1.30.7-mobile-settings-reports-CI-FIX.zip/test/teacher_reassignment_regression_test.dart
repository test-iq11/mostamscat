import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/complete_schedule_solver.dart';
import 'package:iraqi_school_timetable/services/unified_schedule_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';

List<Map<String, Object?>> rows(Object? value) => (value as List? ?? [])
    .map((r) => Map<String, Object?>.from(r as Map))
    .toList();
void main() {
  test('181 lessons survive nine teacher allocation and load exchanges without bans', () {
    final base = Map<String, Object?>.from(
      jsonDecode(
        File('test/fixtures/backup_school_181.json').readAsStringSync(),
      ),
    );
    final teachers = rows(base['teachers']);
    for (var i = 0; i < 9; i++) {
      final a = teachers[i]['id'], b = teachers[i + 1]['id'];
      Object? swap(Object? v) => v == a
          ? b
          : v == b
          ? a
          : v;
      final input = Map<String, Object?>.from(jsonDecode(jsonEncode(base)));
      input['subjectBlockedSlots'] = [];
      input['teacherAvailability'] = [];
      input['teachers'] = teachers
          .map((t) => {...t, 'id': swap(t['id'])})
          .toList();
      for (final key in [
        'qualifications',
        'teacherGrades',
        'teacherSubjectGrades',
      ]) {
        input[key] = rows(base[key])
            .map((r) => {...r, 'teacher_id': swap(r['teacher_id'])})
            .toList();
      }
      final witness = rows(base['initialPlacements'])
          .map((r) => {...r, 'teacher_id': swap(r['teacher_id'])})
          .toList();
      expect(ScheduleImprovementService.valid(input, witness), isTrue);
      final result = const UnifiedScheduleService().generate(
        input: input,
        timeLimit: const Duration(seconds: 4),
      );
      expect(result.complete, isTrue, reason: 'exchange $a/$b');
      expect(result.placements, hasLength(181));
      expect(
        ScheduleImprovementService.valid(input, result.placements),
        isTrue,
      );
    }
  });
  test(
    'restricted teacher repair failure cannot prove whole-week infeasibility',
    () {
      final input = <String, Object?>{
        'sections': [
          {'id': 1, 'grade_id': 1, 'max_daily_lessons': 2},
        ],
        'teachers': [
          {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 2},
        ],
        'requirements': [
          for (var s = 1; s <= 2; s++)
            {'section_id': 1, 'subject_id': s, 'weekly_lessons': 1},
        ],
        'qualifications': [
          for (var s = 1; s <= 2; s++) {'teacher_id': 1, 'subject_id': s},
        ],
        'days': [
          {'id': 1, 'name': 'الأحد', 'position': 0},
        ],
        'slots': [
          for (var s = 1; s <= 2; s++)
            {'id': s, 'position': s - 1, 'kind': 'lesson', 'is_available': 1},
        ],
        'initialPlacements': [
          for (var s = 1; s <= 2; s++)
            {
              'section_id': 1,
              'subject_id': s,
              'teacher_id': 1,
              'day_id': 1,
              'slot_id': s,
            },
        ],
        'subjectBlockedSlots': [
          {'subject_id': 1, 'slot_id': 1},
        ],
      };
      final restricted = const CompleteScheduleSolver().solve(
        input: input,
        preserveLessonPositions: true,
      );
      expect(restricted.complete, isFalse);
      expect(restricted.provenInfeasible, isFalse);
      final result = const UnifiedScheduleService().generate(
        input: input,
        timeLimit: const Duration(seconds: 3),
      );
      expect(result.complete, isTrue);
      expect(
        ScheduleImprovementService.valid(input, result.placements),
        isTrue,
      );
    },
  );
}
