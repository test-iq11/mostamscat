import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/teacher_capacity_flow.dart';

void main() {
  test('يكشف عجز مجموعة معلمين رغم كفاية النصاب الإجمالي', () {
    expect(
      TeacherCapacityFlow.maximum(
        demand: [3, 3, 1],
        eligibleTeachers: [
          [1, 2],
          [1, 2],
          [3],
        ],
        capacity: {1: 2, 2: 2, 3: 20},
      ),
      5,
    );
  });

  test('يعيد توجيه الإسناد المرن ويحترم التأهيل المكرر والسعة الصفرية', () {
    expect(
      TeacherCapacityFlow.maximum(
        demand: [2, 2],
        eligibleTeachers: [
          [1, 1, 2, 3],
          [1],
        ],
        capacity: {1: 2, 2: 2, 3: 0},
      ),
      4,
    );
    expect(
      TeacherCapacityFlow.maximum(
        demand: [],
        eligibleTeachers: [],
        capacity: {},
      ),
      0,
    );
  });

  test('يطابق البحث الشامل في 150 شبكة عشوائية صغيرة', () {
    final random = Random(192);
    for (var sample = 0; sample < 150; sample++) {
      final capacities = {for (var t = 1; t <= 3; t++) t: random.nextInt(4)};
      final demand = List.generate(3, (_) => random.nextInt(3));
      final eligible = List.generate(
        3,
        (_) => [
          for (var t = 1; t <= 3; t++)
            if (random.nextBool()) t,
        ],
      );
      final lessons = <List<int>>[
        for (var g = 0; g < demand.length; g++)
          for (var i = 0; i < demand[g]; i++) eligible[g],
      ];
      int brute(int index) {
        if (index == lessons.length) return 0;
        var best = brute(index + 1);
        for (final t in lessons[index]) {
          if (capacities[t]! <= 0) continue;
          capacities[t] = capacities[t]! - 1;
          best = max(best, 1 + brute(index + 1));
          capacities[t] = capacities[t]! + 1;
        }
        return best;
      }

      final expected = brute(0);
      expect(
        TeacherCapacityFlow.maximum(
          demand: demand,
          eligibleTeachers: eligible,
          capacity: capacities,
        ),
        expected,
        reason: 'sample $sample',
      );
    }
  });
}
