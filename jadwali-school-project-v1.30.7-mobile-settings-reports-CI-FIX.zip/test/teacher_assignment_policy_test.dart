import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/teacher_assignment_policy.dart';

void main() {
  group('TeacherAssignmentPolicy', () {
    late TeacherAssignmentPolicy policy;

    setUp(() {
      policy = TeacherAssignmentPolicy(
        qualifications: const [
          {'teacher_id': 4, 'subject_id': 2}, // طالب: العربية
          {'teacher_id': 4, 'subject_id': 4}, // طالب: الرياضيات
          {'teacher_id': 5, 'subject_id': 2}, // معلم العربية للرابع
        ],
        teacherGrades: const [],
        teacherSubjectGrades: const [
          {'teacher_id': 4, 'subject_id': 2, 'grade_id': 1},
          {'teacher_id': 4, 'subject_id': 4, 'grade_id': 3},
          {'teacher_id': 4, 'subject_id': 4, 'grade_id': 4},
          {'teacher_id': 5, 'subject_id': 2, 'grade_id': 4},
        ],
      );
    });

    test('يسمح لطالب بالعربية للأول فقط، ويمنعها عنه في الرابع', () {
      expect(policy.isSubjectQualified(4, 2), isTrue);
      expect(policy.isGradeAllowed(4, 2, 1), isTrue);
      expect(policy.isGradeAllowed(4, 2, 4), isFalse);
      expect(
        policy.violation(
          teacherId: 4,
          subjectId: 2,
          gradeId: 4,
          teacherName: 'طالب',
          subjectName: 'اللغة العربية',
          gradeName: 'الرابع الابتدائي',
        ),
        contains('غير مسموح له بتدريس مادة اللغة العربية في الصف الرابع الابتدائي'),
      );
    });

    test('يسمح لطالب بالرياضيات في الثالث والرابع', () {
      expect(policy.isGradeAllowed(4, 4, 3), isTrue);
      expect(policy.isGradeAllowed(4, 4, 4), isTrue);
      expect(policy.isGradeAllowed(4, 4, 1), isFalse);
    });

    test('يفشل بأمان إذا كانت المادة مؤهلاً لها المعلم لكن إعداد صفوفها مفقود', () {
      final incomplete = TeacherAssignmentPolicy(
        qualifications: const [
          {'teacher_id': 4, 'subject_id': 2},
          {'teacher_id': 4, 'subject_id': 4},
        ],
        teacherGrades: const [],
        teacherSubjectGrades: const [
          {'teacher_id': 4, 'subject_id': 2, 'grade_id': 1},
        ],
      );
      expect(incomplete.isGradeAllowed(4, 4, 4), isFalse);
    });

    test('يرفض معلماً لم تُضبط صلاحيات صفوف مواده عندما يستخدم النظام قواعد حديثة', () {
      final incomplete = TeacherAssignmentPolicy(
        qualifications: const [
          {'teacher_id': 4, 'subject_id': 2},
          {'teacher_id': 9, 'subject_id': 2},
        ],
        teacherGrades: const [],
        teacherSubjectGrades: const [
          {'teacher_id': 4, 'subject_id': 2, 'grade_id': 1},
        ],
      );
      expect(incomplete.isGradeAllowed(9, 2, 1), isFalse);
      expect(
        incomplete.violation(teacherId: 9, subjectId: 2, gradeId: 1),
        contains('غير مسموح له بتدريس'),
      );
    });

    test('يرفض الإسناد عندما لا يمكن تحديد صف الشعبة', () {
      expect(policy.isGradeAllowed(4, 2, 0), isFalse);
      expect(
        policy.violation(teacherId: 4, subjectId: 2, gradeId: 0),
        contains('تعذر تحديد الصف الفعلي'),
      );
    });

    test('يحافظ على التوافق مع سجل قديم لا يحتوي قيود الصف للمادة', () {
      final legacy = TeacherAssignmentPolicy(
        qualifications: const [
          {'teacher_id': 8, 'subject_id': 9},
        ],
        teacherGrades: const [],
        teacherSubjectGrades: const [],
      );
      expect(legacy.isGradeAllowed(8, 9, 6), isTrue);
    });
  });
}
