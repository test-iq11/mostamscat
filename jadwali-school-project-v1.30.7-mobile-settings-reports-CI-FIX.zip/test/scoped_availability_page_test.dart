import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:iraqi_school_timetable/features/data_management/availability_page.dart';

class _Paths extends PathProviderPlatform {
  _Paths(this.directory);
  final String directory;
  @override
  Future<String> getApplicationSupportPath() async => directory;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory directory;
  late PathProviderPlatform oldPaths;
  late int teacherId, subjectId;
  setUpAll(() async {
    directory = await Directory.systemTemp.createTemp(
      'jadwali-availability-ui-',
    );
    oldPaths = PathProviderPlatform.instance;
    PathProviderPlatform.instance = _Paths(directory.path);
    final db = await DatabaseService.instance.database;
    teacherId = await db.insert('teachers', {'name': 'معلم الإتاحة'});
    subjectId = await db.insert('subjects', {'name': 'مادة الاختبار'});
    await db.insert('teacher_subjects', {
      'teacher_id': teacherId,
      'subject_id': subjectId,
    });
  });
  tearDownAll(() async {
    await DatabaseService.instance.close();
    PathProviderPlatform.instance = oldPaths;
    await directory.delete(recursive: true);
  });
  Future<void> settle(WidgetTester tester) async {
    for (var i = 0; i < 80; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump(const Duration(milliseconds: 100));
      if (i >= 4 &&
          find.byType(CircularProgressIndicator).evaluate().isEmpty &&
          find.byType(LinearProgressIndicator).evaluate().isEmpty &&
          find.byKey(const ValueKey('availability-cell:1:1')).evaluate().isNotEmpty &&
          tester.widget<FilledButton>(find.byKey(
              const ValueKey('availability-cell:1:1'))).onPressed != null)
        break;
    }
    expect(find.byType(CircularProgressIndicator), findsNothing);
    expect(find.byType(LinearProgressIndicator), findsNothing);
  }

  for (final width in [390.0, 1280.0]) {
    testWidgets(
      'scope selection saves grade and subject without replacing a general ban at $width',
      (tester) async {
        tester.view.physicalSize = Size(width, 1000);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await tester.runAsync(() async {
          final db = await DatabaseService.instance.database;
          await db.delete('teacher_availability');
          await db.insert('teacher_availability', {
            'teacher_id': teacherId,
            'day_id': 1,
            'slot_id': 2,
            'is_available': 0,
          });
        });
        await tester.pumpWidget(
          MaterialApp(
            home: Directionality(
              textDirection: TextDirection.rtl,
              child: AvailabilityPage(onChanged: () {}, onEditTeachers: () {}),
            ),
          ),
        );
        await settle(tester);
        await tester.tap(find.byKey(const ValueKey('availability-grade:0')));
        await tester.pumpAndSettle();
        await tester.tap(find.text('الأول').last);
        await tester.pumpAndSettle();
        await tester.tap(find.byKey(const ValueKey('availability-subject:0')));
        await tester.pumpAndSettle();
        await tester.tap(find.text('مادة الاختبار').last);
        await tester.pumpAndSettle();
        final cell = find.byKey(const ValueKey('availability-cell:1:1'));
        await tester.ensureVisible(cell);
        await tester.pumpAndSettle();
        await tester.tap(cell);
        await settle(tester);
        final saved = await tester.runAsync(
          () async => (await DatabaseService.instance.database).query(
            'teacher_availability',
          ),
        );
        expect(saved, hasLength(2));
        final scope = saved!.singleWhere((r) => r['slot_id'] == 1);
        expect(scope['grade_id'], 1);
        expect(scope['subject_id'], subjectId);
        expect(saved.singleWhere((r) => r['slot_id'] == 2)['grade_id'], isNull);
        final inheritedCell = tester.widget<FilledButton>(
          find.byKey(const ValueKey('availability-cell:1:2')),
        );
        expect(inheritedCell.onPressed, isNull);
        await tester.tap(cell);
        await settle(tester);
        final remaining = await tester.runAsync(
          () async => (await DatabaseService.instance.database).query(
            'teacher_availability',
          ),
        );
        expect(remaining, hasLength(1));
        expect(remaining!.single['slot_id'], 2);
        expect(tester.takeException(), isNull);
      },
    );
  }
}
