import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';

void main() {
  List<ConflictIssue> scan(List<int> occupied, {bool reverse = false}) {
    final slots = [
      for (var i = 1; i <= 7; i++)
        <String, Object?>{
          'id': i * 10,
          'name': 'الحصة $i',
          'kind': 'lesson',
          'is_available': 1,
          'position': i <= 5 ? i - 1 : 99,
          'start_time': '${i + 7}:00'.padLeft(5, '0'),
        },
    ];
    return const ConflictDetectionService().scan(
      entries: [
        for (final period in occupied)
          {
            'section_id': period,
            'subject_id': 1,
            'teacher_id': 1,
            'day_id': 1,
            'slot_id': period * 10,
          },
      ],
      teachers: [
        {'id': 1, 'max_consecutive_lessons': 4},
      ],
      slots: reverse ? slots.reversed.toList() : slots,
    ).where((issue) => issue.type == 'حصص متتالية زائدة').toList();
  }

  test('legacy duplicate positions cannot hide five consecutive lessons', () {
    expect(scan([2, 3, 4, 5, 6]), hasLength(1));
    expect(scan([3, 4, 5, 6, 7]), hasLength(1));
    expect(scan([2, 3, 4, 5, 6], reverse: true), hasLength(1));
  });

  test('an actual free lesson breaks the consecutive run', () {
    expect(scan([1, 2, 4, 5, 6, 7]), isEmpty);
    expect(scan([1, 2, 3, 4]), isEmpty);
  });
}
