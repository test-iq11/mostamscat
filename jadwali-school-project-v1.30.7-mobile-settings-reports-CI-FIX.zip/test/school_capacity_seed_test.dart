import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/mandatory_period_capacity.dart';
import 'package:iraqi_school_timetable/services/unified_schedule_service.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';
import 'package:iraqi_school_timetable/services/schedule_search_controller.dart';

void main() {
  Map<String, Object?> input() => Map<String, Object?>.from(
    jsonDecode(
      File('test/fixtures/school_oct27_period_capacity.json')
          .readAsStringSync(),
    ) as Map,
  );
  test(
    'uploaded school has a proven fifth-period staffing shortage on every day',
    () {
      final found = const MandatoryPeriodCapacity().inspect(input());
      expect(found, hasLength(5));
      expect(found.map((r) => r['capacity']), [5, 4, 4, 5, 5]);
      expect(
        found.every((r) => r['slotId'] == 5 && r['required'] == 6),
        isTrue,
      );
    },
  );
  test(
    'retain 169 legal lessons and return proof without speculative search',
    () {
      final data = input();
      List<Map<String, Object?>> rows(String k) => (data[k] as List? ?? [])
          .map((r) => Map<String, Object?>.from(r as Map))
          .toList();
      final result = const AutoSchedulerService().generate(
        sections: rows('sections'),
        requirements: rows('requirements'),
        teachers: rows('teachers'),
        qualifications: rows('qualifications'),
        teacherGrades: rows('teacherGrades'),
        teacherSubjectGrades: rows('teacherSubjectGrades'),
        subjectBlockedSlots: rows('subjectBlockedSlots'),
        teacherAvailability: rows('teacherAvailability'),
        days: rows('days'),
        slots: rows('slots'),
        initialPlacements: rows('initialPlacements'),
        lockedPlacements: rows('lockedPlacements'),
      );
      expect(result.provenInfeasible, isTrue);
      expect(result.complete, isFalse);
      expect(result.searchLimitReached, isFalse);
      expect(result.exploredNodes, 0);
      expect(result.placements, hasLength(169));
      expect(result.unscheduled, hasLength(5));
      expect(
        ScheduleImprovementService.validPartial(data, result.placements),
        isTrue,
      );
    },
  );
  test(
    'controller preserves proof and bypasses LNS after a proven contradiction',
    () async {
      final controller = ScheduleSearchController();
      addTearDown(controller.dispose);
      final phases = <String>[];
      final subscription = controller.events.listen(
        (e) => phases.add('${e['phase']}'),
      );
      addTearDown(subscription.cancel);
      final results = await controller.start(input());
      expect(results.single['provenInfeasible'], isTrue);
      expect(results.single['placements'], hasLength(169));
      expect(phases, isNot(contains('rescuing')));
    },
  );
  test('restoring Islamic fifth allows repair of the archived consecutive violation', () {
    final data = input();
    data['subjectBlockedSlots'] = (data['subjectBlockedSlots'] as List)
        .where((r) => !(r['subject_id'] == 1 && r['slot_id'] == 5))
        .toList();
    expect(const MandatoryPeriodCapacity().inspect(data), isEmpty);
    final seed = (data['initialPlacements'] as List)
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    // Legacy backup uses position99 for period6. Its teacher10 has five
    // consecutive lessons despite a limit of4; the corrected checker rejects it.
    expect(ScheduleImprovementService.valid(data, seed), isFalse);
    final repaired = const UnifiedScheduleService().generate(
      input: data,
      timeLimit: const Duration(seconds: 5),
    );
    expect(repaired.complete, isTrue);
    expect(ScheduleImprovementService.valid(data, repaired.placements), isTrue);
  });
}
