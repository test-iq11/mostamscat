import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/school_timetable_policy.dart';

void main() {
  final days = [
    {'id': 1, 'name': 'الأحد', 'position': 0},
    {'id': 2, 'name': 'الاثنين', 'position': 1},
    {'id': 3, 'name': 'الثلاثاء', 'position': 2},
    {'id': 4, 'name': 'الأربعاء', 'position': 3},
    {'id': 5, 'name': 'الخميس', 'position': 4},
  ];
  final slots = [
    for (var i = 1; i <= 7; i++)
      {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
  ];

  test('يسمح بالسابعة للسادس يوم الأحد فقط عندما تتجاوز المتطلبات سعة ست حصص يومياً', () {
    expect(
      SchoolTimetablePolicy.canUseSeventhPeriod(
        section: {'grade_name': 'السادس الابتدائي', 'max_daily_lessons': 6},
        day: days.first,
        activeDays: days,
        lessonSlots: slots,
        weeklyDemand: 31,
      ),
      isTrue,
    );
  });

  test('لا يتطلب الاستثناء ضبط الحد اليومي للشعبة على سبع حصص', () {
    expect(
      SchoolTimetablePolicy.canUseSeventhPeriod(
        section: {'grade_name': 'السادس الابتدائي', 'max_daily_lessons': 6},
        day: days.first,
        activeDays: days,
        lessonSlots: slots,
        weeklyDemand: 31,
      ),
      isTrue,
    );
  });

  test('لا يسمح بالسابعة لصف آخر أو في يوم غير الأحد', () {
    expect(
      SchoolTimetablePolicy.canUseSeventhPeriod(
        section: {'grade_name': 'الخامس الابتدائي', 'max_daily_lessons': 7},
        day: days.first,
        activeDays: days,
        lessonSlots: slots,
        weeklyDemand: 31,
      ),
      isFalse,
    );
    expect(
      SchoolTimetablePolicy.canUseSeventhPeriod(
        section: {'grade_name': 'السادس الابتدائي', 'max_daily_lessons': 7},
        day: days[1],
        activeDays: days,
        lessonSlots: slots,
        weeklyDemand: 31,
      ),
      isFalse,
    );
  });

  test('لا يسمح بالسابعة إذا لم تتجاوز المتطلبات سعة ست حصص لكل يوم', () {
    expect(
      SchoolTimetablePolicy.canUseSeventhPeriod(
        section: {'grade_name': 'السادس الابتدائي', 'max_daily_lessons': 6},
        day: days.first,
        activeDays: days,
        lessonSlots: slots,
        weeklyDemand: 30,
      ),
      isFalse,
    );
  });
}
