import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/teacher_workload_service.dart';

void main() {
  const service = TeacherWorkloadService();

  test('calculates assigned lessons, remaining load, teaching days and gaps', () {
    final result = service.calculate(
      teachers: [
        {'id': 1, 'name': 'أحمد', 'weekly_load': 5},
        {'id': 2, 'name': 'سارة', 'weekly_load': 1},
      ],
      entries: [
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 3},
        {'teacher_id': 1, 'day_id': 2, 'slot_id': 2},
        {'teacher_id': 2, 'day_id': 1, 'slot_id': 2},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 1, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 2, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 3, 'is_active': 0},
      ],
      slots: [
        {'id': 1, 'position': 1, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'position': 2, 'kind': 'lesson', 'is_available': 1},
        {'id': 3, 'position': 3, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    final ahmed = result.firstWhere((row) => row['teacher_id'] == 1);
    expect(ahmed['assigned_lessons'], 3);
    expect(ahmed['remaining'], 2);
    expect(ahmed['overload'], 0);
    expect(ahmed['days_with_lessons'], 2);
    expect(ahmed['active_days'], 2);
    expect(ahmed['gaps'], 1);

    final sara = result.firstWhere((row) => row['teacher_id'] == 2);
    expect(sara['assigned_lessons'], 1);
    expect(sara['remaining'], 0);
    expect(sara['overload'], 0);
  });

  test('reports overload when assigned lessons exceed the teacher weekly target', () {
    final result = service.calculate(
      teachers: [{'id': 1, 'name': 'أحمد', 'weekly_load': 2}],
      entries: [
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 2},
        {'teacher_id': 1, 'day_id': 1, 'slot_id': 3},
      ],
      days: [{'id': 1, 'is_active': 1}],
      slots: [
        {'id': 1, 'position': 1, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'position': 2, 'kind': 'lesson', 'is_available': 1},
        {'id': 3, 'position': 3, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.single['overload'], 1);
    expect(result.single['remaining'], 0);
  });
}
