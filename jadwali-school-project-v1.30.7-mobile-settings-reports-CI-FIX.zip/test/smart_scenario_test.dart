import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/features/smart/smart_scenario.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';

Map<String, Object?> school() => {
  'subjects': [
    {'id': 3, 'name': 'الرياضيات'},
  ],
  'teachers': [
    {'id': 7, 'weekly_load': 2, 'max_daily_lessons': 2},
  ],
  'sections': [
    {'id': 1, 'grade_id': 1, 'max_daily_lessons': 2},
  ],
  'qualifications': [
    {'teacher_id': 7, 'subject_id': 3},
  ],
  'requirements': [
    {
      'section_id': 1,
      'subject_id': 3,
      'weekly_lessons': 1,
      'allow_same_day': 0,
    },
  ],
  'slots': [
    {'id': 10, 'kind': 'lesson', 'is_available': 1, 'position': 0},
    {'id': 20, 'kind': 'lesson', 'is_available': 1, 'position': 1},
  ],
  'days': [
    {'id': 1, 'is_active': 1, 'position': 0},
    {'id': 2, 'is_active': 1, 'position': 1},
  ],
  'initialPlacements': [
    {
      'section_id': 1,
      'subject_id': 3,
      'teacher_id': 7,
      'day_id': 1,
      'slot_id': 10,
    },
  ],
  'lockedPlacements': <Map<String, Object?>>[],
  'subjectBlockedSlots': <Map<String, Object?>>[],
  'teacherAvailability': <Map<String, Object?>>[],
};
void main() {
  test('recognized requests use real nonconsecutive IDs; unknown requests remain unresolved', () {
    final data = school();
    expect(
      SmartScenario.fromRequest(
        'ابعد الرياضيات عن الحصة الاولى',
        rows(data['subjects']),
        rows(data['slots']),
      )!.slotId,
      10,
    );
    expect(
      SmartScenario.fromRequest(
        'ابعد العلوم عن الحصة الاولى',
        rows(data['subjects']),
        rows(data['slots']),
      ),
      isNull,
    );
    expect(
      SmartScenario.fromRequest(
        'احذف كل بيانات المدرسة',
        rows(data['subjects']),
        rows(data['slots']),
      ),
      isNull,
    );
  });
  test('subject trial leaves original input and existing locks untouched', () {
    final input = school();
    input['lockedPlacements'] = rows(input['initialPlacements']);
    final original = jsonEncode(input);
    final trial = const SmartScenario(
      SmartScenarioKind.subjectPeriod,
      subjectId: 3,
      slotId: 10,
    ).applyTo(input);
    expect(rows(trial['subjectBlockedSlots']), [
      {'subject_id': 3, 'slot_id': 10},
    ]);
    expect(trial['lockedPlacements'], input['lockedPlacements']);
    expect(jsonEncode(input), original);
    expect(
      ScheduleImprovementService.valid(trial, rows(trial['initialPlacements'])),
      isFalse,
    );
  });
  test('teacher-day scenario preserves other days and all source data', () {
    final input = school();
    input['teacherAvailability'] = [
      {'teacher_id': 7, 'day_id': 2, 'slot_id': 20, 'is_available': 0},
    ];
    final original = jsonEncode(input);
    final trial = const SmartScenario(
      SmartScenarioKind.teacherDay,
      teacherId: 7,
      dayId: 1,
    ).applyTo(input);
    expect(rows(trial['teacherAvailability']), hasLength(3));
    expect(jsonEncode(input), original);
  });
  test(
    'trial solves real constraints without modifying the stored-board input',
    () {
      final input = school();
      final original = jsonEncode(input);
      final trial = const SmartScenario(
        SmartScenarioKind.subjectPeriod,
        subjectId: 3,
        slotId: 10,
      ).applyTo(input);
      final r = const AutoSchedulerService(nodeLimit: 10000).generate(
        sections: rows(trial['sections']),
        teachers: rows(trial['teachers']),
        requirements: rows(trial['requirements']),
        qualifications: rows(trial['qualifications']),
        days: rows(trial['days']),
        slots: rows(trial['slots']),
        subjectBlockedSlots: rows(trial['subjectBlockedSlots']),
        initialPlacements: rows(trial['initialPlacements']),
        feasibilityOnly: true,
      );
      expect(r.complete, isTrue);
      expect(r.placements.single['slot_id'], 20);
      expect(ScheduleImprovementService.valid(trial, r.placements), isTrue);
      expect(jsonEncode(input), original);
    },
  );
  test('spacing trial changes only the temporary priority; disabled slots rejected', () {
    final input = school();
    final original = jsonEncode(input);
    final trial = const SmartScenario(SmartScenarioKind.spacing).applyTo(input);
    expect((trial['softPriorities'] as Map)['spacing'], 3);
    expect(jsonEncode(input), original);
    expect(
      () => const SmartScenario(
        SmartScenarioKind.subjectPeriod,
        subjectId: 999,
        slotId: 10,
      ).applyTo(input),
      throwsArgumentError,
    );
  });
}
