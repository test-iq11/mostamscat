import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:xml/xml.dart';
import 'package:iraqi_school_timetable/services/reference_office_service.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';

import 'reference_timetable_report_test.dart' show schoolLayout;

void main() {
  test(
    'all 181 lessons remain in day blocks separated by real blank cells',
    () {
      final layout = schoolLayout(), group = layout.classGroups.single;
      final rows = layout.separatedRows(group), days = layout.rowDays(group);
      expect(rows.length, 37); // 2 headings + 31 periods + 4 blank day rows.
      expect(
        rows.every((r) => r.length == 37),
        isTrue,
      ); // 24 cells + 11 gaps + day/period.
      expect(
        rows.expand((r) => r).where((s) => s.startsWith('مادة ')),
        hasLength(181),
      );
      expect(
        rows[8][17],
        startsWith('مادة '),
      ); // Sixth class, Sunday period seven.
      expect(rows[9].every((s) => s.isEmpty), isTrue);
      expect(days[9], isNull);
      expect(layout.days.map(layout.dayColor).toSet(), hasLength(5));
      for (var c = 0; c < rows.first.length; c++) {
        if (ReferenceTimetableLayout.separatorColumn(c))
          expect(rows.every((r) => r[c].isEmpty), isTrue);
      }
    },
  );
  test('Excel colors each complete day consistently and leaves separators unfilled', () {
    final bytes = const ReferenceOfficeService().timetable(
      layout: schoolLayout(),
      schoolName: 'اختبار',
      word: false,
    );
    final zip = ZipDecoder().decodeBytes(bytes);
    XmlDocument xml(String path) =>
        XmlDocument.parse(utf8.decode(zip.findFile(path)!.readBytes()!));
    final sheet = xml('xl/worksheets/sheet1.xml'),
        styles = xml('xl/styles.xml');
    final cells = {
      for (final c in sheet.findAllElements('c')) c.getAttribute('r'): c,
    };
    expect(cells['C5']!.getAttribute('s'), cells['R11']!.getAttribute('s'));
    expect(
      cells['C13']!.getAttribute('s'),
      isNot(cells['C5']!.getAttribute('s')),
    );
    expect(cells['E5']!.getAttribute('s'), '0'); // Blank class separator.
    expect(cells['C12']!.getAttribute('s'), '0'); // Blank day separator.
    expect(
      sheet.findAllElements('mergeCell').map((e) => e.getAttribute('ref')),
      containsAll(['C3:D3', 'F3:G3', 'A5:A11', 'A13:A18']),
    );
    final colors = styles
        .findAllElements('fgColor')
        .map((e) => e.getAttribute('rgb'));
    for (final color in ReferenceTimetableLayout.dayColors) {
      expect(colors, contains(color.toRadixString(16).toUpperCase()));
    }
  });
  test('Word exports narrow blank class columns and colored day cells', () {
    final bytes = const ReferenceOfficeService().timetable(
      layout: schoolLayout(),
      schoolName: 'اختبار',
      word: true,
    );
    final zip = ZipDecoder().decodeBytes(bytes);
    final doc = XmlDocument.parse(
      utf8.decode(zip.findFile('word/document.xml')!.readBytes()!),
    );
    final colors = doc
        .findAllElements('w:shd')
        .map((e) => e.getAttribute('w:fill'));
    final layout = schoolLayout();
    for (final day in layout.days) {
      expect(
        colors,
        contains(
          schoolLayout()
              .dayColor(day)
              .toRadixString(16)
              .substring(2)
              .toUpperCase(),
        ),
      );
    }
    expect(
      doc
          .findAllElements('w:gridCol')
          .where((e) => e.getAttribute('w:w') == '120'),
      hasLength(11),
    );
    expect(
      doc.findAllElements('w:t').where((e) => e.innerText.startsWith('مادة ')),
      hasLength(181),
    );
  });
}
