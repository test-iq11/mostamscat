import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';
import 'package:iraqi_school_timetable/services/schedule_comparison_service.dart';
import 'package:iraqi_school_timetable/services/timetable_repair_service.dart';
import 'package:iraqi_school_timetable/services/constraint_relief_service.dart';

Map<String, Object?> school() => {
  'sections': [
    {'id': 1, 'grade_id': 1, 'max_daily_lessons': 6},
  ],
  'teachers': [
    {'id': 1, 'weekly_load': 2, 'max_daily_lessons': 6},
  ],
  'qualifications': [
    {'teacher_id': 1, 'subject_id': 1},
    {'teacher_id': 1, 'subject_id': 2},
  ],
  'requirements': [
    for (var i = 1; i <= 2; i++)
      {
        'section_id': 1,
        'subject_id': i,
        'weekly_lessons': 1,
        'allow_same_day': 0,
      },
  ],
  'days': [
    {'id': 1, 'position': 0, 'is_active': 1},
  ],
  'slots': [
    for (var i = 1; i <= 6; i++)
      {'id': i, 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
  ],
  'initialPlacements': [
    {
      'section_id': 1,
      'subject_id': 1,
      'teacher_id': 1,
      'day_id': 1,
      'slot_id': 1,
    },
    {
      'section_id': 1,
      'subject_id': 2,
      'teacher_id': 1,
      'day_id': 1,
      'slot_id': 6,
    },
  ],
};
void main() {
  test(
    'quality stage reduces worst teacher gap and keeps full valid board',
    () {
      final input = school();
      final before = jsonEncode(input);
      final seed = rows(input['initialPlacements']);
      final accepted = <List<Map<String, Object?>>>[];
      final result = const ScheduleImprovementService().improve(
        input: input,
        seed: seed,
        profile: 'teacher_gaps',
        onImproved: (e, _) => accepted.add(e),
      );
      expect(accepted, isNotEmpty);
      for (final board in accepted)
        expect(ScheduleImprovementService.valid(input, board), isTrue);
      final q = ScheduleComparisonService.evaluate(
        entries: result,
        slots: rows(input['slots']),
        days: rows(input['days']),
        requirements: rows(input['requirements']),
      );
      expect(q.teacherGaps, 0);
      expect(q.worstTeacherDayGaps, 0);
      expect(jsonEncode(input), before);
    },
  );
  test('quality stage preserves locked lessons and blocked slots', () {
    final input = school();
    input['lockedPlacements'] = rows(input['initialPlacements']);
    input['subjectBlockedSlots'] = [
      {'subject_id': 1, 'slot_id': 2},
    ];
    final result = const ScheduleImprovementService().improve(
      input: input,
      seed: rows(input['initialPlacements']),
      profile: 'teacher_gaps',
    );
    expect(result, rows(input['initialPlacements']));
  });
  test('minimal-change profile does not disturb valid current timetable', () {
    final input = school();
    final seed = rows(input['initialPlacements']);
    expect(
      const ScheduleImprovementService().improve(
        input: input,
        seed: seed,
        profile: 'minimal_changes',
      ),
      seed,
    );
  });
  test('repairs a block by moving to another day when same-day movement is forbidden', () {
    final initial = <Map<String, Object?>>[
      {
        'section_id': 1,
        'subject_id': 1,
        'teacher_id': 1,
        'day_id': 1,
        'slot_id': 1,
      },
    ];
    final result = const TimetableRepairService().repair(
      initialPlacements: initial,
      blockedSlots: [
        {'subject_id': 1, 'slot_id': 1},
      ],
      days: [
        {'id': 1, 'is_active': 1},
        {'id': 2, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'kind': 'lesson'},
        {'id': 2, 'kind': 'lesson'},
      ],
      isOtherwiseValid: (board) =>
          !(board.single['day_id'] == 1 && board.single['slot_id'] == 2),
    );
    expect(result, isNotNull);
    expect(result!.single['day_id'], 2);
    expect(result.single['slot_id'], 2);
    expect(initial.single['day_id'], 1);
  });
  test(
    'bounded relief proposes a verified change without mutating constraints',
    () {
      final input = school();
      input['subjectBlockedSlots'] = [
        for (var i = 1; i <= 6; i++) {'subject_id': 1, 'slot_id': i},
      ];
      final before = jsonEncode(input);
      final result = suggestConstraintRelief(input);
      expect(result.single.code, 'verified_relief');
      expect(result.single.proven, isFalse);
      expect(result.single.suggestions, hasLength(1));
      expect(jsonEncode(input), before);
    },
  );
  test(
    'priority weights affect quality ranking without changing feasibility',
    () {
      const q = ScheduleQuality(
        teacherGaps: 1,
        changedLessons: 0,
        subjectBalancePenalty: 1,
        lessonCount: 2,
        repeatSpacingPenalty: 40,
      );
      expect(
        ScheduleImprovementService.score(q, 'balanced_subjects', {
          'spacing': 3,
        }),
        greaterThan(
          ScheduleImprovementService.score(q, 'balanced_subjects', {
            'spacing': 1,
          }),
        ),
      );
    },
  );
}
