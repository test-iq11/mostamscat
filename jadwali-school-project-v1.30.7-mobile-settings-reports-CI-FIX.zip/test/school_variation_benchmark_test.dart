import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';
import 'package:iraqi_school_timetable/services/schedule_comparison_service.dart';

void main() {
  test('181-lesson benchmark: extra teacher, replacement teacher, redistributed workload', () {
    final reports = <Map<String, Object?>>[];
    for (final scenario in [
      'extra_teacher',
      'replacement_teacher',
      'reduced_load',
    ]) {
      final input = Map<String, Object?>.from(
        jsonDecode(
          File('test/fixtures/backup_school_181.json').readAsStringSync(),
        ) as Map,
      );
      final teachers = rows(input['teachers']);
      final source = teachers.first;
      final id = source['id'];
      teachers.add({...source, 'id': 999, 'name': 'معلم التجربة'});
      if (scenario == 'replacement_teacher')
        teachers.removeWhere((t) => t['id'] == id);
      if (scenario == 'reduced_load')
        teachers[0] = {
          ...source,
          'weekly_load': (number(source['weekly_load']) - 2).clamp(1, 100),
        };
      input['teachers'] = teachers;
      for (final key in [
        'qualifications',
        'teacherGrades',
        'teacherSubjectGrades',
      ]) {
        final original = rows(input[key]);
        input[key] = [
          ...original.where(
            (r) => scenario != 'replacement_teacher' || r['teacher_id'] != id,
          ),
          for (final row in original.where((r) => r['teacher_id'] == id))
            {...row, 'teacher_id': 999},
        ];
      }
      final clock = Stopwatch()..start();
      final result = const AutoSchedulerService(nodeLimit: 600000).generate(
        sections: rows(input['sections']),
        requirements: rows(input['requirements']),
        teachers: rows(input['teachers']),
        qualifications: rows(input['qualifications']),
        teacherGrades: rows(input['teacherGrades']),
        teacherSubjectGrades: rows(input['teacherSubjectGrades']),
        days: rows(input['days']),
        slots: rows(input['slots']),
        subjectBlockedSlots: rows(input['subjectBlockedSlots']),
        teacherAvailability: rows(input['teacherAvailability']),
        initialPlacements: rows(input['initialPlacements']),
        feasibilityOnly: true,
        timeLimit: const Duration(seconds: 15),
      );
      expect(result.complete, isTrue, reason: scenario);
      expect(result.placements, hasLength(181));
      expect(
        ScheduleImprovementService.valid(input, result.placements),
        isTrue,
        reason: scenario,
      );
      reports.add({
        'scenario': scenario,
        'milliseconds': clock.elapsedMilliseconds,
        'exploredNodes': result.exploredNodes,
        'complete': result.complete,
        'quality': ScheduleComparisonService.evaluate(
          entries: result.placements,
          slots: rows(input['slots']),
          days: rows(input['days']),
          requirements: rows(input['requirements']),
          before: rows(input['initialPlacements']),
        ).toMap(),
      });
    }
    final input = Map<String, Object?>.from(
      jsonDecode(
        File('test/fixtures/backup_school_181.json').readAsStringSync(),
      ) as Map,
    );
    final seed = rows(input['initialPlacements']);
    ScheduleQuality quality(List<Map<String, Object?>> board) =>
        ScheduleComparisonService.evaluate(
          entries: board,
          slots: rows(input['slots']),
          days: rows(input['days']),
          requirements: rows(input['requirements']),
          before: seed,
        );
    for (final profile in ['teacher_gaps', 'balanced_subjects']) {
      final clock = Stopwatch()..start();
      final result = const ScheduleImprovementService().improve(
        input: input,
        seed: seed,
        profile: profile,
        maxCandidates: 1500,
        timeLimit: const Duration(seconds: 3),
      );
      expect(ScheduleImprovementService.valid(input, result), isTrue);
      expect(
        ScheduleImprovementService.score(quality(result), profile, {}),
        lessThanOrEqualTo(
          ScheduleImprovementService.score(quality(seed), profile, {}),
        ),
      );
      reports.add({
        'scenario': 'improve_$profile',
        'milliseconds': clock.elapsedMilliseconds,
        'complete': true,
        'before': quality(seed).toMap(),
        'quality': quality(result).toMap(),
      });
    }
    final destination = Platform.environment['JADWALI_BENCHMARK'];
    if (destination != null)
      File(
        destination,
      ).writeAsStringSync(const JsonEncoder.withIndent('  ').convert(reports));
  }, timeout: const Timeout(Duration(minutes: 2)));
}
