import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/schedule_integrity_audit.dart';

void main() {
  final fixture = Map<String, Object?>.from(jsonDecode(
    File('test/fixtures/backup_school_181.json').readAsStringSync(),
  ) as Map);
  final original = (fixture['initialPlacements'] as List)
      .map((row) => Map<String, Object?>.from(row as Map))
      .toList();
  const audit = ScheduleIntegrityAudit();

  test('independently accepts the known complete 181-lesson witness', () {
    expect(audit.inspect(fixture, original), isEmpty);
  });
  test('rejects an erased requirement and an extra placement', () {
    final missing = original.sublist(1);
    expect(audit.inspect(fixture, missing), isNotEmpty);
    expect(audit.inspect(fixture, [...original, original.first]), isNotEmpty);
  });
  test('rejects collisions even when the number of lessons stays the same', () {
    final bad = original.map((e) => {...e}).toList();
    final first = bad.first;
    // Force a second class into the same teacher/day/period.
    final target = bad.indexWhere((entry) =>
        entry['section_id'] != first['section_id'] &&
        entry['teacher_id'] != first['teacher_id']);
    expect(target, greaterThan(0));
    bad[target] = {
      ...bad[target],
      'teacher_id': first['teacher_id'],
      'day_id': first['day_id'],
      'slot_id': first['slot_id'],
    };
    expect(audit.inspect(fixture, bad).join(' '), contains('تعارض معلم'));
  });
  test('keeps locked placements, even if replacements retain the same count', () {
    final locked = {...fixture, 'lockedPlacements': [original.first]};
    expect(audit.accepts(locked, original), isTrue);
    final modified = original.map((e) => {...e}).toList();
    modified[0]['day_id'] = 9999;
    expect(audit.inspect(locked, modified).join(' '), contains('مقفلة'));
  });
  test('rejects inactive days and unavailable periods', () {
    final modified = original.map((e) => {...e}).toList();
    modified[0]['slot_id'] = 9999;
    expect(audit.accepts(fixture, modified), isFalse);
  });
}
