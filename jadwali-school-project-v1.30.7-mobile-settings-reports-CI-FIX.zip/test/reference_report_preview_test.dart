import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/features/reports/reports_page.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';

void main() {
  testWidgets(
    'reference preview remains scrollable on a phone with twelve class slots',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final layout = ReferenceTimetableLayout(
        sections: [
          {'id': 6, 'grade_name': 'السادس الابتدائي', 'max_daily_lessons': 6},
        ],
        days: [
          {'id': 1, 'name': 'الأحد', 'is_active': 1},
        ],
        slots: [
          for (var i = 1; i <= 7; i++)
            {'id': i, 'position': i, 'kind': 'lesson', 'is_available': 1},
        ],
        entries: [
          {
            'section_id': 6,
            'day_id': 1,
            'slot_id': 7,
            'subject_name': 'علوم',
            'teacher_name': 'معلم الاختبار',
          },
        ],
      );
      await tester.pumpWidget(
        MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(
              body: ListView(
                children: [
                  ReferenceTimetablePreview(
                    layout: layout,
                    school: 'مدرسة الاختبار',
                    number: '1',
                    date: '24/10/2026',
                    manager: '',
                  ),
                ],
              ),
            ),
          ),
        ),
      );
      expect(find.text('٧'), findsOneWidget);
      expect(find.text('علوم'), findsOneWidget);
      expect(tester.takeException(), isNull);
      final horizontal = find.byWidgetPredicate(
        (w) =>
            w is SingleChildScrollView && w.scrollDirection == Axis.horizontal,
      );
      await tester.drag(horizontal, const Offset(300, 0));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    },
  );
}
