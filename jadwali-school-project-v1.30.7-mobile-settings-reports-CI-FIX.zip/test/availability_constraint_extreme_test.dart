import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';
import 'package:iraqi_school_timetable/services/conflict_detection_service.dart';
import 'package:iraqi_school_timetable/services/constraint_explanation_service.dart';

/// The fixture preserves the real school's 181 lessons and eligibility rules,
/// but names are anonymized. The user's original private backup is NOT shipped.
void main() {
  final school = jsonDecode(
    File('test/fixtures/backup_school_181.json').readAsStringSync(),
  ) as Map<String, dynamic>;
  List<Map<String, Object?>> rows(String key) => (school[key] as List)
      .map((row) => Map<String, Object?>.from(row as Map)).toList();

  final knownFullBoard = rows('initialPlacements');
  final teachers = rows('teachers').map((row) => row['id'] as int).toList();
  final days = rows('days').where((r) => r['is_active'] == 1)
      .map((row) => row['id'] as int).toList();
  final slots = rows('slots')
      .where((r) => r['kind'] == 'lesson' && r['is_available'] == 1)
      .map((row) => row['id'] as int).toList();
  final usedTeacherCells = knownFullBoard.map((r) =>
    '${r['teacher_id']}:${r['day_id']}:${r['slot_id']}').toSet();
  final unusedTeacherCells = <Map<String, Object?>>[
    for (final t in teachers)
      for (final d in days)
        for (final s in slots)
          if (!usedTeacherCells.contains('$t:$d:$s'))
            {'teacher_id': t, 'day_id': d, 'slot_id': s, 'is_available': 0},
  ]..shuffle(Random(20261027));
  final usedSubjectSlots = knownFullBoard
      .map((r) => '${r['subject_id']}:${r['slot_id']}').toSet();
  final unusedSubjectSlots = <Map<String, Object?>>[
    for (final sub in rows('requirements').map((r) => r['subject_id'] as int).toSet())
      for (final s in slots)
        if (!usedSubjectSlots.contains('$sub:$s'))
          {'subject_id': sub, 'slot_id': s},
  ];

  Map<String, Object?> input({
    List<Map<String, Object?>> availability = const [],
    List<Map<String, Object?>> blocked = const [],
  }) => {
    for (final key in ['sections', 'requirements', 'teachers', 'qualifications',
      'teacherGrades', 'teacherSubjectGrades', 'days', 'slots']) key: rows(key),
    'subjectBlockedSlots': blocked,
    'teacherAvailability': availability,
    'initialPlacements': knownFullBoard,
    'lockedPlacements': <Map<String, Object?>>[],
  };

  List<String> hardIssues(Map<String, Object?> data, List<Map<String, Object?>> board) {
    final issues = const ConflictDetectionService().scan(
      entries: board,
      sections: (data['sections'] as List).cast<Map<String, Object?>>(),
      requirements: (data['requirements'] as List).cast<Map<String, Object?>>(),
      teachers: (data['teachers'] as List).cast<Map<String, Object?>>(),
      qualifications: (data['qualifications'] as List).cast<Map<String, Object?>>(),
      teacherGrades: (data['teacherGrades'] as List).cast<Map<String, Object?>>(),
      teacherSubjectGrades: (data['teacherSubjectGrades'] as List).cast<Map<String, Object?>>(),
      days: (data['days'] as List).cast<Map<String, Object?>>(),
      slots: (data['slots'] as List).cast<Map<String, Object?>>(),
      subjectBlockedSlots: (data['subjectBlockedSlots'] as List).cast<Map<String, Object?>>(),
      teacherAvailability: (data['teacherAvailability'] as List).cast<Map<String, Object?>>(),
    );
    return [for (final issue in issues)
      if (issue.type != 'تكرار توقيت المادة في أيام متتالية')
        '${issue.type}: ${issue.message}'];
  }

  test('fixture agrees with a complete 181-lesson valid witness', () {
    expect(knownFullBoard.length, 181);
    expect(unusedTeacherCells.length, 169);
    expect(unusedSubjectSlots.length, 12);
    expect(hardIssues(input(), knownFullBoard), isEmpty);
  });

  for (final size in [1, 15, 35, 70, 100, 169]) {
    test('solver keeps 181 lessons with $size precisely unavailable free teacher cells', () {
      final data = input(availability: unusedTeacherCells.take(size).toList());
      final before = jsonEncode(data);
      final result = const AutoSchedulerService(nodeLimit: 3000).generate(
        sections: rows('sections'), requirements: rows('requirements'),
        teachers: rows('teachers'), qualifications: rows('qualifications'),
        teacherGrades: rows('teacherGrades'), teacherSubjectGrades: rows('teacherSubjectGrades'),
        days: rows('days'), slots: rows('slots'),
        subjectBlockedSlots: const [],
        teacherAvailability: unusedTeacherCells.take(size).toList(),
        initialPlacements: knownFullBoard,
        feasibilityOnly: true, timeLimit: const Duration(seconds: 6),
      );
      expect(result.complete, isTrue, reason: result.unscheduled.join('\n'));
      expect(result.placements.length, 181);
      expect(hardIssues(data, result.placements), isEmpty);
      expect(jsonEncode(data), before, reason: 'Never mutate school data.');
    });
  }

  test('combined maximum witness-safe restrictions remain completely feasible', () {
    final data = input(availability: unusedTeacherCells, blocked: unusedSubjectSlots);
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: rows('sections'), requirements: rows('requirements'),
      teachers: rows('teachers'), qualifications: rows('qualifications'),
      teacherGrades: rows('teacherGrades'), teacherSubjectGrades: rows('teacherSubjectGrades'),
      days: rows('days'), slots: rows('slots'),
      subjectBlockedSlots: unusedSubjectSlots,
      teacherAvailability: unusedTeacherCells,
      initialPlacements: knownFullBoard,
      feasibilityOnly: true, timeLimit: const Duration(seconds: 6),
    );
    expect(result.complete, isTrue, reason: result.unscheduled.join('\n'));
    expect(result.placements, hasLength(181));
    expect(hardIssues(data, result.placements), isEmpty);
  });

  test('a whole weekday without any teacher is proven impossible', () {
    final unavailability = <Map<String, Object?>>[
      for (final t in teachers)
        for (final s in slots)
          {'teacher_id':t, 'day_id':days[1], 'slot_id':s, 'is_available':0},
    ];
    final findings = const ConstraintExplanationService().explain(
      input(availability: unavailability),
    );
    expect(findings.any((f) => f.proven &&
      f.code.startsWith('daily_coverage:')), isTrue,
      reason: 'Every five-plus-hour subject must occur on every school day.');
  });

  test('blocking every Arabic period has a rigorous per-subject proof', () {
    final blocked = <Map<String, Object?>>[
      for (final slot in slots) {'subject_id':2, 'slot_id':slot},
    ];
    final findings = const ConstraintExplanationService().explain(input(blocked: blocked));
    expect(findings.any((f) => f.proven &&
      f.code.startsWith('subject_period_capacity:')), isTrue);
  });

  test('two fully unavailable days violate sole-qualified teacher capacity', () {
    final unavailability = <Map<String, Object?>>[
      for (final d in days.take(2))
        for (final s in slots)
          {'teacher_id':4, 'day_id':d, 'slot_id':s, 'is_available':0},
    ];
    final findings = const ConstraintExplanationService().explain(
      input(availability: unavailability),
    );
    expect(findings.any((f) => f.proven &&
      f.code == 'mandatory_teacher_capacity:4'), isTrue);
  });
}
