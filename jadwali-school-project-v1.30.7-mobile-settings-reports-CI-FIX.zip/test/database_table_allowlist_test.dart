import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';

void main() {
  test('allows the compatibility table used by teacher-to-subject-grade rules', () {
    expect(DatabaseService.isAllowedTableName('teacher_subject_grades'), isTrue);
  });

  test('continues to reject arbitrary SQL table names', () {
    expect(DatabaseService.isAllowedTableName('users; DROP TABLE teachers'), isFalse);
    expect(DatabaseService.isAllowedTableName('unknown_table'), isFalse);
  });
}
