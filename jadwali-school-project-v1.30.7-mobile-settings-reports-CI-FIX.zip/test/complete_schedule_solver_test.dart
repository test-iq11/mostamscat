import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/complete_schedule_solver.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';

Map<String, Object?> _tiny() => {
  'sections': [
    {'id': 1, 'grade_id': 1, 'max_daily_lessons': 2},
  ],
  'teachers': [
    for (var t = 1; t <= 2; t++)
      {
        'id': t,
        'weekly_load': 4,
        'max_daily_lessons': 2,
        'max_consecutive_lessons': 2,
      },
  ],
  'requirements': [
    for (var s = 1; s <= 2; s++)
      {
        'section_id': 1,
        'subject_id': s,
        'grade_id': 1,
        'weekly_lessons': 1,
        'allow_same_day': 0,
      },
  ],
  'qualifications': [
    for (var t = 1; t <= 2; t++)
      for (var s = 1; s <= 2; s++) {'teacher_id': t, 'subject_id': s},
  ],
  'days': [
    {'id': 1, 'name': 'الأحد', 'position': 0},
    {'id': 2, 'name': 'الاثنين', 'position': 1},
  ],
  'slots': [
    for (var p = 1; p <= 2; p++)
      {'id': p, 'position': p - 1, 'kind': 'lesson', 'is_available': 1},
  ],
  'initialPlacements': <Map<String, Object?>>[],
  'lockedPlacements': <Map<String, Object?>>[],
};
List<Map<String, Object?>> _rows(Map<String, Object?> i, String key) =>
    (i[key] as List? ?? [])
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();

bool _enumerateIndependently(Map<String, Object?> input) {
  final units = <Map<String, Object?>>[
    for (final req in _rows(input, 'requirements'))
      for (var n = 0; n < (req['weekly_lessons'] as int); n++) req,
  ];
  final board = <Map<String, Object?>>[];
  bool visit(int index) {
    if (index == units.length) {
      return ScheduleImprovementService.valid(input, board) &&
          ScheduleImprovementService.validPartial(input, board);
    }
    for (final d in _rows(input, 'days')) {
      for (final p in _rows(input, 'slots')) {
        for (final t in _rows(input, 'teachers')) {
          board.add({
            'section_id': units[index]['section_id'],
            'subject_id': units[index]['subject_id'],
            'teacher_id': t['id'],
            'day_id': d['id'],
            'slot_id': p['id'],
            'room_id': null,
          });
          if (visit(index + 1)) return true;
          board.removeLast();
        }
      }
    }
    return false;
  }

  return visit(0);
}

void main() {
  test('exhaustive small-school oracle agrees for 80 varied constraints', () {
    final random = Random(125);
    for (var sample = 0; sample < 80; sample++) {
      final input = _tiny();
      input['subjectBlockedSlots'] = [
        for (var s = 1; s <= 2; s++)
          for (var p = 1; p <= 2; p++)
            if (random.nextBool()) {'subject_id': s, 'slot_id': p},
      ];
      input['teacherAvailability'] = [
        for (var t = 1; t <= 2; t++)
          for (var d = 1; d <= 2; d++)
            for (var p = 1; p <= 2; p++)
              if (random.nextBool())
                {'teacher_id': t, 'day_id': d, 'slot_id': p, 'is_available': 0},
      ];
      input['qualifications'] = _rows(
        input,
        'qualifications',
      ).where((_) => random.nextInt(4) > 0).toList();
      final before = jsonEncode(input);
      final expected = _enumerateIndependently(input);
      final result = const CompleteScheduleSolver().solve(input: input);
      expect(result.complete, expected, reason: 'sample $sample');
      expect(result.provenInfeasible, !expected, reason: 'sample $sample');
      if (result.complete)
        expect(
          ScheduleImprovementService.valid(input, result.placements),
          isTrue,
        );
      expect(jsonEncode(input), before);
    }
  });

  test(
    'moves lessons across days and chooses an alternate qualified teacher',
    () {
      final input = _tiny();
      input['requirements'] = [
        {
          'section_id': 1,
          'subject_id': 1,
          'grade_id': 1,
          'weekly_lessons': 2,
          'allow_same_day': 0,
        },
      ];
      input['initialPlacements'] = [
        for (var p = 1; p <= 2; p++)
          {
            'section_id': 1,
            'subject_id': 1,
            'teacher_id': 1,
            'day_id': 1,
            'slot_id': p,
            'room_id': null,
          },
      ];
      input['teacherAvailability'] = [
        for (var d = 1; d <= 2; d++)
          for (var p = 1; p <= 2; p++)
            {'teacher_id': 1, 'day_id': d, 'slot_id': p, 'is_available': 0},
      ];
      final result = const CompleteScheduleSolver().solve(input: input);
      expect(result.complete, isTrue);
      expect(result.placements.map((r) => r['day_id']).toSet(), {1, 2});
      expect(result.placements.every((r) => r['teacher_id'] == 2), isTrue);
    },
  );

  test(
    'partial seed cannot constrain the exact tree; room-bearing pins persist',
    () {
      final input = _tiny();
      final pin = {
        'section_id': 1,
        'subject_id': 1,
        'teacher_id': 1,
        'day_id': 2,
        'slot_id': 2,
        'room_id': 9,
      };
      input['lockedPlacements'] = [pin];
      input['initialPlacements'] = [
        {
          'section_id': 1,
          'subject_id': 2,
          'teacher_id': 1,
          'day_id': 2,
          'slot_id': 2,
          'room_id': null,
        },
      ];
      final result = const CompleteScheduleSolver().solve(input: input);
      expect(result.complete, isTrue);
      expect(result.placements, contains(equals(pin)));
    },
  );

  test('bounded/cancelled attempts never assert infeasibility', () {
    final limited = const CompleteScheduleSolver().solve(
      input: _tiny(),
      nodeLimit: 0,
    );
    expect(limited.status, CompleteScheduleStatus.limit);
    expect(limited.provenInfeasible, isFalse);
    final cancelled = const CompleteScheduleSolver().solve(
      input: _tiny(),
      shouldCancel: () => true,
    );
    expect(cancelled.status, CompleteScheduleStatus.cancelled);
    expect(cancelled.provenInfeasible, isFalse);
  });

  test('exhausts a teacher capacity contradiction without a timeout claim', () {
    final input = _tiny();
    input['teachers'] = [
      {'id': 1, 'weekly_load': 1, 'max_daily_lessons': 2},
    ];
    final result = const CompleteScheduleSolver().solve(input: input);
    expect(result.status, CompleteScheduleStatus.infeasible);
    expect(result.exploredNodes, greaterThan(0));
  });

  test(
    'invalid pins and duplicate requirements do not masquerade as proof',
    () {
      final input = _tiny();
      input['lockedPlacements'] = [
        {
          'section_id': 1,
          'subject_id': 1,
          'teacher_id': 999,
          'day_id': 1,
          'slot_id': 1,
        },
      ];
      expect(
        const CompleteScheduleSolver().solve(input: input).status,
        CompleteScheduleStatus.invalidInput,
      );
      input['lockedPlacements'] = [];
      input['requirements'] = [
        ..._rows(input, 'requirements'),
        _rows(input, 'requirements').first,
      ];
      expect(
        const CompleteScheduleSolver().solve(input: input).status,
        CompleteScheduleStatus.invalidInput,
      );
    },
  );

  test('daily limit constrains counts, not first N period positions', () {
    final input = _tiny();
    input['sections'] = [
      {'id': 1, 'grade_id': 1, 'max_daily_lessons': 1},
    ];
    input['subjectBlockedSlots'] = [
      {'subject_id': 1, 'slot_id': 1},
      {'subject_id': 2, 'slot_id': 1},
    ];
    final result = const CompleteScheduleSolver().solve(input: input);
    expect(result.complete, isTrue);
    expect(result.placements.every((r) => r['slot_id'] == 2), isTrue);
  });

  test(
    'latest backup contradictory bans terminate without losing safe incumbent',
    () {
      final input = Map<String, Object?>.from(
        jsonDecode(
          File('test/fixtures/school_oct27_period_capacity.json')
              .readAsStringSync(),
        ) as Map,
      );
      final result = const CompleteScheduleSolver().solve(
        input: input,
        timeLimit: const Duration(seconds: 4),
      );
      expect(result.status, CompleteScheduleStatus.infeasible);
      expect(
        ScheduleImprovementService.validPartial(input, result.placements),
        isTrue,
      );
      expect(result.complete, isFalse);
    },
  );
}
