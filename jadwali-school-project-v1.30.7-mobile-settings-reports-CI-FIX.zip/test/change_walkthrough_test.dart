import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/features/smart/change_walkthrough.dart';
import 'package:iraqi_school_timetable/services/schedule_comparison_service.dart';

void main() {
  testWidgets(
    'walkthrough is read-only, advances real changes and closes its timer',
    (tester) async {
      final before = <Map<String, Object?>>[
        {
          'section_id': 1,
          'subject_id': 1,
          'teacher_id': 1,
          'day_id': 1,
          'slot_id': 1,
        },
        {
          'section_id': 1,
          'subject_id': 2,
          'teacher_id': 1,
          'day_id': 2,
          'slot_id': 1,
        },
      ];
      final after = <Map<String, Object?>>[
        {...before[0], 'day_id': 2},
        {...before[1], 'day_id': 1},
      ];
      final changes = const ScheduleComparisonService()
          .compare(before, after)
          .changes;
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: TextButton(
                onPressed: () => showChangeWalkthrough(
                  context,
                  changes: changes,
                  sections: {1: 'الأول'},
                  subjects: {1: 'رياضيات', 2: 'علوم'},
                  teachers: {1: 'أحمد'},
                  days: {1: 'الأحد', 2: 'الاثنين'},
                  slots: {1: 'الأولى'},
                ),
                child: const Text('فتح'),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('فتح'));
      await tester.pumpAndSettle();
      expect(find.textContaining('1 من 2'), findsOneWidget);
      expect(find.text('رياضيات'), findsOneWidget);
      await tester.tap(find.text('التالي'));
      await tester.pumpAndSettle();
      expect(find.textContaining('2 من 2'), findsOneWidget);
      await tester.tap(find.text('عرض تلقائي'));
      await tester.pump(const Duration(milliseconds: 2000));
      await tester.tap(find.text('العودة للمقارنة'));
      await tester.pumpAndSettle();
      expect(before[0]['day_id'], 1);
      expect(after[0]['day_id'], 2);
      expect(tester.takeException(), isNull);
    },
  );
}
