import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/schedule_comparison_service.dart';

Map<String, Object?> lesson(int teacher, int day, int slot,
    {int id = 1, int subject = 2, int section = 1}) => {
  'id': id, 'section_id': section, 'subject_id': subject,
  'teacher_id': teacher, 'day_id': day, 'slot_id': slot,
};

void main() {
  const service = ScheduleComparisonService();
  test('saved version row IDs and order do not invent changes', () {
    final before = [lesson(1, 1, 1, id: 1), lesson(2, 2, 2, id: 2)];
    final after = [lesson(2, 2, 2, id: 44), lesson(1, 1, 1, id: 43)];
    final result = service.compare(before, after);
    expect(result.unchangedCount, 2);
    expect(result.changes, isEmpty);
  });

  test('one lesson moved and reassigned is counted once with both flags', () {
    final result = service.compare([lesson(1, 1, 1)], [lesson(2, 3, 2)]);
    expect(result.changedLessonCount, 1);
    expect(result.moves, hasLength(1));
    expect(result.teacherChanges, hasLength(1));
    expect(result.additions, isEmpty);
    expect(result.removals, isEmpty);
  });

  test('teacher-only reassignment remains at the same time', () {
    final result = service.compare([lesson(1, 1, 1)], [lesson(2, 1, 1)]);
    expect(result.changedLessonCount, 1);
    expect(result.teacherChanges, hasLength(1));
    expect(result.moves, isEmpty);
  });

  test('repeated lessons keep unchanged copies before pairing the moved copy', () {
    final before = [lesson(1, 1, 1), lesson(2, 2, 2)];
    final after = [lesson(2, 3, 3), lesson(2, 2, 2)];
    final result = service.compare(before, after);
    expect(result.unchangedCount, 1);
    expect(result.changes, hasLength(1));
    expect(result.changes.single.before!['teacher_id'], 1);
    expect(result.changes.single.after!['day_id'], 3);
    expect(result.changes.single.teacherChanged, isTrue);
  });

  test('minimum-cost pairing avoids invented teacher changes among repeated subjects', () {
    final result = service.compare(
      [lesson(1, 1, 1), lesson(2, 2, 2)],
      [lesson(2, 1, 2), lesson(1, 2, 1)],
    );
    expect(result.moves, hasLength(2));
    expect(result.teacherChanges, isEmpty);
    expect(result.changedLessonCount, 2);
  });

  test('different section or subject is an addition and removal, not a movement', () {
    final result = service.compare([lesson(1, 1, 1)], [lesson(1, 1, 1, subject: 3)]);
    expect(result.additions, hasLength(1));
    expect(result.removals, hasLength(1));
    expect(result.moves, isEmpty);
    expect(result.changedLessonCount, 2);
  });

  test('duplicate multiplicity is retained and missing copies are removed once', () {
    final result = service.compare(
      [lesson(1, 1, 1), lesson(1, 1, 1)], [lesson(1, 1, 1)],
    );
    expect(result.unchangedCount, 1);
    expect(result.removals, hasLength(1));
    expect(result.additions, isEmpty);
    expect(result.changedLessonCount, 1);
  });

  test('empty comparisons and room-only changes are represented explicitly', () {
    expect(service.compare([], []).toMap()['changedLessons'], 0);
    final before = {...lesson(1, 1, 1), 'room_id': 1};
    final after = {...lesson(1, 1, 1), 'room_id': 2};
    final comparison = service.compare([before], [after]);
    expect(comparison.changedLessonCount, 1);
    expect(comparison.changes.single.roomChanged, isTrue);
    expect(comparison.moves, isEmpty);
    expect(comparison.teacherChanges, isEmpty);
    before['day_id'] = 3;
    expect(comparison.changes.single.before!['day_id'], 1,
      reason: 'Preview must not mutate when its source map changes');
  });

  test('100 reordered multiset versions retain every unchanged semantic lesson', () {
    final random = Random(110);
    for (var trial = 0; trial < 100; trial++) {
      final original = List.generate(15, (i) => lesson(
        1 + random.nextInt(3), 1 + random.nextInt(5), 1 + random.nextInt(6),
        id: i, subject: 1 + random.nextInt(3), section: 1 + random.nextInt(3),
      ));
      final copy = original.map((row) => {...row, 'id': 500 + random.nextInt(100)}).toList()
        ..shuffle(random);
      final result = service.compare(original, copy);
      expect(result.unchangedCount, original.length);
      expect(result.changes, isEmpty);
    }
  });

  const days = <Map<String, Object?>>[
    {'id': 1, 'position': 0, 'is_active': 1},
    {'id': 2, 'position': 1, 'is_active': 1},
  ];
  const slots = <Map<String, Object?>>[
    {'id': 10, 'position': 0, 'kind': 'lesson', 'is_available': 1},
    {'id': 99, 'position': 1, 'kind': 'break', 'is_available': 1},
    {'id': 20, 'position': 2, 'kind': 'lesson', 'is_available': 1},
    {'id': 30, 'position': 3, 'kind': 'lesson', 'is_available': 1},
  ];
  test('teacher gaps count empty lesson periods inside a day, not breaks or empty edges', () {
    final quality = ScheduleComparisonService.evaluate(
      entries: [lesson(1, 1, 10), lesson(1, 1, 30), lesson(1, 2, 20)],
      slots: slots, days: days, requirements: [],
    );
    expect(quality.teacherGaps, 1);
    final consecutive = ScheduleComparisonService.evaluate(
      entries: [lesson(1, 1, 10), lesson(1, 1, 20)],
      slots: slots, days: days, requirements: [],
    );
    expect(consecutive.teacherGaps, 0);
  });

  test('rotating the same subject across days improves its timing metric', () {
    final repeated = ScheduleComparisonService.evaluate(
      entries: [lesson(1, 1, 10), lesson(1, 2, 10)],
      slots: slots, days: days, requirements: [],
    );
    final rotated = ScheduleComparisonService.evaluate(
      entries: [lesson(1, 1, 10), lesson(1, 2, 20)],
      slots: slots, days: days, requirements: [],
    );
    expect(rotated.subjectBalancePenalty, lessThan(repeated.subjectBalancePenalty));
  });

  test('the selected preference changes ranking while all metrics remain visible', () {
    const stable = ScheduleQuality(teacherGaps: 4, changedLessons: 1,
      subjectBalancePenalty: 8, lessonCount: 10);
    const compact = ScheduleQuality(teacherGaps: 0, changedLessons: 3,
      subjectBalancePenalty: 5, lessonCount: 10);
    expect(stable.scoreFor('minimal_changes'), lessThan(compact.scoreFor('minimal_changes')));
    expect(compact.scoreFor('teacher_gaps'), lessThan(stable.scoreFor('teacher_gaps')));
    expect(compact.toMap()['lessonCount'], 10);
  });
}
