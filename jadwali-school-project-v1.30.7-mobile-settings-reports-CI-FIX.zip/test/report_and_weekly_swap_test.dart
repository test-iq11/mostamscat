import 'package:flutter/services.dart';

import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iraqi_school_timetable/features/timetable/timetable_page.dart';
import 'package:iraqi_school_timetable/features/reports/reports_page.dart';
import 'package:iraqi_school_timetable/core/interface_settings.dart';
import 'package:iraqi_school_timetable/services/lesson_swap_service.dart';
import 'package:iraqi_school_timetable/core/theme.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';

class _TestPaths extends PathProviderPlatform {
  _TestPaths(this.directory);
  final String directory;
  @override
  Future<String> getApplicationSupportPath() async => directory;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  WidgetController.hitTestWarningShouldBeFatal = true;
  late Directory directory;
  late PathProviderPlatform previousPaths;
  setUpAll(() async {
    directory = await Directory.systemTemp.createTemp('jadwali-ui-');
    previousPaths = PathProviderPlatform.instance;
    PathProviderPlatform.instance = _TestPaths(directory.path);
    SharedPreferences.setMockInitialValues({});
    final input = jsonDecode(
      File('test/fixtures/backup_school_181.json').readAsStringSync(),
    ) as Map;
    List<Map<String, Object?>> rows(String key) => (input[key] as List)
        .map((r) => Map<String, Object?>.from(r as Map))
        .toList();
    final storage = DatabaseService.instance;
    final db = await storage.database;
    await db.transaction((txn) async {
      await txn.delete('time_slots');
      for (final slot in rows('slots')) {
        await txn.insert('time_slots', slot);
      }
      final known = (await txn.query('subjects')).map((s) => s['id']).toSet();
      for (final req in rows('requirements')) {
        if (known.add(req['subject_id']))
          await txn.insert('subjects', {
            'id': req['subject_id'],
            'name': 'مادة ${req['subject_id']}',
          });
      }
      for (final section in rows('sections')) {
        await txn.insert('sections', {
          'id': section['id'],
          'grade_id': section['grade_id'],
          'name': section['section_name'],
          'max_daily_lessons': 6,
        });
      }
      for (final t in rows('teachers')) {
        await txn.insert('teachers', t);
      }
      for (final q in rows('qualifications')) {
        await txn.insert('teacher_subjects', q);
      }
      for (final q in rows('teacherSubjectGrades')) {
        await txn.insert('teacher_subject_grades', q);
      }
      for (final r in rows('requirements')) {
        await txn.insert('section_subject_requirements', {
          for (final k in [
            'section_id',
            'subject_id',
            'weekly_lessons',
            'max_daily_lessons',
            'allow_same_day',
          ])
            k: r[k],
        });
      }
    });
    await storage.saveAsNewVersion(
      yearId: (await storage.activeYearId())!,
      name: 'الجدول النشط',
      entries: rows('initialPlacements'),
      requireComplete: true,
    );
  });
  tearDownAll(() async {
    await DatabaseService.instance.close();
    PathProviderPlatform.instance = previousPaths;
    await directory.delete(recursive: true);
  });
  Future<void> settle(WidgetTester tester) async {
    // Text fields may keep scheduling cursor frames; wait on data readiness,
    // not the absence of every animation in the application.
    for (var i = 0; i < 80; i++) {
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 30)),
      );
      await tester.pump(const Duration(milliseconds: 100));
      if (i >= 4 &&
          find
              .byWidgetPredicate(
                (w) =>
                    (w is CircularProgressIndicator && w.value == null) ||
                    (w is LinearProgressIndicator && w.value == null),
              )
              .evaluate()
              .isEmpty)
        break;
    }
    expect(
      find.byWidgetPredicate(
        (w) =>
            (w is CircularProgressIndicator && w.value == null) ||
            (w is LinearProgressIndicator && w.value == null),
      ),
      findsNothing,
    );
  }

  Future<void> reveal(WidgetTester tester, Finder target) async {
    await tester.ensureVisible(target);
    await tester.pumpAndSettle();
    await tester.ensureVisible(target);
    await tester.pumpAndSettle();
  }

  Future<void> fonts() async {
    for (final font in [
      ('JadwaliStudio', 'assets/fonts/UI-Regular.ttf'),
      ('JadwaliLatin', 'assets/fonts/UI-Latin.ttf'),
      ('MaterialIcons', 'fonts/MaterialIcons-Regular.otf'),
    ]) {
      await (FontLoader(font.$1)..addFont(rootBundle.load(font.$2))).load();
    }
  }

  for (final width in [320.0, 390.0, 1280.0]) {
    testWidgets(
      'weekly minimum scale with large text, selected cards and compact mode at $width',
      (tester) async {
        tester.view.physicalSize = Size(width, 900);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        InterfaceSettings.instance.compact = true;
        addTearDown(() => InterfaceSettings.instance.compact = false);
        await fonts();
        await tester.pumpWidget(
          MaterialApp(
            theme: buildAppTheme(),
            builder: (context, child) => MediaQuery(
              data: MediaQuery.of(context)
                  .copyWith(textScaler: const TextScaler.linear(1.3)),
              child: child!,
            ),
            home: Directionality(
              textDirection: TextDirection.rtl,
              child: TimetablePage(onChanged: () {}),
            ),
          ),
        );
        await settle(tester);
        await tester.tap(find.text('الأسبوع'));
        await settle(tester);
        final smaller = find.byTooltip('تصغير الخلايا');
        await reveal(tester, smaller);
        for (var i = 0; i < 4; i++) {
          await reveal(tester, smaller);
          await tester.tap(smaller);
          await tester.pump();
        }
        expect(
          tester
              .widget<IconButton>(
                find
                    .ancestor(of: smaller, matching: find.byType(IconButton))
                    .first,
              )
              .onPressed,
          isNull,
        );
        final lesson = find
            .byWidgetPredicate(
              (w) =>
                  w is InkWell &&
                  w.key is ValueKey<String> &&
                  (w.key as ValueKey<String>).value.startsWith('lesson-'),
            )
            .first;
        await reveal(tester, lesson);
        await tester.tap(lesson);
        await tester.pumpAndSettle();
        expect(find.text('✓ الأولى'), findsOneWidget);
        final parts = (tester.widget<InkWell>(lesson).key as ValueKey<String>)
            .value
            .split('-');
        await tester.longPress(lesson);
        await settle(tester);
        await tester.pumpAndSettle();
        final pinned = (await tester.runAsync(
          () => DatabaseService.instance.entriesDetailed(),
        ))!;
        expect(
          pinned.singleWhere(
            (e) =>
                e['section_id'] == int.parse(parts[1]) &&
                e['day_id'] == int.parse(parts[2]) &&
                e['slot_id'] == int.parse(parts[3]),
          )['is_locked'],
          1,
        );
        await tester.tap(find.text('تراجع'));
        await settle(tester);
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
        await tester.pumpWidget(const SizedBox());
        await tester.pump(const Duration(seconds: 2));
      },
    );
    testWidgets(
      'report swaps different subjects across days and undo restores exported data at $width',
      (tester) async {
        tester.view.physicalSize = Size(width, 900);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await fonts();
        final input = Map<String, Object?>.from(
          jsonDecode(
            File('test/fixtures/backup_school_181.json').readAsStringSync(),
          ) as Map,
        );
        final entries = (await tester.runAsync(
          () => DatabaseService.instance.entriesDetailed(),
        ))!;
        input['entries'] = entries;
        Map<String, Object?>? a, b;
        for (final first in entries) {
          if (!entries.any(
            (e) =>
                e['section_id'] == first['section_id'] &&
                e['subject_id'] == first['subject_id'] &&
                e['day_id'] != first['day_id'],
          ))
            continue;
          for (final second in entries) {
            if (first['section_id'] != second['section_id'] ||
                first['day_id'] == second['day_id'] ||
                first['subject_id'] == second['subject_id'])
              continue;
            if (const LessonSwapService().validate(input, first, second) ==
                null) {
              a = first;
              b = second;
              break;
            }
          }
          if (a != null) break;
        }
        final first = a!, second = b!;
        var changes = 0;
        await tester.pumpWidget(
          MaterialApp(
            theme: buildAppTheme(),
            home: Directionality(
              textDirection: TextDirection.rtl,
              child: ReportsPage(onChanged: () => changes++),
            ),
          ),
        );
        await settle(tester);
        await reveal(tester, find.text('التالي: المحتوى والورق'));
        await tester.tap(find.text('التالي: المحتوى والورق'));
        await tester.pumpAndSettle();
        await reveal(tester, find.text('معاينة التقرير'));
        await tester.tap(find.text('معاينة التقرير'));
        await tester.pumpAndSettle();
        Finder cell(Map<String, Object?> e) => find.byKey(
          ValueKey(
            'report-lesson-${e['section_id']}-${e['day_id']}-${e['slot_id']}',
          ),
        );
        await reveal(tester, cell(first));
        await tester.tap(cell(first));
        await tester.pump();
        final same = entries.firstWhere(
          (e) =>
              e['section_id'] == first['section_id'] &&
              e['subject_id'] == first['subject_id'] &&
              e['day_id'] != first['day_id'],
        );
        await reveal(tester, cell(same));
        await tester.tap(cell(same));
        await settle(tester);
        expect(find.text('هذا التبديل غير متاح'), findsOneWidget);
        expect(find.textContaining('مادة مختلفة'), findsWidgets);
        await tester.tap(find.text('اختيار حصة أخرى'));
        await tester.pumpAndSettle();
        await reveal(tester, cell(second));
        await tester.tap(cell(second));
        await settle(tester);
        await tester.pumpAndSettle();
        final after = (await tester.runAsync(
          () => DatabaseService.instance.entriesDetailed(),
        ))!;
        expect(
          after.singleWhere((e) => e['id'] == first['id'])['subject_id'],
          second['subject_id'],
        );
        final preview = tester.widget<ReferenceTimetablePreview>(
          find.byType(ReferenceTimetablePreview),
        );
        expect(
          preview.layout.entries.singleWhere(
            (e) => e['id'] == first['id'],
          )['subject_id'],
          second['subject_id'],
        );
        expect(after.length, 181);
        expect(changes, 1);
        final undo = find.byKey(const ValueKey('report-undo'));
        await reveal(tester, undo);
        await tester.tap(undo);
        await settle(tester);
        await tester.pumpAndSettle();
        final restored = (await tester.runAsync(
          () => DatabaseService.instance.entriesDetailed(),
        ))!;
        expect(
          restored.singleWhere((e) => e['id'] == first['id'])['subject_id'],
          first['subject_id'],
        );
        expect(changes, 2);
        expect(tester.takeException(), isNull);
        await tester.pumpWidget(const SizedBox());
        await tester.pump(const Duration(seconds: 2));
      },
    );
  }
}
