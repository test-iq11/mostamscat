import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/teacher_availability_policy.dart';
import 'package:iraqi_school_timetable/services/complete_schedule_solver.dart';
import 'package:iraqi_school_timetable/services/schedule_improvement_service.dart';

void main() {
  test('scoped denials are additive and unknown scopes stay optimistic', () {
    final policy = TeacherAvailabilityPolicy([
      {
        'teacher_id': 1,
        'day_id': 1,
        'slot_id': 1,
        'is_available': 0,
        'grade_id': 2,
        'subject_id': 3,
      },
      {
        'teacher_id': 1,
        'day_id': 1,
        'slot_id': 1,
        'is_available': 1,
        'grade_id': 2,
        'subject_id': 3,
      },
    ]);
    bool available(int? grade, int? subject) => policy.isAvailable(
      teacherId: 1,
      dayId: 1,
      slotId: 1,
      gradeId: grade,
      subjectId: subject,
    );
    expect(available(2, 3), isFalse);
    expect(available(1, 3), isTrue);
    expect(available(2, 4), isTrue);
    expect(available(null, null), isTrue);
    final global = TeacherAvailabilityPolicy([
      {'teacher_id': 1, 'day_id': 1, 'slot_id': 1, 'is_available': 0},
      {
        'teacher_id': 1,
        'day_id': 1,
        'slot_id': 1,
        'is_available': 1,
        'grade_id': 2,
        'subject_id': 3,
      },
    ]);
    expect(
      global.isAvailable(
        teacherId: 1,
        dayId: 1,
        slotId: 1,
        gradeId: 2,
        subjectId: 3,
      ),
      isFalse,
    );
  });

  test(
    'exact search and independent checker enforce grade and subject together',
    () {
      final input = <String, Object?>{
        'sections': [
          for (var i = 1; i <= 2; i++)
            {'id': i, 'grade_id': i, 'max_daily_lessons': 2},
        ],
        'teachers': [
          for (var i = 1; i <= 2; i++)
            {'id': i, 'weekly_load': 4, 'max_daily_lessons': 2},
        ],
        'requirements': [
          for (var i = 1; i <= 2; i++)
            for (var s = 1; s <= 2; s++)
              {'section_id': i, 'subject_id': s, 'weekly_lessons': 1},
        ],
        'qualifications': [
          for (var i = 1; i <= 2; i++)
            for (var s = 1; s <= 2; s++) {'teacher_id': i, 'subject_id': s},
        ],
        'days': [
          {'id': 1, 'name': 'الأحد', 'position': 0},
        ],
        'slots': [
          for (var p = 1; p <= 2; p++)
            {'id': p, 'position': p - 1, 'kind': 'lesson', 'is_available': 1},
        ],
        'teacherAvailability': [
          for (var p = 1; p <= 2; p++)
            {
              'teacher_id': 1,
              'day_id': 1,
              'slot_id': p,
              'is_available': 0,
              'grade_id': 1,
              'subject_id': 1,
            },
        ],
      };
      final result = const CompleteScheduleSolver().solve(input: input);
      expect(result.complete, isTrue);
      expect(
        ScheduleImprovementService.valid(input, result.placements),
        isTrue,
      );
      expect(
        result.placements.singleWhere(
          (r) => r['section_id'] == 1 && r['subject_id'] == 1,
        )['teacher_id'],
        2,
      );
      final bad = result.placements
          .map((r) => Map<String, Object?>.from(r))
          .toList();
      bad.singleWhere(
        (r) => r['section_id'] == 1 && r['subject_id'] == 1,
      )['teacher_id'] = 1;
      expect(ScheduleImprovementService.valid(input, bad), isFalse);
    },
  );
}
