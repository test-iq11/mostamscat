import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/schedule_integrity_audit.dart';
import 'package:iraqi_school_timetable/services/school_timetable_policy.dart';

void main() {
  final days = <Map<String, Object?>>[
    {'id': 1, 'name': 'الأحد', 'is_active': 1, 'position': 0},
    {'id': 2, 'name': 'الاثنين', 'is_active': 1, 'position': 1},
    {'id': 3, 'name': 'الثلاثاء', 'is_active': 1, 'position': 2},
    {'id': 4, 'name': 'الأربعاء', 'is_active': 1, 'position': 3},
    {'id': 5, 'name': 'الخميس', 'is_active': 1, 'position': 4},
  ];
  final slots = <Map<String, Object?>>[
    for (var i = 0; i < 7; i++)
      {'id': i + 1, 'position': i, 'kind': 'lesson', 'is_available': 1},
  ];
  final first = <String, Object?>{
    'grade_name': 'الأول الابتدائي',
    'max_daily_lessons': 6,
    'daily_limits_json': '{"1":6,"2":6,"3":4,"4":6,"5":6}',
  };
  test('Tuesday has four lessons while Monday remains six', () {
    expect(SchoolTimetablePolicy.dailyLimit(section: first, day: days[1],
        activeDays: days, lessonSlots: slots, weeklyDemand: 28), 6);
    expect(SchoolTimetablePolicy.dailyLimit(section: first, day: days[2],
        activeDays: days, lessonSlots: slots, weeklyDemand: 28), 4);
    expect(SchoolTimetablePolicy.weeklyCapacity(section: first,
        activeDays: days, lessonSlots: slots, weeklyDemand: 28), 28);
  });
  test('zero lessons prohibits that day without affecting other weekdays', () {
    final section = {...first,
      'daily_limits_json': '{"1":6,"2":6,"3":0,"4":6,"5":6}'};
    expect(SchoolTimetablePolicy.dailyLimit(section: section, day: days[2],
        activeDays: days, lessonSlots: slots, weeklyDemand: 24), 0);
    expect(SchoolTimetablePolicy.weeklyCapacity(section: section,
        activeDays: days, lessonSlots: slots, weeklyDemand: 24), 24);
  });
  test('sixth Sunday seventh is used only when weekly demand needs it', () {
    const section = <String, Object?>{
      'grade_name': 'السادس الابتدائي',
      'max_daily_lessons': 6,
      'daily_limits_json': '{"1":7,"2":6,"3":6,"4":6,"5":6}',
    };
    expect(SchoolTimetablePolicy.canUseSeventhPeriod(
      section: section, day: days.first, activeDays: days,
      lessonSlots: slots, weeklyDemand: 30), isFalse);
    expect(SchoolTimetablePolicy.canUseSeventhPeriod(
      section: section, day: days.first, activeDays: days,
      lessonSlots: slots, weeklyDemand: 31), isTrue);
  });
  test('independent timetable audit rejects a lesson after Tuesday limit', () {
    final section = <String, Object?>{...first, 'id': 1, 'grade_id': 1};
    final input = <String, Object?>{
      'sections': [section],
      'teachers': [<String, Object?>{'id': 9}],
      'days': days,
      'slots': slots,
      'requirements': [<String, Object?>{
        'section_id': 1, 'subject_id': 2, 'weekly_lessons': 1,
      }],
    };
    final placements = [<String, Object?>{
      'section_id': 1, 'subject_id': 2, 'teacher_id': 9,
      'day_id': 3, 'slot_id': 5,
    }];
    expect(const ScheduleIntegrityAudit().accepts(input, placements), isFalse);
    placements.single['slot_id'] = 4;
    expect(const ScheduleIntegrityAudit().accepts(input, placements), isTrue);
  });

  test('legacy count quota allows later periods but explicit day ends at its limit', () {
    final legacy = <String, Object?>{'max_daily_lessons': 1};
    expect(SchoolTimetablePolicy.dailyLimit(section: legacy, day: days[1],
        activeDays: days, lessonSlots: slots, weeklyDemand: 1), 1);
    expect(SchoolTimetablePolicy.periodLimit(section: legacy, day: days[1],
        activeDays: days, lessonSlots: slots, weeklyDemand: 1), 6);
    final explicit = <String, Object?>{...legacy, 'daily_limits_json': '{"2":1}'};
    expect(SchoolTimetablePolicy.periodLimit(section: explicit, day: days[1],
        activeDays: days, lessonSlots: slots, weeklyDemand: 1), 1);
  });

}
