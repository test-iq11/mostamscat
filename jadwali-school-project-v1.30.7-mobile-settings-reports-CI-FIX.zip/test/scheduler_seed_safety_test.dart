import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';

void main() {
  test('invalid active rows are rejected and the scheduler rebuilds a safe week', () {
    final result = const AutoSchedulerService(nodeLimit: 1000).generate(
      sections: [{'id': 1, 'grade_id': 1, 'max_daily_lessons': 1}],
      requirements: [{'section_id': 1, 'subject_id': 1, 'weekly_lessons': 2, 'allow_same_day': 0}],
      teachers: [{'id': 1, 'weekly_load': 2, 'max_daily_lessons': 1}],
      qualifications: [{'teacher_id': 1, 'subject_id': 1}],
      days: [{'id': 1, 'position': 1, 'is_active': 1}, {'id': 2, 'position': 2, 'is_active': 1}],
      slots: [{'id': 1, 'position': 1, 'kind': 'lesson', 'is_available': 1}],
      initialPlacements: [
        for (var id = 1; id <= 2; id++)
          {'id': id, 'section_id': 1, 'subject_id': 1, 'teacher_id': 1, 'day_id': 1, 'slot_id': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements.map((e) => e['day_id']).toSet(), {1, 2});
  });
}
