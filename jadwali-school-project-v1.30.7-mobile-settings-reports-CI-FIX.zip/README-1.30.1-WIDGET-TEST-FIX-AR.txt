جدولي 1.30.1 - معالجة تعليق اختبار بطاقة الحصص اليومية

العطل: انتهى اختبار grade_daily_interaction_130_test.dart بمهلة 10 دقائق دون AssertionFailure، بينما اجتازت اختبارات التحقق والتنقل.

السبب المرجح من الكود: إنشاء مجلد مؤقت وفتح SQLite FFI واستعلامه مباشرة داخل testWidgets في منطقة FakeAsync؛ وقد تنتظر عمليات I/O الحقيقي بلا تقدم.

الإصلاح: نقل تهيئة قاعدة البيانات وقراءتها الأولية وتنظيفها إلى setUpAll/tearDownAll (خارج FakeAsync)، واستخدام tester.runAsync لقراءة النتيجة بعد الحفظ. احتفظنا باختبار النقر والإنقاص والحفظ والتحقق من قاعدة SQLite الفعلية.

لا تعديلات على خوارزميات الجدولة أو واجهة Flutter أو التقارير.

لرفع المشروع المضغوط: ارفع jadwali-school-project-v1.30.1-widget-test-fix.zip إلى جذر GitHub كما هو، وضع ملف workflow من الحزمة في .github/workflows/build-apk.yml. تأكد من ظهور ZIP فعلًا في المستودع قبل تشغيل Actions.

التحقق المحلي: فحص سلامة المصدر والتغليف وملفات YAML واختبارات Python. بيئة العمل لا تحتوي على Flutter؛ نجاح Flutter/APK يتطلب GitHub Actions.
