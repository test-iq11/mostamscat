import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/reference_office_service.dart';
import 'package:iraqi_school_timetable/services/reference_timetable_layout.dart';
import 'package:iraqi_school_timetable/services/workload_report_palette.dart';
import 'package:iraqi_school_timetable/core/timetable_palette.dart';

void main() {
  const rows = <List<String>>[
    ['المعلم', 'النصاب', 'الموزع', 'المتبقي', 'الزيادة', 'أيام التدريس', 'الفجوات'],
    ['أحمد', '20', '20', '0', '0', '5', '0'],
    ['سارة', '20', '16', '4', '0', '4', '1'],
    ['علي', '20', '22', '0', '2', '5', '2'],
  ];

  test('teacher workload status maps to distinct printable pastel shades', () {
    final colors = WorkloadReportPalette.colors(rows);
    expect(colors, hasLength(rows.length));
    expect(colors.first, isNull);
    expect(colors[1], ReferenceTimetableLayout.dayColors[1]);
    expect(colors[2], ReferenceTimetableLayout.dayColors[2]);
    expect(colors[3], ReferenceTimetableLayout.dayColors[4]);
  });

  test('subject tint is opt-in for a teacher report and preserves school form', () {
    final layout = ReferenceTimetableLayout(
      entries: const [
        {'section_id': 1, 'day_id': 1, 'slot_id': 1,
         'subject_id': 3, 'subject_name': 'رياضيات', 'teacher_name': 'أحمد'},
      ],
      sections: const [{'id': 1, 'section_name': 'أ', 'max_daily_lessons': 1}],
      days: const [{'id': 1, 'name': 'الأحد', 'is_active': 1}],
      slots: const [{'id': 1, 'name': 'الأولى', 'kind': 'lesson', 'is_available': 1}],
      templateColumns: false,
    );
    const office = ReferenceOfficeService();
    String sheet(bool tinted) {
      final archive = ZipDecoder().decodeBytes(office.timetable(
        layout: layout, schoolName: 'مدرسة', word: false,
        colorTeacherSubjects: tinted,
      ));
      return utf8.decode(archive.findFile('xl/worksheets/sheet1.xml')!.readBytes()!);
    }
    final subjectStyle = 5 + 2 * (ReferenceTimetableLayout.dayColors.length +
        TimetablePalette.index(3));
    expect(sheet(false), contains('<c r="C5" s="5"'));
    expect(sheet(true), contains('<c r="C5" s="$subjectStyle"'));
    // Teacher column remains tinted with the day background in both versions.
    expect(sheet(true), contains('<c r="D5" s="5"'));
    final archive = ZipDecoder().decodeBytes(office.timetable(
      layout: layout, schoolName: 'مدرسة', word: true,
      colorTeacherSubjects: true,
    ));
    final doc = utf8.decode(archive.findFile('word/document.xml')!.readBytes()!);
    expect(doc, contains(TimetablePalette.tint(3)
        .toRadixString(16).substring(2).toUpperCase()));
  });

  test('teacher workload Word & Excel preserve the same printable colors', () {
    const service = ReferenceOfficeService();
    final colors = WorkloadReportPalette.colors(rows);
    final word = ZipDecoder().decodeBytes(service.list(
      title: 'نصاب المعلمين', schoolName: 'مدرستي', rows: rows,
      rowColors: colors, word: true,
    ));
    final document = utf8.decode(word.findFile('word/document.xml')!.readBytes()!);
    for (final color in colors.whereType<int>()) {
      expect(document, contains(color.toRadixString(16).substring(2).toUpperCase()));
    }
    final excel = ZipDecoder().decodeBytes(service.list(
      title: 'نصاب المعلمين', schoolName: 'مدرستي', rows: rows,
      rowColors: colors, word: false,
    ));
    final styles = utf8.decode(excel.findFile('xl/styles.xml')!.readBytes()!);
    final sheet = utf8.decode(excel.findFile('xl/worksheets/sheet1.xml')!.readBytes()!);
    for (final color in colors.whereType<int>()) {
      expect(styles, contains(color.toRadixString(16).toUpperCase()));
    }
    // Heading is row 1, spacer row 2, workload header row 3, and data
    // rows 4-6. The footer is row 8, not a fourth workload row.
    for (var index = 1; index < rows.length; index++) {
      final color = colors[index]!;
      final paletteIndex = ReferenceTimetableLayout.dayColors.indexOf(color);
      final expectedStyle = 5 + paletteIndex * 2;
      expect(sheet, contains('<c r="B${index + 3}" s="$expectedStyle"'),
          reason: 'workload row ${index + 3} must keep its palette fill');
    }
    expect(sheet, contains('<row r="8"'), reason: 'footer after workload rows');
  });
}

// The original school report must remain untouched. Subject tints are only
// active in the teacher-scoped export, whether Word or Excel.
