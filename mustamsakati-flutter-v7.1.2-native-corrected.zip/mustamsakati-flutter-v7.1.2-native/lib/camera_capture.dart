import 'dart:io';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

import 'card_geometry.dart';

class _CameraCropRequest {
  const _CameraCropRequest(this.bytes, this.viewport, this.frame);
  final Uint8List bytes;
  final Size viewport;
  final Rect frame;
}

/// Uses the same viewfinder geometry as the live guide. Runs off the UI
/// isolate to avoid blocking the shutter animation or preview.
Uint8List _cropToCameraGuide(_CameraCropRequest request) {
  final decoded = img.decodeImage(request.bytes);
  if (decoded == null) {
    throw const FormatException('تعذر قراءة صورة الكاميرا');
  }
  final upright = img.bakeOrientation(decoded);
  final rect = cameraFrameInPhoto(
    photoSize: Size(upright.width.toDouble(), upright.height.toDouble()),
    viewSize: request.viewport,
    frame: request.frame,
  );
  final x = rect.left.round().clamp(0, upright.width - 1).toInt();
  final y = rect.top.round().clamp(0, upright.height - 1).toInt();
  final width = rect.width.round().clamp(1, upright.width - x).toInt();
  final height = rect.height.round().clamp(1, upright.height - y).toInt();
  var cropped = img.copyCrop(upright, x: x, y: y, width: width, height: height);
  if (math.max(cropped.width, cropped.height) > 2400) {
    final scale = 2400 / math.max(cropped.width, cropped.height);
    cropped = img.copyResize(cropped,
        width: (cropped.width * scale).round().clamp(1, 2400).toInt(),
        height: (cropped.height * scale).round().clamp(1, 2400).toInt());
  }
  return Uint8List.fromList(img.encodeJpg(cropped, quality: 92));
}

class CardCameraScreen extends StatefulWidget {
  const CardCameraScreen({super.key, required this.card, required this.documentName});
  final bool card;
  final String documentName;

  @override
  State<CardCameraScreen> createState() => _CardCameraScreenState();
}

class _CardCameraScreenState extends State<CardCameraScreen>
    with WidgetsBindingObserver {
  CameraController? _controller;
  bool _busy = false;
  bool _initializing = true;
  String? _error;
  Size _viewSize = Size.zero;
  Rect _guide = Rect.zero;
  FlashMode _flash = FlashMode.off;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initialize();
  }

  Future<void> _initialize() async {
    if (mounted) {
      setState(() { _initializing = true; _error = null; });
    }
    CameraController? created;
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        throw StateError('لا تتوفر كاميرا على هذا الجهاز');
      }
      final camera = cameras.firstWhere(
          (c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => cameras.first);
      created = CameraController(camera, ResolutionPreset.high, enableAudio: false);
      await created.initialize();
      await created.setFlashMode(_flash);
      if (!mounted) {
        await created.dispose();
        return;
      }
      setState(() { _controller = created; _initializing = false; });
    } catch (e) {
      if (created != null) {
        await created.dispose();
      }
      if (mounted) {
        setState(() { _initializing = false; _error = 'تعذر تشغيل الكاميرا: $e'; });
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive) {
      final old = _controller;
      _controller = null;
      if (old != null) {
        old.dispose();
      }
    } else if (state == AppLifecycleState.resumed && _controller == null && !_busy) {
      _initialize();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    super.dispose();
  }

  Future<void> _takePhoto() async {
    final camera = _controller;
    if (camera == null || _busy || _viewSize.isEmpty || _guide.isEmpty) {
      return;
    }
    setState(() => _busy = true);
    try {
      final captured = await camera.takePicture();
      final data = await File(captured.path).readAsBytes();
      try {
        await File(captured.path).delete();
      } catch (_) {
        // Temporary camera file may already have been removed.
      }
      final output = await compute(_cropToCameraGuide,
          _CameraCropRequest(data, _viewSize, _guide));
      if (mounted) {
        Navigator.of(context).pop(output);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('تعذر التقاط الصورة: $e')));
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final camera = _controller;
    final dark = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: const Color(0xFF101B29),
      appBar: AppBar(
        title: Text(widget.documentName),
        foregroundColor: Colors.white,
        backgroundColor: const Color(0xFF152238),
        actions: [
          if (camera != null && camera.value.isInitialized)
            IconButton(
              tooltip: 'تبديل الفلاش',
              icon: Icon(_flash == FlashMode.off
                  ? Icons.flash_off_rounded : Icons.flash_auto_rounded),
              onPressed: () async {
                final next = _flash == FlashMode.off ? FlashMode.auto : FlashMode.off;
                try {
                  await camera.setFlashMode(next);
                  if (mounted) {
                    setState(() => _flash = next);
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('الفلاش غير مدعوم: $e')));
                  }
                }
              },
            ),
        ],
      ),
      body: Column(children: [
        Expanded(child: _initializing
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(26),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text(_error!, textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white)),
                      const SizedBox(height: 18),
                      OutlinedButton(onPressed: _initialize,
                          child: const Text('إعادة المحاولة')),
                    ])))
                : LayoutBuilder(builder: (context, constraints) {
                    _viewSize = Size(constraints.maxWidth, constraints.maxHeight);
                    _guide = frameForCamera(_viewSize, card: widget.card);
                    final preview = camera!.value.previewSize;
                    // Portrait coordinates of the camera's video preview.
                    final pw = preview?.height ?? 1080.0;
                    final ph = preview?.width ?? 1920.0;
                    return Stack(children: [
                      Positioned.fill(child: ClipRect(child: FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(width: pw, height: ph,
                          child: CameraPreview(camera)),
                      ))),
                      Positioned.fill(child: IgnorePointer(child: CustomPaint(
                        painter: _CameraGuidePainter(_guide),
                      ))),
                      Positioned(
                        top: math.max(12, _guide.top - 42),
                        left: 8, right: 8,
                        child: Center(child: DecoratedBox(
                          decoration: BoxDecoration(color: Colors.black54,
                            borderRadius: BorderRadius.circular(11)),
                          child: Padding(padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 7),
                            child: Text(widget.card ? 'طابق البطاقة داخل الإطار' : 'طابق المستند داخل الإطار',
                              style: const TextStyle(color: Colors.white)),
                          ),
                        )),
                      ),
                    ]);
                  })),
        Container(
          color: const Color(0xFF152238),
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
          child: Column(children: [
            Text(widget.card ? 'بطاقة 85.6 × 53.98 ملم — الطباعة بالحجم الطبيعي' :
              'راجع حدود المستند بعد الالتقاط',
              style: const TextStyle(color: Color(0xFFC5D5E5), fontSize: 12)),
            const SizedBox(height: 10),
            Center(child: FilledButton(
              onPressed: _busy || camera == null ? null : _takePhoto,
              style: FilledButton.styleFrom(
                backgroundColor: dark.primary,
                minimumSize: const Size(88, 66),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(32))),
              child: _busy
                  ? const SizedBox(width: 23, height: 23,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.camera_alt_rounded, size: 30),
            )),
          ]),
        ),
      ]),
    );
  }
}

class _CameraGuidePainter extends CustomPainter {
  const _CameraGuidePainter(this.guide);
  final Rect guide;

  @override
  void paint(Canvas canvas, Size size) {
    final outer = Path()..addRect(Offset.zero & size);
    final hole = Path()..addRRect(RRect.fromRectAndRadius(guide,
        const Radius.circular(15)));
    final shade = Path.combine(PathOperation.difference, outer, hole);
    canvas.drawPath(shade, Paint()..color = Colors.black.withValues(alpha: .58));
    canvas.drawRRect(RRect.fromRectAndRadius(guide, const Radius.circular(15)),
        Paint()..color = const Color(0xFF5DE6DB)
          ..strokeWidth = 3..style = PaintingStyle.stroke);
    const length = 25.0;
    final corners = [
      (Offset(guide.left, guide.top), 1.0, 1.0),
      (Offset(guide.right, guide.top), -1.0, 1.0),
      (Offset(guide.right, guide.bottom), -1.0, -1.0),
      (Offset(guide.left, guide.bottom), 1.0, -1.0),
    ];
    for (final point in corners) {
      final p = Path()..moveTo(point.$1.dx + length * point.$2, point.$1.dy)
        ..lineTo(point.$1.dx, point.$1.dy)
        ..lineTo(point.$1.dx, point.$1.dy + length * point.$3);
      canvas.drawPath(p, Paint()..color = Colors.white..strokeWidth = 4
          ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke);
    }
  }

  @override
  bool shouldRepaint(covariant _CameraGuidePainter old) => old.guide != guide;
}
