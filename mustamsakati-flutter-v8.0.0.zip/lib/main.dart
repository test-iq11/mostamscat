import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MustamsakatiApp());

class MustamsakatiApp extends StatelessWidget {
  const MustamsakatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مستمسكاتي',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF086858)),
      ),
      home: Scaffold(
        body: SafeArea(
          child: defaultTargetPlatform == TargetPlatform.android
              ? const AndroidView(viewType: 'mustamsakati/studio')
              : const Center(
                  child: Text(
                    'مستمسكاتي متاح على Android',
                    textDirection: TextDirection.rtl,
                  ),
                ),
        ),
      ),
    );
  }
}
