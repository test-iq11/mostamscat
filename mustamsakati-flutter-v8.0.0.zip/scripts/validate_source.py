"""Check the bundled interface and its contract with the Android host."""
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = root / 'android_overlay/src/main'
html = (source / 'assets/mustamsakati_studio.html').read_text(encoding='utf-8')
java = (source / 'java/iq/mustamsakati/mustamsakati/MainActivity.java').read_text(encoding='utf-8')


class StudioMarkup(HTMLParser):
    ids = set()
    modes = set()
    documents = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            assert attrs['id'] not in self.ids, f"Duplicate HTML ID: {attrs['id']}"
            self.ids.add(attrs['id'])
        if 'data-mode' in attrs:
            self.modes.add(attrs['data-mode'])
        if 'data-type' in attrs:
            self.documents.add(attrs['data-type'])
        assert not (tag in {'script', 'link', 'iframe'} and
                    ('src' in attrs or 'href' in attrs)), 'External UI resource'


markup = StudioMarkup()
markup.feed(html)
assert markup.modes == {'card', 'page', 'batch', 'receipt', 'passport', 'small'}
assert markup.documents == {'national', 'license', 'residence', 'passport', 'other'}
assert {'workspaceView', 'filesView', 'settingsView', 'layoutChoices'}.issubset(markup.ids)
assert 'mustamsakati/studio' in java
assert 'Content-Security-Policy' in html
for method in ('beginPdf', 'writePdf', 'finishPdf', 'abortPdf'):
    assert f'androidBridge.{method}(' in html
    assert re.search(r'@JavascriptInterface public synchronized \w+ '+method+r'\(', java)
script = re.search(r'<script>([\s\S]*?)</script>', html)
assert script
with tempfile.TemporaryDirectory() as temporary:
    js = Path(temporary) / 'studio.js'
    js.write_text(script.group(1), encoding='utf-8')
    subprocess.run(['node', '--check', str(js)], check=True)
print('Validated offline UI, IDs, scan modes and Android bridge entry points.')
