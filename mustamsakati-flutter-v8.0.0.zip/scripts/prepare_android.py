"""Apply the app's Android files to the Flutter-generated platform scaffold."""
from pathlib import Path
from shutil import copytree
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
scaffold = Path(sys.argv[1]).resolve() / 'android'
target = root / 'android'
if not scaffold.is_dir():
    sys.exit('Flutter Android scaffold is missing.')
copytree(scaffold, target, dirs_exist_ok=True)
app = target / 'app'
copytree(root / 'android_overlay', app, dirs_exist_ok=True)

manifest = app / 'src/main/AndroidManifest.xml'
ns = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ns)
attr = f'{{{ns}}}'
doc = ET.parse(manifest)
android = doc.getroot()
application = android.find('application')
if application is None:
    sys.exit('Flutter Android manifest is missing its application.')
android.insert(0, ET.Element('uses-permission', {attr+'name': 'android.permission.CAMERA'}))
android.insert(1, ET.Element('uses-feature', {
    attr+'name': 'android.hardware.camera.any',
    attr+'required': 'false',
}))
application.set(attr+'label', 'مستمسكاتي')
application.set(attr+'allowBackup', 'false')
application.set(attr+'usesCleartextTraffic', 'false')
application.set(attr+'enableOnBackInvokedCallback', 'false')
provider = ET.SubElement(application, 'provider', {
    attr+'name': 'androidx.core.content.FileProvider',
    attr+'authorities': '${applicationId}.files',
    attr+'exported': 'false',
    attr+'grantUriPermissions': 'true',
})
ET.SubElement(provider, 'meta-data', {
    attr+'name': 'android.support.FILE_PROVIDER_PATHS',
    attr+'resource': '@xml/studio_paths',
})
ET.indent(doc, space='    ')
doc.write(manifest, encoding='utf-8', xml_declaration=True)

gradle = app / 'build.gradle.kts'
if not gradle.is_file():
    sys.exit('Expected Flutter Kotlin DSL Android scaffold.')
source = gradle.read_text(encoding='utf-8')
marker = 'minSdk = flutter.minSdkVersion'
if marker not in source:
    sys.exit('Flutter scaffold changed its minSdk declaration.')
source = source.replace(marker, 'minSdk = 24', 1)
source += '\ndependencies {\n    implementation("androidx.core:core:1.13.1")\n}\n'
gradle.write_text(source, encoding='utf-8')
wrapper = target / 'gradle/wrapper/gradle-wrapper.properties'
if wrapper.is_file():
    text = wrapper.read_text(encoding='utf-8')
    text = text.replace('services.gradle.org/distributions/', 'downloads.gradle.org/distributions/')
    if 'networkTimeout=' not in text:
        text += '\nnetworkTimeout=120000\n'
    wrapper.write_text(text, encoding='utf-8')
