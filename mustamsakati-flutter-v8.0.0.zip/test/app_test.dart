import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mustamsakati/main.dart';

void main() {
  testWidgets('The app identifies the Android-only studio on other hosts',
      (tester) async {
    final previous = debugDefaultTargetPlatformOverride;
    debugDefaultTargetPlatformOverride = TargetPlatform.linux;
    try {
      await tester.pumpWidget(const MustamsakatiApp());
      expect(find.text('مستمسكاتي متاح على Android'), findsOneWidget);
    } finally {
      debugDefaultTargetPlatformOverride = previous;
    }
  });
}
