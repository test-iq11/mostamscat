package iq.mustamsakati.mustamsakati;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.StandardMessageCodec;
import io.flutter.plugin.platform.PlatformView;
import io.flutter.plugin.platform.PlatformViewFactory;

public final class MainActivity extends FlutterActivity {
    private static final String HOST = "studio.mustamsakati.invalid";
    private static final String HOME = "https://" + HOST + "/index.html";
    private static final String PDF = "application/pdf";
    private static final int PICK_IMAGE = 701;
    private static final int TAKE_PHOTO = 702;
    private static final int SAVE_PDF = 703;
    private static final int CAMERA_PERMISSION = 704;
    private static final long MAX_PDF_BYTES = 64L * 1024 * 1024;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final StudioBridge bridge = new StudioBridge();
    private WebView studio;
    private ValueCallback<Uri[]> imageCallback;
    private File cameraFile;
    private Uri cameraUri;
    private PermissionRequest webCameraRequest;
    private boolean pendingSystemCamera;
    private boolean cameraPermissionInFlight;
    private File pendingSave;

    @Override
    public void configureFlutterEngine(FlutterEngine engine) {
        super.configureFlutterEngine(engine);
        io.execute(() -> { cleanCache("studio-preview"); cleanCache("studio-camera"); });
        engine.getPlatformViewsController().getRegistry().registerViewFactory(
            "mustamsakati/studio", new PlatformViewFactory(StandardMessageCodec.INSTANCE) {
                @Override
                public PlatformView create(android.content.Context context, int viewId, Object args) {
                    final WebView view = createStudio(context);
                    return new PlatformView() {
                        @Override public View getView() { return view; }
                        @Override public void dispose() {
                            if (studio == view) studio = null;
                            finishImageRequest(null);
                            view.removeJavascriptInterface("MustamsakatiAndroid");
                            view.stopLoading();
                            view.destroy();
                        }
                    };
                }
            }
        );
    }

    private WebView createStudio(android.content.Context context) {
        WebView view = new WebView(context);
        studio = view;
        view.setBackgroundColor(0xfff3f6f9);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        view.addJavascriptInterface(bridge, "MustamsakatiAndroid");
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOME.equals(request.getUrl().toString());
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (HOME.equals(request.getUrl().toString()) && "GET".equals(request.getMethod())) {
                    try {
                        return new WebResourceResponse("text/html", "UTF-8", 200, "OK",
                            Collections.singletonMap("Cache-Control", "no-store"),
                            getAssets().open("mustamsakati_studio.html"));
                    } catch (IOException error) {
                        return emptyResponse(500, "Load Error");
                    }
                }
                String scheme = request.getUrl().getScheme();
                if ("data".equals(scheme) || "blob".equals(scheme) || "content".equals(scheme)) return null;
                return emptyResponse(404, "Not Found");
            }
        });
        view.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (!HOME.equals(webView.getUrl()) || imageCallback != null) {
                    callback.onReceiveValue(null);
                    return true;
                }
                imageCallback = callback;
                if (params.isCaptureEnabled()) {
                    requestSystemCamera();
                } else {
                    pickImages(params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                }
                return true;
            }

            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> requestWebCamera(request));
            }

            @Override public void onPermissionRequestCanceled(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (webCameraRequest == request) webCameraRequest = null;
                });
            }
        });
        view.loadUrl(HOME);
        return view;
    }

    private static WebResourceResponse emptyResponse(int status, String reason) {
        return new WebResourceResponse("text/plain", "UTF-8", status, reason,
            Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    private void pickImages(boolean multiple) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
        try {
            startActivityForResult(intent, PICK_IMAGE);
        } catch (RuntimeException error) {
            finishImageRequest(null);
            message("تعذّر فتح معرض الصور.");
        }
    }

    private void requestWebCamera(PermissionRequest request) {
        if (!"https".equals(request.getOrigin().getScheme())
                || !HOST.equals(request.getOrigin().getHost())
                || studio == null || !HOME.equals(studio.getUrl())
                || request.getResources().length != 1
                || !PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(request.getResources()[0])
                || cameraPermissionInFlight) {
            request.deny();
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        } else {
            webCameraRequest = request;
            askCameraPermission();
        }
    }

    private void requestSystemCamera() {
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchSystemCamera();
        } else if (cameraPermissionInFlight) {
            finishImageRequest(null);
        } else {
            pendingSystemCamera = true;
            askCameraPermission();
        }
    }

    private void askCameraPermission() {
        cameraPermissionInFlight = true;
        requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
    }

    private void launchSystemCamera() {
        if (imageCallback == null) return;
        try {
            cameraFile = File.createTempFile("capture-", ".jpg", cacheDir("studio-camera"));
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".files", cameraFile);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            intent.setClipData(ClipData.newRawUri("camera", cameraUri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, TAKE_PHOTO);
        } catch (IOException | RuntimeException error) {
            deleteFile(cameraFile);
            cameraFile = null;
            cameraUri = null;
            finishImageRequest(null);
            message("تعذّر فتح كاميرا الهاتف.");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != CAMERA_PERMISSION) return;
        cameraPermissionInFlight = false;
        boolean allowed = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        PermissionRequest request = webCameraRequest;
        webCameraRequest = null;
        if (request != null) {
            if (allowed && studio != null && HOME.equals(studio.getUrl())) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else request.deny();
        }
        if (pendingSystemCamera) {
            pendingSystemCamera = false;
            if (allowed) launchSystemCamera();
            else { finishImageRequest(null); message("إذن الكاميرا غير متاح."); }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int result, Intent data) {
        super.onActivityResult(requestCode, result, data);
        if (requestCode == PICK_IMAGE) {
            finishImageRequest(selectedImages(result, data));
        } else if (requestCode == TAKE_PHOTO) {
            Uri uri = cameraUri;
            File file = cameraFile;
            cameraUri = null;
            cameraFile = null;
            if (uri != null) revokeUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (result == Activity.RESULT_OK && uri != null && file != null && file.length() > 0) {
                finishImageRequest(new Uri[]{uri});
            } else {
                deleteFile(file);
                finishImageRequest(null);
            }
        } else if (requestCode == SAVE_PDF) {
            File file = pendingSave;
            pendingSave = null;
            Uri uri = data == null ? null : data.getData();
            if (file == null) return;
            if (result != Activity.RESULT_OK || uri == null) { deleteFile(file); return; }
            io.execute(() -> {
                try (InputStream in = new FileInputStream(file);
                     OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new IOException("Output unavailable");
                    copy(in, out, null);
                    runOnUiThread(() -> message("حُفظ ملف PDF."));
                } catch (IOException | RuntimeException error) {
                    runOnUiThread(() -> message("تعذّر حفظ ملف PDF."));
                } finally {
                    deleteFile(file);
                }
            });
        }
    }

    private static Uri[] selectedImages(int result, Intent data) {
        if (result != Activity.RESULT_OK || data == null) return null;
        Set<Uri> images = new LinkedHashSet<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount() && images.size() < 30; i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null && "content".equals(uri.getScheme())) images.add(uri);
            }
        }
        Uri uri = data.getData();
        if (images.size() < 30 && uri != null && "content".equals(uri.getScheme())) images.add(uri);
        return images.isEmpty() ? null : images.toArray(new Uri[0]);
    }

    private void finishImageRequest(Uri[] result) {
        ValueCallback<Uri[]> callback = imageCallback;
        imageCallback = null;
        if (callback != null) callback.onReceiveValue(result);
    }

    private void savePdf(File file, String title) {
        if (pendingSave != null) { deleteFile(file); message("أكمل الحفظ السابق أولاً."); return; }
        pendingSave = file;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(PDF);
        intent.putExtra(Intent.EXTRA_TITLE, title);
        try {
            startActivityForResult(intent, SAVE_PDF);
        } catch (RuntimeException error) {
            pendingSave = null;
            deleteFile(file);
            message("تعذّر فتح نافذة حفظ PDF.");
        }
    }

    private void openPdf(File file, String title) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, PDF);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (RuntimeException error) {
            message("تعذّر فتح عارض PDF. يمكنك حفظ الملف من نافذة التنزيل.");
            savePdf(file, title);
        }
    }

    private void printPdf(File file, String title, String paper, boolean landscape, int pages) {
        PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
        if (manager == null) { deleteFile(file); message("خدمة الطباعة غير متاحة."); return; }
        PrintAttributes.MediaSize size = "A5".equals(paper)
            ? PrintAttributes.MediaSize.ISO_A5 : PrintAttributes.MediaSize.ISO_A4;
        PrintAttributes attrs = new PrintAttributes.Builder()
            .setMediaSize(landscape ? size.asLandscape() : size.asPortrait())
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .setColorMode(PrintAttributes.COLOR_MODE_COLOR).build();
        try {
            manager.print(title, new PrintDocumentAdapter() {
                @Override public void onLayout(PrintAttributes oldAttrs, PrintAttributes newAttrs,
                        CancellationSignal cancel, LayoutResultCallback callback, Bundle extras) {
                    if (cancel.isCanceled()) { callback.onLayoutCancelled(); return; }
                    PrintDocumentInfo info = new PrintDocumentInfo.Builder(title)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(pages).build();
                    callback.onLayoutFinished(info, !newAttrs.equals(oldAttrs));
                }

                @Override public void onWrite(PageRange[] requested, ParcelFileDescriptor destination,
                        CancellationSignal cancel, WriteResultCallback callback) {
                    io.execute(() -> {
                        try (OutputStream out = new ParcelFileDescriptor.AutoCloseOutputStream(destination);
                             InputStream in = new FileInputStream(file)) {
                            copy(in, out, cancel);
                        } catch (IOException error) {
                            if (cancel.isCanceled()) callback.onWriteCancelled();
                            else callback.onWriteFailed("تعذّرت كتابة ملف الطباعة.");
                            return;
                        }
                        if (cancel.isCanceled()) callback.onWriteCancelled();
                        else callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                    });
                }

                @Override public void onFinish() { deleteFile(file); }
            }, attrs);
        } catch (RuntimeException error) {
            deleteFile(file);
            message("تعذّر فتح الطباعة.");
        }
    }

    private static void copy(InputStream in, OutputStream out, CancellationSignal cancel) throws IOException {
        byte[] buffer = new byte[32 * 1024];
        int count;
        while ((count = in.read(buffer)) >= 0) {
            if (cancel != null && cancel.isCanceled()) return;
            out.write(buffer, 0, count);
        }
    }

    private File cacheDir(String name) throws IOException {
        File dir = new File(getCacheDir(), name);
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory()) throw new IOException("Cache unavailable");
        return dir;
    }

    private void cleanCache(String name) {
        File[] files = new File(getCacheDir(), name).listFiles();
        long cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
        if (files != null) for (File file : files) if (file.lastModified() < cutoff) deleteFile(file);
    }

    private static void deleteFile(File file) {
        if (file != null) file.delete();
    }

    private void message(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        WebView view = studio;
        if (view == null) { super.onBackPressed(); return; }
        view.evaluateJavascript("window.studioAndroidBack && window.studioAndroidBack()", result -> {
            if (!"true".equals(result)) super.onBackPressed();
        });
    }

    @Override
    protected void onDestroy() {
        bridge.abortPdf();
        deleteFile(pendingSave);
        io.shutdown();
        super.onDestroy();
    }

    private final class StudioBridge {
        private File transfer;
        private FileOutputStream output;
        private long size;

        @JavascriptInterface public synchronized boolean beginPdf() {
            abortPdf();
            try {
                transfer = new File(cacheDir("studio-preview"), UUID.randomUUID() + ".pdf");
                output = new FileOutputStream(transfer);
                size = 0;
                return true;
            } catch (IOException error) {
                abortPdf();
                return false;
            }
        }

        @JavascriptInterface public synchronized boolean writePdf(String base64) {
            if (output == null || base64 == null || base64.length() > 90000) return false;
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (bytes.length == 0 || size + bytes.length > MAX_PDF_BYTES) {
                    abortPdf();
                    return false;
                }
                if (size == 0 && (bytes.length < 5
                        || !"%PDF-".equals(new String(bytes, 0, 5, StandardCharsets.US_ASCII)))) {
                    abortPdf();
                    return false;
                }
                output.write(bytes);
                size += bytes.length;
                return true;
            } catch (IOException | IllegalArgumentException error) {
                abortPdf();
                return false;
            }
        }

        @JavascriptInterface public synchronized boolean finishPdf(String action, String title,
                String paper, boolean landscape, int pages) {
            if (output == null || size < 8 || pages < 1 || pages > 50
                    || (!"save".equals(action) && !"open".equals(action) && !"print".equals(action))) {
                abortPdf();
                return false;
            }
            try { output.close(); } catch (IOException error) { abortPdf(); return false; }
            output = null;
            File file = transfer;
            transfer = null;
            size = 0;
            String clean = title == null ? "mustamsakati.pdf" : title.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "-").trim();
            if (clean.isEmpty()) clean = "mustamsakati.pdf";
            if (clean.length() > 96) clean = clean.substring(0, 92) + ".pdf";
            final String filename = clean;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) { deleteFile(file); return; }
                if ("save".equals(action)) savePdf(file, filename);
                else if ("open".equals(action)) openPdf(file, filename);
                else printPdf(file, filename, paper, landscape, pages);
            });
            return true;
        }

        @JavascriptInterface public synchronized void abortPdf() {
            if (output != null) {
                try { output.close(); } catch (IOException ignored) { }
                output = null;
            }
            deleteFile(transfer);
            transfer = null;
            size = 0;
        }
    }
}
