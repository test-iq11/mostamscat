#!/usr/bin/env python3
"""Fast source-level regression checks; does not replace flutter analyze."""
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
code = (root / 'lib/main.dart').read_text(encoding='utf-8')
manifest = (root / 'pubspec.yaml').read_text(encoding='utf-8')
assert 'version: 7.1.1+4' in manifest, 'Wrong project version selected'
assert 'separatorBuilder: (_, _)' not in code, 'Duplicate wildcard parameters'
assert 'identical(extra.original, source)) return;' not in code, 'Missing if braces'
assert "if (mounted) {\n                    ScaffoldMessenger.of(context)" not in code, 'BuildContext async safety regression'
# Ensure the repaired code is present, rather than only checking absence of old text.
assert re.search(r'!identical\(extra\.original, source\)\)\s*\{\s*return;\s*\}', code)
assert 'separatorBuilder: (context, index)' in code
assert "if (context.mounted) {\n                    ScaffoldMessenger.of(context)" in code
for expected in ('CardCameraScreen(', 'onPointerDown:', 'onPointerMove:',
                 '_ActualCornerLensPainter', 'extra.original = image;',
                 'frontOriginal = photo;', 'backOriginal = photo;'):
    assert expected in code, f'Missing fix: {expected}'
for path in ('lib/layouts.dart','lib/perspective.dart','lib/exporters.dart',
             'lib/scan_filters.dart', 'lib/card_geometry.dart',
             'lib/camera_capture.dart', 'test/layouts_test.dart',
             'test/card_geometry_test.dart', 'test/editor_drag_test.dart'):
    assert (root/path).is_file(), path
print('V7.1 static regression checks passed; run flutter analyze/test next')

# CI regressions observed on 2026-11-09. These failures are fatal under flutter analyze.
camera_code = (root / 'lib/camera_capture.dart').read_text(encoding='utf-8')
assert "import 'dart:typed_data';" not in camera_code, 'Redundant typed_data import in camera_capture.dart'
assert "import 'card_geometry.dart';" not in code, 'Unused card_geometry import in main.dart'
assert "if (context.mounted) {\n                    ScaffoldMessenger.of(context)" in camera_code, 'Unsafe camera flash callback context'
assert "if (mounted) {\n                    ScaffoldMessenger.of(context)" not in camera_code, 'Wrong mounted check for a local BuildContext'

# Regression checks for errors observed in the last GitHub Actions log.
camera_code = (root / 'lib/camera_capture.dart').read_text(encoding='utf-8')
assert "import 'dart:typed_data';" not in camera_code, 'Redundant dart:typed_data in camera_capture.dart'
assert "import 'card_geometry.dart';" not in code, 'Unused card_geometry.dart in main.dart'
assert "if (context.mounted) {\n                    ScaffoldMessenger.of(context)" in camera_code, 'Missing BuildContext.mounted safety check in camera flash callback'
assert "if (mounted) {\n                    ScaffoldMessenger.of(context)" not in camera_code, 'Wrong State.mounted guard around a local BuildContext'
