import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'exporters.dart';
import 'layouts.dart';
import 'perspective.dart';
import 'scan_filters.dart';
import 'camera_capture.dart';
import 'redaction.dart';
import 'vault.dart';

void main() => runApp(const MustamsakatiApp());

const _navy = Color(0xFF12344A);
const _brand = Color(0xFF086858);
const _blue = Color(0xFF4874EB);
const _pageBg = Color(0xFFF3F6F9);
const _types = <(String, IconData, String, Color, Color)>[
  ('البطاقة الوطنية', Icons.badge_outlined, 'الوجه الأمامي والخلفي', Color(0xFF5A79E8), Color(0xFFEDEEFF)),
  ('إجازة السوق', Icons.directions_car_outlined, 'رخصة القيادة', Color(0xFF15A98C), Color(0xFFE4F8F3)),
  ('بطاقة السكن', Icons.home_outlined, 'بيانات السكن', Color(0xFFEF913E), Color(0xFFFFF1E5)),
  ('جواز السفر', Icons.book_outlined, 'صفحة البيانات', Color(0xFF448FF0), Color(0xFFE7F3FF)),
  ('مستمسك آخر', Icons.post_add_outlined, 'أي وثيقة إضافية', Color(0xFF9675CE), Color(0xFFF0EAFC)),
];

const _accentPalette = <(String, Color)>[
  ('أخضر بحري', _brand),
  ('أزرق', Color(0xFF4874EB)),
  ('تركوازي', Color(0xFF138CA5)),
  ('أخضر', Color(0xFF239C78)),
  ('نعناعي', Color(0xFF27A9A1)),
  ('بنفسجي', Color(0xFF8061CF)),
  ('ليلكي', Color(0xFF9B70C6)),
  ('وردي', Color(0xFFCA688D)),
  ('مرجاني', Color(0xFFE37D67)),
  ('برتقالي', Color(0xFFE28B46)),
  ('ذهبي', Color(0xFFB99441)),
  ('كحلي', Color(0xFF305A88)),
  ('رمادي أزرق', Color(0xFF6E859E)),
];

const _captureModes = <(String, String, IconData, Color, Color, LayoutStyle, String)>[
  ('بطاقة في دقيقة', 'الوجه والظهر · حجم طبيعي', Icons.badge_outlined,
    Color(0xFF4771C9), Color(0xFFE5EEFF), LayoutStyle.sideTop, 'البطاقة الوطنية'),
  ('سكنر ورقة كاملة', 'مستند · ملء الورقة', Icons.description_outlined,
    Color(0xFF168A71), Color(0xFFE1F6ED), LayoutStyle.single, 'مستمسك آخر'),
  ('الجوازات', 'صفحة بيانات الجواز', Icons.menu_book_outlined,
    Color(0xFFBA8031), Color(0xFFFFF0DF), LayoutStyle.single, 'جواز السفر'),
  ('معاملة كاملة', 'رتّب المستمسكات في ملف واحد', Icons.auto_awesome_motion,
    Color(0xFF7960B1), Color(0xFFEFE9FF), LayoutStyle.verticalCenter, 'مستمسك آخر'),
  ('الإيصالات', 'فواتير وأوراق طويلة', Icons.receipt_long_outlined,
    Color(0xFFC87462), Color(0xFFFFEDE8), LayoutStyle.single, 'إيصال'),
  ('بطاقات صغيرة', 'صور متعددة بترتيب حر', Icons.dashboard_customize_outlined,
    Color(0xFF4C83B3), Color(0xFFE7F1F8), LayoutStyle.free, 'بطاقات صغيرة'),
];

class MustamsakatiApp extends StatefulWidget {
  const MustamsakatiApp({super.key});

  @override
  State<MustamsakatiApp> createState() => _MustamsakatiAppState();
}

class _MustamsakatiAppState extends State<MustamsakatiApp> {
  final PrintSettings _settings = PrintSettings()..accent = _brand;

  @override
  void initState() {
    super.initState();
    _restoreTheme();
  }

  Future<void> _restoreTheme() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _settings.dark = prefs.getBool('dark') ?? false;
        _settings.accent = Color(prefs.getInt('accent') ?? _brand.toARGB32());
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final seed = _settings.accent;
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: _settings.dark ? Brightness.dark : Brightness.light,
    ).copyWith(
      surface: _settings.dark ? const Color(0xFF182633) : Colors.white,
      onSurface: _settings.dark ? const Color(0xFFECF5FB) : const Color(0xFF142C3E),
      onSurfaceVariant: _settings.dark ? const Color(0xFFAFC4D1) : const Color(0xFF526A7A),
      outlineVariant: _settings.dark ? const Color(0xFF314452) : const Color(0xFFE0E8EE),
    );
    return MaterialApp(
      title: 'مستمسكاتي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        brightness: scheme.brightness,
        scaffoldBackgroundColor: _settings.dark
            ? const Color(0xFF101A24) : _pageBg,
        dialogTheme: DialogThemeData(
          backgroundColor: _settings.dark ? const Color(0xFF1A283A) : Colors.white,
        ),
        appBarTheme: AppBarThemeData(
          backgroundColor: _settings.dark ? const Color(0xFF182638) : Colors.white,
          foregroundColor: scheme.onSurface,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          color: scheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(
          minimumSize: const Size(0, 42),
          side: BorderSide(color: scheme.outlineVariant),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
        )),
        inputDecorationTheme: InputDecorationThemeData(
          isDense: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(9)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size(0, 42),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            backgroundColor: seed,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
          ),
        ),
      ),
      home: ScannerHome(settings: _settings, onThemeChange: () => setState(() {})),
    );
  }
}

class ScannerHome extends StatefulWidget {
  const ScannerHome({super.key, required this.settings, required this.onThemeChange});
  final PrintSettings settings;
  final VoidCallback onThemeChange;

  @override
  State<ScannerHome> createState() => _ScannerHomeState();
}

class _ScannerHomeState extends State<ScannerHome> {
  final ImagePicker _picker = ImagePicker();
  final List<ScanDocument> _documents = [ScanDocument('البطاقة الوطنية')];
  final TextEditingController _filename = TextEditingController(text: 'البطاقة الوطنية');
  int _navigation = 0;
  int _currentDoc = 0;
  int _visiblePage = 0;
  bool _busy = false;
  int _captureQuality = 86;
  bool _defaultA5 = false;
  bool _defaultLandscape = false;
  bool _autoCapture = false;
  bool _autoEnhance = false;
  LayoutStyle _defaultLayout = LayoutStyle.sideTop;
  String _captureMode = 'بطاقة في دقيقة';
  String? _processingPhoto;

  Color get _accent => widget.settings.accent;
  bool get _dark => widget.settings.dark;
  Color get _ink => Theme.of(context).colorScheme.onSurface;
  Color get _muted => Theme.of(context).colorScheme.onSurfaceVariant;
  Color _tileColor(Color color, Color light) => _dark
      ? Color.alphaBlend(color.withValues(alpha: .19),
          Theme.of(context).colorScheme.surface)
      : light;
  List<File> _saved = [];
  List<File> _vaultFiles = [];

  @override
  void initState() {
    super.initState();
    _loadSaved();
    _loadPreferences();
  }

  @override
  void dispose() {
    _filename.dispose();
    super.dispose();
  }

  Future<Directory> _outputDirectory() async {
    final directory = Directory('${(await getApplicationDocumentsDirectory()).path}/mustamsakati');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  Future<void> _loadSaved() async {
    try {
      final directory = await _outputDirectory();
      final files = await directory.list().where((item) => item is File).cast<File>().toList();
      files.sort((a, b) => b.path.compareTo(a.path));
      if (!mounted) return;
      setState(() {
        _saved = files.where((file) => file.path.endsWith('.pdf') ||
            file.path.endsWith('.docx')).toList();
        _vaultFiles = files.where((file) => file.path.endsWith('.msvault')).toList();
      });
    } catch (_) {
      if (mounted) _message('تعذّر قراءة الملفات المحفوظة');
    }
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _captureQuality = (prefs.getInt('capture_quality') ?? 86).clamp(65, 100).toInt();
      _defaultA5 = prefs.getBool('default_a5') ?? false;
      _defaultLandscape = prefs.getBool('default_landscape') ?? false;
      _autoCapture = prefs.getBool('auto_capture') ?? false;
      _autoEnhance = prefs.getBool('auto_enhance') ?? false;
      final layout = prefs.getString('default_layout');
      _defaultLayout = LayoutStyle.values.firstWhere((item) => item.name == layout,
          orElse: () => LayoutStyle.sideTop);
      if (_documents.every((doc) => doc.photos.isEmpty)) {
        _preparePrint(widget.settings.fillPage ? widget.settings.style : _defaultLayout,
            fillPage: widget.settings.fillPage);
      }
    });
  }

  void _preparePrint(LayoutStyle style, {required bool fillPage}) {
    widget.settings
      ..a5 = _defaultA5
      ..landscape = _defaultLandscape
      ..style = style
      ..fillPage = fillPage
      ..singleFace = style == LayoutStyle.single ? 0 : null
      ..scale = 1
      ..margin = 28
      ..gap = 14
      ..showCut = false;
    _visiblePage = 0;
  }

  Future<bool> _confirmNewDocument() async {
    if (!_documents.any((doc) => doc.photos.isNotEmpty)) return true;
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('بدء عمل جديد'),
      content: const Text('ستُستبدل الصور الحالية في مساحة العمل.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('متابعة')),
      ],
    ));
    return confirmed == true;
  }

  Future<void> _selectType(String label, {bool add = false}) async {
    if (!add) {
      if (label == _documents[_currentDoc].title) return;
      final confirmed = await _confirmNewDocument();
      if (!mounted || !confirmed) return;
    }
    setState(() {
      final document = ScanDocument(label);
      if (!add) {
        _documents.clear();
        _preparePrint(document.usesNaturalCardSize ? _defaultLayout : LayoutStyle.single,
            fillPage: !document.usesNaturalCardSize);
        _captureMode = document.usesNaturalCardSize ? 'بطاقة في دقيقة' :
            label == 'جواز السفر' ? 'الجوازات' : 'سكنر ورقة كاملة';
        _filename.text = label;
      }
      _documents.add(document);
      _currentDoc = _documents.length - 1;
      _navigation = 0;
    });
  }

  Future<void> _startCaptureMode(
      (String, String, IconData, Color, Color, LayoutStyle, String) mode) async {
    if (mode.$1 == _captureMode) return;
    final confirmed = await _confirmNewDocument();
    if (!mounted || !confirmed) return;
    setState(() {
      _captureMode = mode.$1;
      _preparePrint(mode.$1 == 'بطاقة في دقيقة' ? _defaultLayout : mode.$6,
          fillPage: mode.$6 == LayoutStyle.single);
      _documents.clear();
      _documents.add(ScanDocument(mode.$7));
      _filename.text = mode.$7;
      _currentDoc = 0;
      _navigation = 0;
    });
  }

  Future<void> _chooseKind() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('اختر نوع المستمسك'),
        contentPadding: const EdgeInsets.symmetric(vertical: 10),
        content: SizedBox(
          width: 340,
          child: ListView(shrinkWrap: true, children: [
            for (final entry in _types)
              ListTile(
                leading: Icon(entry.$2, color: entry.$4),
                title: Text(entry.$1),
                onTap: () {
                  Navigator.pop(dialogContext);
                  _selectType(entry.$1, add: true);
                },
              ),
          ]),
        ),
      ),
    );
  }

  Future<PhotoData> _photo(Uint8List bytes) async {
    // Decode only a screen-sized frame here; keep the original bytes untouched.
    // Full-resolution processing is deferred to scanner/editor/export actions.
    final codec = await ui.instantiateImageCodec(
      bytes, targetWidth: 1200, allowUpscaling: false);
    final frame = await codec.getNextFrame();
    final result = PhotoData(bytes, frame.image.width, frame.image.height);
    frame.image.dispose();
    codec.dispose();
    return result;
  }

  /// Capture once and display immediately. Choosing scanner is optional and
  /// uses a background isolate; the original JPEG/PNG remains recoverable.
  Future<void> _getPicture(bool back, ImageSource source) async {
    final target = _documents.isEmpty ? null : _documents[_currentDoc];
    if (target == null) {
      return;
    }
    try {
      final Uint8List bytes;
      if (source == ImageSource.camera) {
        final captured = await Navigator.push<Uint8List>(context,
          MaterialPageRoute(builder: (_) => CardCameraScreen(
            card: target.usesNaturalCardSize,
            documentName: target.title, autoCapture: _autoCapture,
          )),
        );
        if (captured == null) {
          return;
        }
        bytes = captured;
      } else {
        final file = await _picker.pickImage(
          source: source,
          maxWidth: 2400, maxHeight: 2400,
          imageQuality: _captureQuality,
          requestFullMetadata: false,
        );
        if (file == null) {
          return;
        }
        bytes = await file.readAsBytes();
      }
      final photo = await _photo(bytes);
      if (!mounted || !_documents.contains(target)) {
        return;
      }
      setState(() {
        if (back) {
          target.backOriginal = photo;
          target.back = photo;
          target.backAppearance = ScanAppearance.original;
        } else {
          target.frontOriginal = photo;
          target.front = photo;
          target.frontAppearance = ScanAppearance.original;
        }
      });
      if (!mounted) {
        return;
      }
      // The image is already on-screen before this small choice dialog.
      if (_autoEnhance) {
        await _setPhotoAppearance(target, back, ScanAppearance.smart);
      } else {
        await _askPhotoAppearance(target, back);
      }
    } catch (error) {
      if (mounted) {
        _message('تعذّر فتح الصورة: $error');
      }
    }
  }

  Future<void> _askPhotoAppearance(ScanDocument doc, bool back) async {
    final selected = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('كيف تريد الاحتفاظ بالصورة؟'),
        content: SizedBox(width: 345, child: Column(
          mainAxisSize: MainAxisSize.min, children: [
          const Text('اختر الصورة الأصلية أو أحد فلاتر السكنر. يمكنك الرجوع للأصل لاحقاً.',
            style: TextStyle(fontSize: 12, color: Color(0xFF7C899A))),
          const SizedBox(height: 14),
          _appearanceChoiceCard(
            icon: Icons.photo_outlined, title: 'الصورة الأصلية',
            subtitle: 'احتفظ بتفاصيل المستمسك والألوان دون تغيير',
            tint: const Color(0xFFE8F0FF),
            onTap: () => Navigator.pop(ctx, false)),
          const SizedBox(height: 10),
          _appearanceChoiceCard(
            icon: Icons.document_scanner_outlined, title: 'عمل سكنر للصورة',
            subtitle: 'اختر من 9 تحسينات بعد الالتقاط',
            tint: const Color(0xFFE3F6EE),
            onTap: () => Navigator.pop(ctx, true)),
        ])),
        actions: [TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('لاحقاً'))],
      ),
    );
    if (!mounted || !_documents.contains(doc)) {
      return;
    }
    if (selected == true) {
      final style = await _chooseScannerPreset(back ? doc.backOriginal : doc.frontOriginal);
      if (style != null && mounted) {
        await _setPhotoAppearance(doc, back, style);
      }
    } else if (selected == false) {
      await _setPhotoAppearance(doc, back, ScanAppearance.original);
    }
  }

  Future<ScanAppearance?> _chooseScannerPreset(PhotoData? original) async {
    if (original == null) {
      return null;
    }
    return showDialog<ScanAppearance>(context: context, builder: (ctx) {
      var chosen = ScanAppearance.smart;
      return StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
        title: const Text('اختر وضع السكنر'),
        contentPadding: const EdgeInsets.fromLTRB(12, 14, 12, 4),
        content: SizedBox(width: 365, child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(height: 144, width: double.infinity,
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHigh,
                borderRadius: BorderRadius.circular(14)),
              child: ClipRRect(borderRadius: BorderRadius.circular(14),
                child: ColorFiltered(
                  colorFilter: _scanPreviewFilter(chosen),
                  child: Image.memory(original.bytes, fit: BoxFit.contain,
                    filterQuality: FilterQuality.low)))),
            const SizedBox(height: 7),
            Text(chosen.description, style: const TextStyle(fontSize: 11)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              itemCount: ScanAppearance.values.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, mainAxisSpacing: 7,
                crossAxisSpacing: 7, childAspectRatio: 1.36),
              itemBuilder: (_, i) {
                final style = ScanAppearance.values[i];
                final picked = style == chosen;
                return InkWell(
                  onTap: () => setDialog(() => chosen = style),
                  borderRadius: BorderRadius.circular(12),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: picked ? _tileColor(const Color(0xFF148A77),
                          const Color(0xFFE2F3EF))
                          : Theme.of(context).colorScheme.surfaceContainerLow,
                      border: Border.all(color: picked ? const Color(0xFF148A77)
                        : Theme.of(context).colorScheme.outlineVariant, width: picked ? 2 : 1)),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(style.icon, size: 23,
                        color: picked ? const Color(0xFF138870) : const Color(0xFF7187A3)),
                      const SizedBox(height: 4),
                      Text(style.label, style: const TextStyle(fontSize: 10,
                        fontWeight: FontWeight.w700), textAlign: TextAlign.center),
                    ]),
                  ),
                );
              },
            ),
            const SizedBox(height: 7),
            const Text('الصورة الأصلية تبقى محفوظة ويمكن استعادتها.',
              style: TextStyle(fontSize: 10, color: Color(0xFF2E977E))),
          ]))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, chosen),
            child: const Text('تطبيق السكنر')),
        ],
      ));
    });
  }

  ColorFilter _scanPreviewFilter(ScanAppearance preset) {
    if (preset == ScanAppearance.original) {
      return const ColorFilter.mode(Colors.transparent, BlendMode.dst);
    }
    if (preset == ScanAppearance.gray || preset == ScanAppearance.blackWhite ||
        preset == ScanAppearance.whitePaper) {
      const r = .299, g = .587, b = .114;
      return ColorFilter.matrix([
        r, g, b, 0, 0,
        r, g, b, 0, 0,
        r, g, b, 0, 0,
        0, 0, 0, 1, 0,
      ]);
    }
    final brightness = switch (preset) {
      ScanAppearance.smart => 9.0,
      ScanAppearance.color => 10.0,
      ScanAppearance.soft => 5.0,
      _ => 8.0,
    };
    final contrast = switch (preset) {
      ScanAppearance.highContrast => 1.55,
      ScanAppearance.smart => 1.18,
      ScanAppearance.color => 1.16,
      _ => 1.08,
    };
    final offset = 128 * (1 - contrast) + brightness;
    return ColorFilter.matrix([
      contrast, 0, 0, 0, offset + (preset == ScanAppearance.warm ? 10 : 0),
      0, contrast, 0, 0, offset,
      0, 0, contrast, 0, offset + (preset == ScanAppearance.cool ? 10 : 0),
      0, 0, 0, 1, 0,
    ]);
  }

  Widget _appearanceChoiceCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color tint,
    required VoidCallback onTap,
  }) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: _tileColor(_accent, tint),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(children: [
        Icon(icon, size: 27, color: _ink),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: _ink, fontSize: 14,
            fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text(subtitle, style: TextStyle(color: _muted,
            fontSize: 10, height: 1.5)),
        ])),
        Icon(Icons.chevron_left_rounded, color: _ink),
      ]),
    ),
  );

  Future<void> _setPhotoAppearance(
      ScanDocument doc, bool back, ScanAppearance appearance) async {
    final original = back ? doc.backOriginal : doc.frontOriginal;
    if (original == null) {
      return;
    }
    if (appearance == ScanAppearance.original) {
      setState(() {
        if (back) {
          doc.back = original;
          doc.backAppearance = appearance;
        } else {
          doc.front = original;
          doc.frontAppearance = appearance;
        }
      });
      return;
    }
    if (_processingPhoto != null) {
      return;
    }
    final token = '${_documents.indexOf(doc)}_${back ? 'back' : 'front'}';
    setState(() => _processingPhoto = token);
    try {
      final bytes = await scanImageAsync(original.bytes, appearance);
      final decoded = await _photo(bytes);
      // A scanner filter changes pixels, never the photograph's print geometry.
      // Keep the original preview aspect, avoiding a sudden resize in layouts.
      final processed = PhotoData(bytes, original.width, original.height);
      if (decoded.width <= 0 || decoded.height <= 0) {
        throw const FormatException('تعذر معالجة الصورة');
      }
      if (!mounted || !_documents.contains(doc) ||
          !identical(back ? doc.backOriginal : doc.frontOriginal, original)) {
        return;
      }
      setState(() {
        if (back) {
          doc.back = processed;
          doc.backAppearance = appearance;
        } else {
          doc.front = processed;
          doc.frontAppearance = appearance;
        }
      });
    } catch (error) {
      if (mounted) {
        _message('تعذّر تطبيق السكنر: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _processingPhoto = null);
      }
    }
  }

  Future<void> _getExtraPicture(ScanDocument doc, ExtraScanPage extra,
      ImageSource source) async {
    try {
      final Uint8List bytes;
      if (source == ImageSource.camera) {
        final captured = await Navigator.push<Uint8List>(context,
          MaterialPageRoute(builder: (_) => CardCameraScreen(
            card: doc.usesNaturalCardSize, documentName: doc.title,
            autoCapture: _autoCapture,
          )),
        );
        if (captured == null) {
          return;
        }
        bytes = captured;
      } else {
        final file = await _picker.pickImage(source: source,
          maxWidth: 2400, maxHeight: 2400,
          imageQuality: _captureQuality, requestFullMetadata: false);
        if (file == null) {
          return;
        }
        bytes = await file.readAsBytes();
      }
      final photo = await _photo(bytes);
      if (!mounted || !_documents.contains(doc) || !doc.extras.contains(extra)) {
        return;
      }
      setState(() {
        extra.original = photo;
        extra.image = photo;
        extra.appearance = ScanAppearance.original;
      });
      if (!mounted) {
        return;
      }
      if (_autoEnhance) {
        await _setExtraAppearance(doc, extra, ScanAppearance.smart);
        return;
      }
      final useScanner = await showDialog<bool>(context: context, builder: (ctx) =>
        AlertDialog(title: const Text('الصورة الأصلية أم السكنر؟'),
          content: const Text('يمكنك تحسين الصفحة أو الاحتفاظ بالصورة الأصلية.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('الأصلية')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true),
              child: const Text('السكنر')),
          ]));
      if (useScanner == true && mounted) {
        final appearance = await _chooseScannerPreset(extra.original);
        if (appearance != null && mounted) {
          await _setExtraAppearance(doc, extra, appearance);
        }
      }
    } catch (error) {
      if (mounted) {
        _message('تعذّر إضافة الصفحة: $error');
      }
    }
  }

  Future<void> _setExtraAppearance(ScanDocument doc,
      ExtraScanPage extra, ScanAppearance appearance) async {
    final source = extra.original;
    if (source == null) {
      return;
    }
    if (appearance == ScanAppearance.original) {
      setState(() { extra.image = source; extra.appearance = appearance; });
      return;
    }
    if (_processingPhoto != null) {
      return;
    }
    setState(() => _processingPhoto = 'extra');
    try {
      final data = await scanImageAsync(source.bytes, appearance);
      final decoded = await _photo(data);
      final image = PhotoData(data, source.width, source.height);
      if (decoded.width <= 0 || decoded.height <= 0) {
        throw const FormatException('تعذر معالجة الصفحة');
      }
      if (!mounted || !doc.extras.contains(extra) ||
          !identical(extra.original, source)) {
        return;
      }
      setState(() { extra.image = image; extra.appearance = appearance; });
    } catch (error) {
      if (mounted) {
        _message('تعذّرت معالجة الصورة: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _processingPhoto = null);
      }
    }
  }

  Future<void> _editExtra(ScanDocument doc, ExtraScanPage extra) async {
    if (extra.image == null) {
      return;
    }
    final image = await Navigator.push<PhotoData>(context,
      MaterialPageRoute(builder: (_) => CornerEditor(photo: extra.image!)));
    if (image != null && mounted && doc.extras.contains(extra)) {
      setState(() {
        // The corrected quadrilateral is the new scanner source; otherwise
        // choosing a filter would restore the full-size pre-crop photograph.
        extra.image = image;
        extra.original = image;
        extra.appearance = ScanAppearance.original;
      });
    }
  }

  Future<void> _demo() async {
    final confirmed = await _confirmNewDocument();
    if (!mounted || !confirmed) return;
    final current = _documents[_currentDoc];
    try {
      final asset = current.usesNaturalCardSize ? 'sample_front.jpg' :
        current.title == 'إيصال' ? 'sample_receipt.jpg' : 'sample_document.jpg';
      final first = await rootBundle.load('assets/demo/$asset');
      final photoA = await _photo(first.buffer.asUint8List(first.offsetInBytes, first.lengthInBytes));
      PhotoData? photoB;
      if (current.usesNaturalCardSize) {
        final second = await rootBundle.load('assets/demo/sample_back.jpg');
        photoB = await _photo(second.buffer.asUint8List(second.offsetInBytes, second.lengthInBytes));
      }
      if (!mounted) return;
      setState(() {
        _documents
          ..clear()
          ..add(ScanDocument(current.title)
            ..front = photoA
            ..frontOriginal = photoA
            ..back = photoB
            ..backOriginal = photoB);
        _filename.text = '${current.title} - عينة';
        _currentDoc = 0;
        _visiblePage = 0;
        _navigation = 0;
      });
    } catch (e) {
      if (mounted) _message('تعذرت تجربة الصور: $e');
    }
  }

  Future<void> _editImage(bool back, {ScanDocument? owner}) async {
    final document = owner ?? _documents[_currentDoc];
    final source = back ? document.back : document.front;
    if (source == null) {
      return;
    }
    final photo = await Navigator.push<PhotoData>(
      context,
      MaterialPageRoute(builder: (_) => CornerEditor(photo: source)),
    );
    if (photo == null || !mounted || !_documents.contains(document)) {
      return;
    }
    setState(() {
      if (back) {
        document.back = photo;
        document.backOriginal = photo;
        document.backAppearance = ScanAppearance.original;
      } else {
        document.front = photo;
        document.frontOriginal = photo;
        document.frontAppearance = ScanAppearance.original;
      }
    });
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  List<LayoutSheet> get _sheets => [
    for (final document in _documents) ...layoutDocument(document, widget.settings),
  ];

  Future<void> _export(bool word, {bool redact = false}) async {
    var sheets = _sheets;
    if (sheets.isEmpty) {
      _message('أضف صورة واحدة على الأقل أولاً');
      return;
    }
    Map<PhotoData, List<Rect>>? redactions;
    if (redact) {
      final photos = {for (final sheet in sheets)
        for (final item in sheet.placements) item.photo}.toList();
      redactions = await Navigator.push<Map<PhotoData, List<Rect>>>(context,
        MaterialPageRoute(builder: (_) => RedactionEditor(photos: photos)));
      if (!mounted || redactions == null) return;
    }
    setState(() => _busy = true);
    try {
      if (redactions != null) {
        final replacements = <PhotoData, PhotoData>{};
        for (final entry in redactions.entries) {
          if (entry.value.isNotEmpty) {
            replacements[entry.key] = await compute(burnRedactions, (entry.key, entry.value));
          }
        }
        sheets = [
          for (final sheet in sheets)
            LayoutSheet([
              for (final item in sheet.placements)
                ImagePlacement(replacements[item.photo] ?? item.photo, item.rect, item.index),
            ], cutLine: sheet.cutLine),
        ];
      }
      final data = word
          ? Exporter.makeDocx(sheets, widget.settings)
          : await Exporter.makePdf(sheets, widget.settings);
      final originalName = _filename.text.trim().isEmpty
          ? 'مستمسكاتي'
          : _filename.text.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
      final filename = redact ? '$originalName - نسخة مشاركة' : originalName;
      final extension = word ? 'docx' : 'pdf';
      final directory = await _outputDirectory();
      final saved = File('${directory.path}/${filename}_${DateTime.now().millisecondsSinceEpoch}.$extension');
      await saved.writeAsBytes(data, flush: true);
      await _loadSaved();
      if (!mounted) {
        return;
      }
      _message('تم حفظ ${word ? 'Word' : 'PDF'} داخل ملفات التطبيق');
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('تم إنشاء الملف بنجاح'),
          content: Text(saved.path.split('/').last),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
            TextButton(
              onPressed: () async {
                Navigator.pop(ctx);
                try {
                  await FilePicker.platform.saveFile(
                    dialogTitle: 'اختر مكان الحفظ',
                    fileName: '$filename.$extension',
                    bytes: data,
                  );
                } catch (_) {
                  if (mounted) {
                    _message('يمكن مشاركة الملف واختيار «حفظ في الملفات»');
                  }
                }
              },
              child: const Text('حفظ في مجلد'),
            ),
            FilledButton(
              onPressed: () async {
                Navigator.pop(ctx);
                await _shareFile(saved);
              },
              child: const Text('مشاركة'),
            ),
          ],
        ),
      );
    } catch (error) {
      if (mounted) {
        _message('فشل إنشاء المستند: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<String?> _vaultPassword({required bool saving}) async {
    var password = '';
    return showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (context, update) =>
        AlertDialog(
          title: Text(saving ? 'حفظ في الخزنة المشفّرة' : 'فتح معاملة مشفّرة'),
          content: TextField(
            obscureText: true,
            autofocus: true,
            autocorrect: false,
            enableSuggestions: false,
            maxLength: 128,
            onChanged: (value) => update(() => password = value),
            decoration: InputDecoration(
              labelText: 'عبارة المرور',
              helperText: saving ? 'ثمانية أحرف على الأقل' : null,
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
            FilledButton(
              onPressed: password.length < (saving ? 8 : 1) ? null :
                  () => Navigator.pop(dialogContext, password),
              child: Text(saving ? 'تشفير وحفظ' : 'فتح المعاملة'),
            ),
          ],
        )),
    );
  }

  Future<void> _saveToVault() async {
    final password = await _vaultPassword(saving: true);
    if (!mounted || password == null) return;
    final draft = VaultDraft(_documents, _filename.text, widget.settings);
    setState(() => _busy = true);
    File? temporary;
    try {
      final bytes = await compute(sealVault, (draft, password));
      final directory = await _outputDirectory();
      final file = File('${directory.path}/draft_${DateTime.now().microsecondsSinceEpoch}.msvault');
      temporary = File('${file.path}.tmp');
      await temporary.writeAsBytes(bytes, flush: true);
      await temporary.rename(file.path);
      temporary = null;
      await _loadSaved();
      if (mounted) _message('حُفظت المعاملة مشفّرة');
    } catch (_) {
      if (mounted) _message('تعذّر حفظ المعاملة في الخزنة');
    } finally {
      final remaining = temporary;
      if (remaining != null) {
        try { await remaining.delete(); } on FileSystemException { /* No completed draft. */ }
      }
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restoreFromVault(File file) async {
    final password = await _vaultPassword(saving: false);
    if (!mounted || password == null) return;
    if (_documents.any((doc) => doc.photos.isNotEmpty)) {
      final replace = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('استبدال العمل الحالي؟'),
        content: const Text('فتح هذه المعاملة يستبدل الصور الموجودة في مساحة العمل.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('فتح')),
        ],
      ));
      if (!mounted || replace != true) return;
    }
    setState(() => _busy = true);
    try {
      final bytes = await file.readAsBytes();
      final draft = await compute(openVault, (bytes, password));
      if (!mounted) return;
      setState(() {
        final saved = draft.settings;
        widget.settings
          ..a5 = saved.a5
          ..landscape = saved.landscape
          ..margin = saved.margin
          ..gap = saved.gap
          ..scale = saved.scale
          ..style = saved.style
          ..fillPage = saved.fillPage
          ..singleFace = saved.singleFace
          ..showCut = saved.showCut;
        _documents..clear()..addAll(draft.documents);
        _filename.text = draft.filename;
        _currentDoc = 0;
        _visiblePage = 0;
        _captureMode = 'معاملة محفوظة';
        _navigation = 0;
      });
    } catch (_) {
      if (mounted) _message('تعذّر فتح المعاملة. تأكّد من عبارة المرور وسلامة الملف.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteSaved(File file) async {
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('حذف الملف؟'),
      content: const Text('سيُحذف الملف من مستمسكاتي.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
      ],
    ));
    if (confirmed != true || !mounted) return;
    try {
      await file.delete();
      await _loadSaved();
    } catch (_) {
      if (mounted) _message('تعذّر حذف الملف');
    }
  }

  Future<void> _openSavedPdf(File file) async {
    await Navigator.push<void>(
    context,
    MaterialPageRoute(builder: (_) => Scaffold(
      appBar: AppBar(title: const Text('معاينة PDF')),
      body: PdfPreview(
        build: (_) => file.readAsBytes(),
        canChangePageFormat: false,
        canChangeOrientation: false,
        canDebug: false,
        pdfFileName: file.uri.pathSegments.last,
      ),
    )),
    );
  }

  Future<void> _shareFile(File file) async {
    try {
      await SharePlus.instance.share(ShareParams(files: [XFile(file.path)]));
    } catch (error) {
      if (mounted) {
        _message('تعذرت المشاركة: $error');
      }
    }
  }

  Future<void> _printPdf() async {
    try {
      if (_sheets.isEmpty) {
        return;
      }
      await Printing.layoutPdf(onLayout: (_) => Exporter.makePdf(_sheets, widget.settings));
    } catch (error) {
      if (mounted) {
        _message('تعذرت الطباعة: $error');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 61,
        titleSpacing: 11,
        backgroundColor: scheme.surface,
        title: Row(children: [
          Container(width: 43, height: 43,
            decoration: BoxDecoration(color: _accent, borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.document_scanner_outlined, color: Colors.white, size: 24)),
          const SizedBox(width: 10),
          const Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('مستمسكاتي', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            Text('استوديو المستندات', style: TextStyle(fontSize: 11)),
          ])),
        ]),
        actions: [
          IconButton(tooltip: 'الخزنة', icon: const Icon(Icons.lock_outline),
            onPressed: _busy ? null : () => setState(() => _navigation = 1)),
          IconButton(tooltip: 'تبديل الوضع الليلي',
            icon: Icon(_dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
            onPressed: _busy ? null : () async {
              widget.settings.dark = !_dark;
              final value = widget.settings.dark;
              widget.onThemeChange();
              final prefs = await SharedPreferences.getInstance();
              await prefs.setBool('dark', value);
            }),
          const SizedBox(width: 4),
        ],
        bottom: PreferredSize(preferredSize: const Size.fromHeight(55),
          child: Padding(padding: const EdgeInsets.fromLTRB(11, 2, 11, 8),
            child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 480),
              child: Row(children: [
                for (final (index, label, icon) in const [
                  (0, 'الرئيسية', Icons.home_outlined),
                  (1, 'ملفاتي', Icons.folder_outlined),
                  (2, 'الإعدادات', Icons.settings_outlined),
                ]) ...[
                  if (index > 0) const SizedBox(width: 6),
                  Expanded(child: OutlinedButton.icon(
                    onPressed: _busy ? null : () => setState(() => _navigation = index),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: _navigation == index ? _mint : scheme.surface,
                      foregroundColor: _navigation == index ? scheme.primary : _ink,
                      side: BorderSide(color: _navigation == index ? _accent : scheme.outlineVariant),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                    ),
                    icon: Icon(icon, size: 17),
                    label: Text(label, style: const TextStyle(fontSize: 12)),
                  )),
                ],
              ]),
            ),
          )),
      ),
      body: SafeArea(
        child: Stack(fit: StackFit.expand, children: [
          _navigation == 1 ? _filesPage() : _navigation == 2 ? _settingsPage() : _homePage(),
          if (_busy)
            const ColoredBox(color: Colors.black45, child: Center(child: Card(child: Padding(
              padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min,
                children: [CircularProgressIndicator(), SizedBox(height: 12), Text('جارٍ معالجة الملف…')]),
            )))),
        ]),
      ),
    );
  }

  Color get _mint => _dark ? const Color(0xFF213F3D) : const Color(0xFFE5F4EF);

  Widget _panel(List<Widget> children) => Card(
    margin: EdgeInsets.zero,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18),
      side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant)),
    child: Padding(padding: const EdgeInsets.all(13), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: children)),
  );

  Widget _homePage() => LayoutBuilder(builder: (context, limits) {
    final wide = limits.maxWidth > 740;
    final scan = _scanPanel();
    final preview = _previewPanel();
    final current = _documents[_currentDoc];
    return ListView(
      key: const PageStorageKey('workspace'),
      padding: EdgeInsets.fromLTRB(wide ? 21 : 11, 12, wide ? 21 : 11, 24),
      children: [
        Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1180),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            _heroCard(),
            const SizedBox(height: 12),
            _sectionTitle('نوع المستمسك'),
            const SizedBox(height: 6),
            GridView.builder(
              key: const ValueKey('document_types'),
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              itemCount: _types.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: wide ? 5 : 3, mainAxisSpacing: 6, crossAxisSpacing: 6,
                mainAxisExtent: wide ? 69 : 49),
              itemBuilder: (_, i) {
                final type = _types[i];
                return _selectorTile(
                  title: type.$1, icon: type.$2, selected: current.title == type.$1,
                  onTap: () => _selectType(type.$1), horizontal: !wide,
                );
              },
            ),
            const SizedBox(height: 11),
            _sectionTitle('أوضاع المسح'),
            const SizedBox(height: 6),
            GridView.builder(
              key: const ValueKey('capture_modes'),
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              itemCount: _captureModes.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, mainAxisSpacing: 6, crossAxisSpacing: 6,
                mainAxisExtent: wide ? 78 : 83),
              itemBuilder: (_, i) {
                final mode = _captureModes[i];
                return _selectorTile(title: mode.$1, subtitle: mode.$2,
                  icon: mode.$3, color: mode.$4, background: mode.$5,
                  selected: _captureMode == mode.$1,
                  onTap: () => _startCaptureMode(mode));
              },
            ),
            const SizedBox(height: 12),
            if (wide)
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: scan), const SizedBox(width: 16), Expanded(child: preview),
              ])
            else ...[scan, const SizedBox(height: 12), preview],
          ]),
        )),
      ],
    );
  });

  Widget _selectorTile({required String title, required IconData icon,
      required bool selected, required VoidCallback onTap, String? subtitle,
      Color? color, Color? background, bool horizontal = false}) {
    final scheme = Theme.of(context).colorScheme;
    final badge = Container(
      width: subtitle == null ? 21 : 30, height: subtitle == null ? 21 : 29,
      decoration: BoxDecoration(color: background == null ? Colors.transparent :
          _tileColor(color!, background), borderRadius: BorderRadius.circular(8)),
      child: Icon(icon, size: 16, color: color ?? scheme.primary),
    );
    final name = Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, height: 1.15));
    return Material(
      color: selected && subtitle == null ? _mint : scheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: selected ? _accent : scheme.outlineVariant, width: selected ? 1.4 : 1)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(onTap: onTap, child: Padding(padding: const EdgeInsets.all(7),
        child: horizontal ? Row(children: [badge, const SizedBox(width: 4), Expanded(child: name)])
          : Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center,
              children: [
                badge, const SizedBox(height: 3), name,
                if (subtitle != null) Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 9, color: _muted, height: 1.12)),
              ]),
      )),
    );
  }

  Widget _heroCard() => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color.lerp(const Color(0xFF298B77), _accent, .35)!, _navy]),
    ),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('✦  استوديو التصوير والطباعة', style: TextStyle(color: Color(0xFFE5F4EF), fontSize: 11)),
        SizedBox(height: 6),
        Text('من الصورة إلى الورقة', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
        Text('صوّر مستمسكاتك، رتّبها واطبعها بالمقاس الذي تحتاجه.',
          style: TextStyle(color: Color(0xFFE0F2EC), fontSize: 12, height: 1.5)),
      ])),
      const SizedBox(width: 6),
      OutlinedButton.icon(
        onPressed: _demo,
        style: OutlinedButton.styleFrom(foregroundColor: Colors.white,
          side: const BorderSide(color: Color(0x66B7E5DA)),
          backgroundColor: const Color(0x17FFFFFF),
          padding: const EdgeInsets.symmetric(horizontal: 6)),
        icon: const Icon(Icons.image_outlined, size: 14),
        label: const Text('جرّب بعينة', style: TextStyle(fontSize: 11)),
      ),
    ]),
  );

  Widget _sectionTitle(String title) => Text(title,
    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800));

  Widget _scanPanel() {
    final doc = _documents[_currentDoc];
    final card = doc.usesNaturalCardSize && doc.title != 'بطاقات صغيرة';
    final nextBack = card && doc.front != null && doc.back == null;
    final addExtra = !card && doc.front != null;
    Future<void> addPicture(ImageSource source) async {
      if (addExtra) {
        final extra = ExtraScanPage();
        setState(() => doc.extras.add(extra));
        await _getExtraPicture(doc, extra, source);
        if (mounted && extra.image == null && doc.extras.contains(extra)) {
          setState(() => doc.extras.remove(extra));
        }
      } else {
        await _getPicture(nextBack, source);
      }
    }

    return _panel([
      Row(children: [
        Expanded(child: _sectionTitle('١. إضافة الصور')),
        _smallPill(card ? '${doc.photos.length} / 2' : '${doc.photos.length} صورة'),
      ]),
      Text(card ? 'الوجه الأمامي ثم الخلفي. تستطيع إعادة تصوير أي وجه.' :
        'التقط صورة أو اخترها من المعرض.', style: TextStyle(color: _muted, fontSize: 12)),
      const SizedBox(height: 8),
      TextField(controller: _filename, maxLength: 70,
        decoration: const InputDecoration(labelText: 'اسم الملف', counterText: '')),
      const SizedBox(height: 8),
      if (card || doc.front != null)
        _imageSlot(card ? 'الوجه الأمامي' :
          doc.title == 'جواز السفر' ? 'صفحة بيانات الجواز' : 'الصورة الأولى', doc.front, false),
      if (card || doc.back != null)
        _imageSlot(card ? 'الوجه الخلفي' : 'صفحة ثانية', doc.back, true),
      if (doc.photos.isEmpty && !card)
        _emptyBox('الصور المضافة تظهر هنا'),
      for (var i = 0; i < doc.extras.length; ++i) _extraPageCard(doc, doc.extras[i], i),
      if (_documents.length > 1) Wrap(spacing: 5, children: [
        for (var i = 0; i < _documents.length; i++)
          InputChip(label: Text(_documents[i].title), selected: i == _currentDoc,
            onSelected: (_) => setState(() { _currentDoc = i; _visiblePage = 0; }),
            onDeleted: () => setState(() {
              _documents.removeAt(i);
              _currentDoc = _currentDoc.clamp(0, _documents.length - 1).toInt();
              _visiblePage = 0;
            })),
      ]),
      Row(children: [
        SizedBox(width: 35, child: Checkbox(value: _autoCapture, onChanged: (value) {
          if (value != null) _saveAutoCapture(value);
        })),
        const Expanded(child: Text('التقاط تلقائي عند الوضوح والثبات', style: TextStyle(fontSize: 11))),
        _smallPill('مساعد التصوير'),
      ]),
      Wrap(spacing: 7, runSpacing: 6, children: [
        FilledButton.icon(
          onPressed: card && doc.front != null && doc.back != null ? null : () => addPicture(ImageSource.camera),
          icon: const Icon(Icons.camera_alt_outlined, size: 18),
          label: Text(nextBack ? 'تصوير الظهر' : card ? 'تصوير الوجه' :
            doc.title == 'إيصال' ? 'تصوير إيصال' : 'تصوير صفحة'),
        ),
        OutlinedButton.icon(
          onPressed: card && doc.front != null && doc.back != null ? null : () => addPicture(ImageSource.gallery),
          icon: const Icon(Icons.image_outlined, size: 18), label: const Text('من المعرض'),
        ),
        if (_captureMode == 'معاملة كاملة' || doc.photos.isNotEmpty)
          TextButton.icon(onPressed: _chooseKind,
            icon: const Icon(Icons.add, size: 17), label: const Text('مستمسك إضافي')),
      ]),
      if (_documents.any((item) => item.photos.isNotEmpty)) ...[
        const SizedBox(height: 9), const Divider(), _displayOptions(),
      ],
    ]);
  }

  Future<void> _saveAutoCapture(bool value) async {
    setState(() => _autoCapture = value);
    await (await SharedPreferences.getInstance()).setBool('auto_capture', value);
  }

  Widget _smallPill(String label) => DecoratedBox(
    decoration: BoxDecoration(color: _mint, borderRadius: BorderRadius.circular(30)),
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
        color: Theme.of(context).colorScheme.primary))),
  );

  Widget _emptyBox(String label) => Container(
    alignment: Alignment.center, padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(11),
      border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
    child: Text(label, style: TextStyle(color: _muted, fontSize: 12)),
  );

  Widget _extraPageCard(ScanDocument doc, ExtraScanPage page, int index) {
    return Card(child: Padding(padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('صفحة إضافية ${index + 1}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
          const Spacer(),
          IconButton(tooltip: 'تقديم الصفحة',
            onPressed: index == 0 ? null : () => setState(
              () => doc.moveExtra(index, index - 1)),
            icon: const Icon(Icons.arrow_upward_rounded, size: 19)),
          IconButton(tooltip: 'تأخير الصفحة',
            onPressed: index + 1 >= doc.extras.length ? null : () => setState(
              () => doc.moveExtra(index, index + 1)),
            icon: const Icon(Icons.arrow_downward_rounded, size: 19)),
          IconButton(tooltip: 'حذف الصفحة',
            onPressed: () => setState(() => doc.extras.remove(page)),
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 19)),
        ]),
        if (page.image != null) ...[
          ClipRRect(borderRadius: BorderRadius.circular(12),
            child: Container(height: 130, width: double.infinity,
              color: Theme.of(context).colorScheme.surfaceContainerHigh,
              child: Image.memory(page.image!.bytes, fit: BoxFit.contain,
                gaplessPlayback: true))),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () async {
                final style = await _chooseScannerPreset(page.original);
                if (style != null) {
                  await _setExtraAppearance(doc, page, style);
                }
              }, icon: const Icon(Icons.tune, size: 18),
              label: Text(page.appearance.label))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(
              onPressed: () => _editExtra(doc, page),
              icon: const Icon(Icons.crop, size: 18),
              label: const Text('الزوايا'))),
          ]),
          const SizedBox(height: 8),
        ],
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            onPressed: () => _getExtraPicture(doc, page, ImageSource.camera),
            icon: const Icon(Icons.camera_alt_outlined, size: 18),
            label: const Text('تصوير'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(
            onPressed: () => _getExtraPicture(doc, page, ImageSource.gallery),
            icon: const Icon(Icons.photo_library_outlined, size: 18),
            label: const Text('المعرض'))),
        ]),
      ])));
  }

  Widget _imageSlot(String heading, PhotoData? image, bool back) {
    final doc = _documents[_currentDoc];
    final key = '${_documents.indexOf(doc)}_${back ? 'back' : 'front'}';
    final processing = _processingPhoto == key;
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
      child: Row(children: [
        SizedBox(width: 42, height: 38,
          child: image == null ? const Icon(Icons.badge_outlined, size: 18) :
            Image.memory(image.bytes, fit: BoxFit.contain, cacheWidth: 96)),
        const SizedBox(width: 6),
        Expanded(child: Text(heading, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
        if (processing)
          const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2))
        else ...[
          IconButton(tooltip: 'تصوير', visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.camera_alt_outlined, size: 17),
            onPressed: () => _getPicture(back, ImageSource.camera)),
          IconButton(tooltip: 'من المعرض', visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.image_outlined, size: 17),
            onPressed: () => _getPicture(back, ImageSource.gallery)),
          if (image != null)
            PopupMenuButton<String>(
              tooltip: 'تعديل الصورة',
              icon: const Icon(Icons.more_vert, size: 18),
              onSelected: (action) async {
                switch (action) {
                  case 'crop': await _editImage(back);
                  case 'original': await _setPhotoAppearance(doc, back, ScanAppearance.original);
                  case 'scanner':
                    final choice = await _chooseScannerPreset(back ? doc.backOriginal : doc.frontOriginal);
                    if (mounted && choice != null) await _setPhotoAppearance(doc, back, choice);
                  case 'swap':
                    setState(doc.swapSides);
                  case 'delete':
                    setState(() {
                      if (back) {
                        doc.back = null;
                        doc.backOriginal = null;
                        doc.backAppearance = ScanAppearance.original;
                      } else {
                        doc.front = null;
                        doc.frontOriginal = null;
                        doc.frontAppearance = ScanAppearance.original;
                      }
                    });
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'crop', child: Text('تصحيح الزوايا والقص')),
                const PopupMenuItem(value: 'scanner', child: Text('اختيار السكنر')),
                const PopupMenuItem(value: 'original', child: Text('استعادة الأصل')),
                if (doc.front != null && doc.back != null)
                  const PopupMenuItem(value: 'swap', child: Text('تبديل الوجهين')),
                const PopupMenuItem(value: 'delete', child: Text('حذف الصورة')),
              ],
            ),
        ],
      ]),
    );
  }

  Widget _layoutThumbnail(LayoutStyle style) => Center(
    child: CustomPaint(
      painter: _LayoutSchematicPainter(style),
      size: const Size(76, 90),
    ),
  );

  Widget _displayOptions() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _sectionTitle(_documents.any((doc) => doc.usesNaturalCardSize)
          ? '٢. طريقة عرض البطاقة' : '٢. طريقة عرض الصورة'),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 6, children: [
        ChoiceChip(
          label: Text(_documents.any((doc) => doc.usesNaturalCardSize) ? 'الحجم الطبيعي' : 'تخطيط الصور'),
          selected: !widget.settings.fillPage,
          onSelected: (_) => setState(() { widget.settings.fillPage = false; _visiblePage = 0; }),
        ),
        ChoiceChip(
          avatar: const Icon(Icons.fit_screen_rounded, size: 18),
          label: const Text('ملء الورقة'),
          selected: widget.settings.fillPage,
          onSelected: (_) => setState(() { widget.settings.fillPage = true; _visiblePage = 0; }),
        ),
      ]),
      const SizedBox(height: 10),
      if (!widget.settings.fillPage) GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: LayoutStyle.values.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, mainAxisSpacing: 5, crossAxisSpacing: 5, mainAxisExtent: 53),
        itemBuilder: (_, i) {
          final mode = LayoutStyle.values[i];
          final active = widget.settings.style == mode;
          return InkWell(
            onTap: () => setState(() {
              widget.settings.style = mode;
              widget.settings.singleFace = mode == LayoutStyle.single ? 0 : null;
              _visiblePage = 0;
            }),
            borderRadius: BorderRadius.circular(14),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: active ? _accent.withValues(alpha: .09) : Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: active ? _accent : Colors.transparent, width: active ? 2 : 1),
              ),
              child: Row(children: [
                SizedBox(width: 24, height: 33, child: FittedBox(child: _layoutThumbnail(mode))),
                const SizedBox(width: 4),
                Expanded(child: Text(mode.label, maxLines: 2,
                  style: TextStyle(fontSize: 10, fontWeight: active ? FontWeight.w800 : FontWeight.w600))),
              ]),
            ),
          );
        },
      ),
      if (!widget.settings.fillPage && widget.settings.style == LayoutStyle.single &&
          _documents.any((doc) => doc.usesNaturalCardSize &&
              doc.front != null && doc.back != null && doc.photos.length == 2))
        Wrap(spacing: 8, children: [
          for (final (index, label) in [(0, 'الوجه الأمامي'), (1, 'الوجه الخلفي')])
            ChoiceChip(label: Text(label), selected: widget.settings.singleFace == index,
              onSelected: (_) => setState(() {
                widget.settings.singleFace = index;
                _visiblePage = 0;
              })),
        ]),
        if (!widget.settings.fillPage) _slider('المسافة بين الصورتين', widget.settings.gap, 5, 45, (v) => setState(() => widget.settings.gap = v)),
        if (!widget.settings.fillPage) _slider('حجم الصور', widget.settings.scale, .65, 1.2, (v) => setState(() => widget.settings.scale = v)),
        if (!widget.settings.fillPage && widget.settings.style == LayoutStyle.halves)
          SwitchListTile(title: const Text('خط القص بين النصفين'),
            value: widget.settings.showCut,
            onChanged: (value) => setState(() => widget.settings.showCut = value)),
    ],
  );

  ScanDocument _ownerOf(PhotoData photo) =>
      _documents.firstWhere((document) => document.photos.contains(photo));

  Future<void> _editPlacement(PhotoData photo) async {
    final doc = _ownerOf(photo);
    if (identical(photo, doc.front)) {
      await _editImage(false, owner: doc);
    } else if (identical(photo, doc.back)) {
      await _editImage(true, owner: doc);
    } else {
      final page = doc.extras.firstWhere((item) => identical(item.image, photo));
      await _editExtra(doc, page);
    }
  }

  Widget _previewPanel() {
    final sheets = _sheets;
    final hasImages = sheets.isNotEmpty;
    final pageIndex = hasImages ? _visiblePage.clamp(0, sheets.length - 1).toInt() : 0;
    final page = widget.settings.paper;
    return _panel([
      Row(children: [
        Expanded(child: _sectionTitle(hasImages ? '٣. معاينة الطباعة' : 'معاينة الطباعة')),
        _smallPill('${widget.settings.a5 ? 'A5' : 'A4'} · ${widget.settings.landscape ? 'أفقي' : 'عمودي'}'),
      ]),
      Text('نفس ترتيب الصور والقياسات في ملف PDF.', style: TextStyle(color: _muted, fontSize: 12)),
      const SizedBox(height: 8),
      Column(children: [
        Row(children: [
          Expanded(child: _paperOption()),
          const SizedBox(width: 8),
          Expanded(child: _paperDirection()),
        ]),
        _slider('هوامش الصفحة', widget.settings.margin, 18, 65, (v) => setState(() => widget.settings.margin = v)),
      ]),
      const SizedBox(height: 7),
      Text(widget.settings.fillPage ? 'ملء المساحة داخل الهوامش مع حفظ نسبة الصورة' :
          'التخطيط الحالي: ${widget.settings.style.label}',
        style: TextStyle(fontSize: 11, color: _accent, fontWeight: FontWeight.w800)),
      if (!widget.settings.fillPage && _documents.any((d) => d.usesNaturalCardSize))
        Padding(padding: const EdgeInsets.only(top: 5),
          child: Text('مقاس البطاقات الطبيعي: 85.6 × 53.98 ملم عند حجم 100%؛ '
              'قد يُصغَّر عند عدم اتساع الورقة.',
            style: TextStyle(fontSize: 11, color: _muted))),
      const SizedBox(height: 8),
      if (hasImages && widget.settings.fillPage)
        Align(alignment: AlignmentDirectional.centerStart, child: OutlinedButton.icon(
          onPressed: () => _editPlacement(sheets[pageIndex].placements.first.photo),
          icon: const Icon(Icons.crop_outlined, size: 16),
          label: const Text('قص حواف صورة المستند'),
        )),
      if (!hasImages) _emptyBox('أضف صورة لعرض المعاينة'),
      if (hasImages) Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: _dark ? const Color(0xFF101820) : const Color(0xFFE7EDF3),
            borderRadius: BorderRadius.circular(18)),
        child: Center(child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 470, maxWidth: 375),
          child: AspectRatio(
            aspectRatio: page.width / page.height,
            child: FittedBox(
              fit: BoxFit.contain,
              child: SizedBox(
                width: page.width,
                height: page.height,
                child: ColoredBox(
                  color: Colors.white,
                  child: Stack(children: [
                    for (final item in sheets[pageIndex].placements)
                      Positioned.fromRect(
                        rect: item.rect,
                        child: GestureDetector(
                          onPanUpdate: !widget.settings.fillPage && widget.settings.style == LayoutStyle.free
                            ? (details) {
                              final rect = item.rect;
                              setState(() {
                                _ownerOf(item.photo).freeOffsets[item.index] = Offset(
                                  (rect.left + details.delta.dx).clamp(
                                    widget.settings.margin,
                                    page.width - widget.settings.margin - rect.width).toDouble(),
                                  (rect.top + details.delta.dy).clamp(
                                    widget.settings.margin,
                                    page.height - widget.settings.margin - rect.height).toDouble(),
                                );
                              });
                            } : null,
                          child: Image.memory(item.photo.bytes,
                            key: ValueKey(item.photo.bytes),
                            fit: BoxFit.contain, gaplessPlayback: true,
                            filterQuality: FilterQuality.medium, cacheWidth: 1100,
                          ),
                        ),
                      ),
                    if (sheets[pageIndex].cutLine)
                      Positioned(left: widget.settings.margin,
                        top: page.height / 2,
                        width: page.width - 2 * widget.settings.margin,
                        child: const Divider(thickness: 1,
                          color: Colors.grey)),
                  ]),
                ),
              ),
            ),
          ),
        )),
      ),
      if (sheets.length > 1) ...[
        const SizedBox(height: 11),
        SizedBox(height: 56, child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: sheets.length,
          separatorBuilder: (context, index) => const SizedBox(width: 8),
          itemBuilder: (_, i) => InkWell(
            onTap: () => setState(() => _visiblePage = i),
            borderRadius: BorderRadius.circular(11),
            child: Container(
              width: 86,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: i == pageIndex ? _accent.withValues(alpha: .12)
                    : Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: i == pageIndex ? _accent
                  : const Color(0xFFD6E0E9))),
              child: Text('صفحة ${i + 1}  •  ${sheets[i].placements.length} صورة',
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 10)),
            ),
          ),
        )),
      ],
      if (hasImages && !widget.settings.fillPage && widget.settings.style == LayoutStyle.free) ...[
        const Padding(padding: EdgeInsets.only(top: 8), child: Text('اسحب كل صورة إلى مكانها الجديد داخل الورقة',
          textAlign: TextAlign.center)),
        for (final item in sheets[pageIndex].placements)
          _slider('حجم الصورة ${item.index + 1}', _ownerOf(item.photo).freeScales[item.index] ?? 1,
            .65, 1.2, (value) => setState(() => _ownerOf(item.photo).freeScales[item.index] = value)),
      ],
      const SizedBox(height: 14),
      const SizedBox(height: 9),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: hasImages ? () => _export(false) : null,
          icon: const Icon(Icons.download_outlined, size: 17), label: const Text('حفظ PDF'))),
        const SizedBox(width: 7),
        Expanded(child: OutlinedButton.icon(onPressed: hasImages ? _printPdf : null,
          icon: const Icon(Icons.print_outlined, size: 17), label: const Text('طباعة'))),
      ]),
      const SizedBox(height: 7),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: hasImages ? () => _export(false, redact: true) : null,
          icon: const Icon(Icons.visibility_off_outlined, size: 16),
          label: const Text('نسخة بإخفاء البيانات', style: TextStyle(fontSize: 11)))),
        const SizedBox(width: 7),
        Expanded(child: OutlinedButton.icon(onPressed: hasImages ? _saveToVault : null,
          icon: const Icon(Icons.lock_outline, size: 16),
          label: const Text('حفظ في الخزنة', style: TextStyle(fontSize: 11)))),
      ]),
      if (hasImages) Align(alignment: AlignmentDirectional.centerStart, child: TextButton.icon(
        onPressed: () => _export(true), icon: const Icon(Icons.description_outlined, size: 16),
        label: const Text('حفظ Word'),
      )),
    ]);
  }

  Widget _paperOption() => DropdownButtonFormField<bool>(
    key: ValueKey(('paper', widget.settings.a5)),
    initialValue: widget.settings.a5,
    decoration: const InputDecoration(labelText: 'حجم الورق', border: OutlineInputBorder()),
    items: const [
      DropdownMenuItem(value: false, child: Text('A4')),
      DropdownMenuItem(value: true, child: Text('A5')),
    ],
    onChanged: (v) => setState(() => widget.settings.a5 = v ?? false),
  );

  Widget _paperDirection() => DropdownButtonFormField<bool>(
    key: ValueKey(('orientation', widget.settings.landscape)),
    initialValue: widget.settings.landscape,
    decoration: const InputDecoration(labelText: 'اتجاه الصفحة', border: OutlineInputBorder()),
    items: const [
      DropdownMenuItem(value: false, child: Text('عمودي')),
      DropdownMenuItem(value: true, child: Text('أفقي')),
    ],
    onChanged: (v) => setState(() => widget.settings.landscape = v ?? false),
  );

  Widget _slider(String title, double value, double min, double max, ValueChanged<double> onChanged) =>
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.only(top: 12), child: Text(title,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
      Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged),
    ]);

  Widget _filesPage() => RefreshIndicator(
    onRefresh: _loadSaved,
    child: ListView(padding: const EdgeInsets.all(11), children: [
      _sectionTitle('ملفاتي'),
      Text('الملفات المصدّرة والمعاملات المحفوظة في الخزنة.',
        style: TextStyle(color: _muted, fontSize: 12)),
      const SizedBox(height: 10),
      _panel([
        _sectionTitle('الملفات المصدّرة'),
        const SizedBox(height: 8),
        if (_saved.isEmpty) _emptyBox('ستظهر ملفات PDF هنا بعد حفظها.')
        else for (final f in _saved)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(f.path.endsWith('.pdf') ? Icons.picture_as_pdf_outlined :
              Icons.description_outlined, color: _accent),
            title: Text(f.uri.pathSegments.last, maxLines: 2),
            onTap: f.path.endsWith('.pdf') ? () => _openSavedPdf(f) : null,
            trailing: PopupMenuButton<String>(
              onSelected: (choice) async {
                if (choice == 'share') { await _shareFile(f); }
                if (choice == 'delete') { await _deleteSaved(f); }
                if (choice == 'print' && f.path.endsWith('.pdf')) {
                  await Printing.layoutPdf(onLayout: (_) => f.readAsBytes());
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'share', child: Text('مشاركة')),
                if (f.path.endsWith('.pdf')) const PopupMenuItem(value: 'print', child: Text('طباعة')),
                const PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          ),
      ]),
      const SizedBox(height: 12),
      _panel([
        _sectionTitle('الخزنة المشفّرة'),
        Text('افتح معاملة محفوظة بعبارة المرور.', style: TextStyle(color: _muted, fontSize: 12)),
        const SizedBox(height: 8),
        if (_vaultFiles.isEmpty) _emptyBox('لا توجد معاملات محفوظة')
        else for (final (index, file) in _vaultFiles.indexed)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.lock_outline, color: _accent),
            title: Text('معاملة مشفّرة ${index + 1}'),
            onTap: () => _restoreFromVault(file),
            trailing: IconButton(tooltip: 'حذف المعاملة',
              icon: const Icon(Icons.delete_outline), onPressed: () => _deleteSaved(file)),
          ),
      ]),
    ]),
  );

  Future<void> _resetPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    for (final key in ['dark', 'accent', 'capture_quality', 'auto_capture',
        'auto_enhance', 'default_a5', 'default_landscape', 'default_layout']) {
      await prefs.remove(key);
    }
    if (!mounted) return;
    widget.settings
      ..dark = false
      ..accent = _brand;
    widget.onThemeChange();
    await _loadPreferences();
    if (mounted) _message('استُعيدت الإعدادات الافتراضية');
  }

  Future<void> _clearSession() async {
    final confirmed = await _confirmNewDocument();
    if (!mounted || !confirmed) return;
    setState(() {
      _documents..clear()..add(ScanDocument('البطاقة الوطنية'));
      _currentDoc = 0;
      _captureMode = 'بطاقة في دقيقة';
      _filename.text = 'البطاقة الوطنية';
      _preparePrint(_defaultLayout, fillPage: false);
      _navigation = 0;
    });
  }

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(16), children: [
    _sectionTitle('الإعدادات'),
    Text('تُحفظ تفضيلاتك على هذا الجهاز.', style: TextStyle(color: _muted, fontSize: 12)),
    const SizedBox(height: 12),
    Card(child: Column(children: [
      const ListTile(title: Text('المظهر')),
      SwitchListTile(
        title: const Text('الوضع الليلي'),
        secondary: const Icon(Icons.dark_mode_outlined),
        value: widget.settings.dark,
        onChanged: (v) async {
          widget.settings.dark = v;
          widget.onThemeChange();
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('dark', v);
        },
      ),
      const Divider(height: 1),
      Padding(
        padding: const EdgeInsets.fromLTRB(14, 15, 14, 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.palette_outlined), SizedBox(width: 8),
            Text('اللون الرئيسي', style: TextStyle(fontWeight: FontWeight.w900)),
          ]),
          const SizedBox(height: 5),
          const Text('اختر لوناً من البطاقات الصغيرة. سيُحفظ اختيارك تلقائياً.',
            style: TextStyle(color: Color(0xFF8492A5), fontSize: 11)),
          const SizedBox(height: 13),
          Wrap(spacing: 9, runSpacing: 10, children: [
            for (final swatch in _accentPalette)
              InkWell(
                onTap: () async {
                  widget.settings.accent = swatch.$2;
                  widget.onThemeChange();
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setInt('accent', swatch.$2.toARGB32());
                },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  width: 66,
                  padding: const EdgeInsets.fromLTRB(4, 6, 4, 5),
                  decoration: BoxDecoration(
                    color: _accent == swatch.$2
                        ? swatch.$2.withValues(alpha: .12)
                        : Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _accent == swatch.$2 ? swatch.$2
                          : Theme.of(context).colorScheme.outlineVariant,
                      width: _accent == swatch.$2 ? 2 : 1,
                    ),
                  ),
                  child: Column(children: [
                    Container(
                      height: 32, width: 36,
                      decoration: BoxDecoration(color: swatch.$2,
                        borderRadius: BorderRadius.circular(9)),
                      child: _accent == swatch.$2
                          ? const Icon(Icons.check_rounded, color: Colors.white, size: 20)
                          : null,
                    ),
                    const SizedBox(height: 4),
                    Text(swatch.$1, style: const TextStyle(fontSize: 9,
                      fontWeight: FontWeight.w700), maxLines: 1,
                      textAlign: TextAlign.center),
                  ]),
                ),
              ),
          ]),
        ]),
      ),
    ])),
    Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('التصوير والتحرير', style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        Text('جودة ضغط صور المعرض: $_captureQuality%', style: const TextStyle(fontSize: 12)),
        Slider(value: _captureQuality.toDouble(), min: 65, max: 100, divisions: 7,
          onChanged: (v) => setState(() => _captureQuality = v.round()),
          onChangeEnd: (v) async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.setInt('capture_quality', v.round());
          }),
        const Text('التصوير يحفظ الصورة دون ضغط إضافي لتسريع ظهورها، ويمكن تصحيح المنظور لاحقاً.',
          style: TextStyle(fontSize: 11, color: Color(0xFF8C9BB0))),
      ],
    ))),
    Card(child: Column(children: [
      SwitchListTile(title: const Text('التقاط تلقائي عند الثبات'),
        value: _autoCapture, onChanged: (value) async {
          setState(() => _autoCapture = value);
          await (await SharedPreferences.getInstance()).setBool('auto_capture', value);
        }),
      SwitchListTile(title: const Text('تحسين الصور تلقائياً'),
        value: _autoEnhance, onChanged: (value) async {
          setState(() => _autoEnhance = value);
          await (await SharedPreferences.getInstance()).setBool('auto_enhance', value);
        }),
    ])),
    Card(child: Column(children: [
      const ListTile(title: Text('المستندات الجديدة'), subtitle: Text('تُطبّق عند بدء مستند جديد.')),
      SwitchListTile(title: const Text('مقاس الورق الافتراضي A5'),
        subtitle: const Text('عند الإيقاف، يُستخدم A4'),
        value: _defaultA5, onChanged: (value) async {
          setState(() => _defaultA5 = value);
          await (await SharedPreferences.getInstance()).setBool('default_a5', value);
        }),
      SwitchListTile(title: const Text('اتجاه الورق الافتراضي أفقي'),
        value: _defaultLandscape, onChanged: (value) async {
          setState(() => _defaultLandscape = value);
          await (await SharedPreferences.getInstance()).setBool('default_landscape', value);
        }),
      ListTile(title: const Text('طريقة عرض البطاقة الافتراضية'),
        trailing: DropdownButton<LayoutStyle>(
          value: _defaultLayout,
          items: [
            for (final item in LayoutStyle.values)
              DropdownMenuItem(value: item, child: Text(item.label)),
          ],
          onChanged: (value) async {
            if (value == null) return;
            setState(() => _defaultLayout = value);
            await (await SharedPreferences.getInstance()).setString('default_layout', value.name);
          },
        )),
    ])),
    Card(child: Column(children: [
      const ListTile(title: Text('الجلسة الحالية')),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Wrap(spacing: 6, children: [
        OutlinedButton(onPressed: _resetPreferences, child: const Text('استعادة الإعدادات')),
        OutlinedButton(onPressed: _clearSession, child: const Text('مسح الجلسة')),
      ])),
      const ListTile(leading: Icon(Icons.lock_outline), title: Text('الخصوصية'),
        subtitle: Text('الصور تُعالج محلياً على الهاتف ولا تُرفع إلى خادم')),
      const Divider(height: 1),
      ListTile(
        leading: const Icon(Icons.delete_sweep_outlined),
        title: const Text('حذف الملفات المؤقتة'),
        onTap: () async {
          final directory = await getTemporaryDirectory();
          for (final file in directory.listSync().whereType<File>()) {
            if (file.path.contains('mustamsakati_temp_')) {
              await file.delete();
            }
          }
          if (mounted) {
            _message('تم تنظيف الملفات المؤقتة');
          }
        },
      ),
      const Divider(height: 1),
      const ListTile(leading: Icon(Icons.info_outline),
        title: Text('مستمسكاتي 8.1.0'), subtitle: Text('تطبيق Flutter أصلي — بدون WebView')),
    ])),
  ]);
}

class CornerEditor extends StatefulWidget {
  const CornerEditor({super.key, required this.photo});
  final PhotoData photo;

  @override
  State<CornerEditor> createState() => _CornerEditorState();
}

class _CornerEditorState extends State<CornerEditor> {
  late List<Offset> _corners;
  int _active = -1;
  int _rotation = 0;
  double _brightness = 0;
  bool _saving = false;
  bool _detecting = false;
  int? _dragPointer;
  Offset _lensPoint = const Offset(.5, .5);
  ui.Image? _lensBitmap;
  Size _imageViewport = Size.zero;

  @override
  void initState() {
    super.initState();
    _corners = List.of(defaultCorners);
    _prepareLensImage();
  }

  Future<void> _prepareLensImage() async {
    try {
      final codec = await ui.instantiateImageCodec(widget.photo.bytes,
          targetWidth: 1800, allowUpscaling: false);
      final frame = await codec.getNextFrame();
      codec.dispose();
      if (!mounted) {
        frame.image.dispose();
        return;
      }
      setState(() => _lensBitmap = frame.image);
    } catch (_) {
      // The editor remains usable even if the zoom image cannot be decoded.
    }
  }

  @override
  void dispose() {
    _lensBitmap?.dispose();
    super.dispose();
  }

  void _startDrag(PointerDownEvent event, double width, double height) {
    if (_dragPointer != null) {
      return;
    }
    var closest = double.infinity;
    var hit = -1;
    for (var i = 0; i < 4; ++i) {
      final point = Offset(_corners[i].dx * width, _corners[i].dy * height);
      final distance = (point - event.localPosition).distance;
      if (distance < closest && distance <= 68) {
        hit = i;
        closest = distance;
      }
    }
    if (hit >= 0) {
      setState(() {
        _active = hit;
        _dragPointer = event.pointer;
        _lensPoint = _corners[hit];
      });
    }
  }

  void _continueDrag(PointerMoveEvent event, double width, double height) {
    if (_dragPointer != event.pointer || _active < 0) {
      return;
    }
    final next = Offset(
      (event.localPosition.dx / width).clamp(0.0, 1.0),
      (event.localPosition.dy / height).clamp(0.0, 1.0),
    );
    final candidate = List<Offset>.from(_corners);
    candidate[_active] = next;
    setState(() {
      // The lens follows the finger even when an invalid crossing is rejected.
      _lensPoint = next;
      if (isValidQuadrilateral(candidate)) {
        _corners = candidate;
      }
    });
  }

  void _endDrag(int pointer) {
    if (_dragPointer == pointer) {
      setState(() {
        _dragPointer = null;
        _active = -1;
      });
    }
  }

  Widget _magnifier() {
    if (_active < 0) {
      return const SizedBox.shrink();
    }
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      SizedBox(width: 116, height: 116,
        child: CustomPaint(painter: _ActualCornerLensPainter(
          _lensBitmap, _lensPoint, _imageViewport,
          Theme.of(context).colorScheme.primary,
        )),
      ),
      const SizedBox(height: 3),
      Text('الزاوية ${_active + 1} / 4 • حرّك إصبعك بدقة',
        style: TextStyle(color: Theme.of(context).colorScheme.primary,
          fontSize: 10, fontWeight: FontWeight.w900)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final aspect = widget.photo.aspect;
    return Scaffold(
      appBar: AppBar(title: const Text('تصحيح الزوايا والمنظور')),
      body: SafeArea(child: Column(children: [
        SizedBox(height: 142, child: Center(child: _active >= 0
          ? _magnifier()
          : const Padding(padding: EdgeInsets.all(16),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.zoom_in_rounded, size: 28),
                SizedBox(height: 9),
                Text('اسحب أي زاوية لتصحيح الميل',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                SizedBox(height: 4),
                Text('ستظهر عدسة مكبّرة هنا، بعيداً عن إصبعك.',
                    style: TextStyle(fontSize: 11)),
              ]))),
        ),
        Expanded(child: Padding(
          padding: const EdgeInsets.all(14),
          child: LayoutBuilder(builder: (context, limits) {
            final width = math.min(limits.maxWidth, limits.maxHeight * aspect);
            final height = width / aspect;
            // Listener is immediate and does not wait for the pan gesture arena.
            // It works independently for each of the four visible handles.
            _imageViewport = Size(width, height);
            return Center(child: SizedBox(
              width: width, height: height,
              child: Listener(
                key: const ValueKey('corner_touch_layer'),
                behavior: HitTestBehavior.opaque,
                onPointerDown: (e) => _startDrag(e, width, height),
                onPointerMove: (e) => _continueDrag(e, width, height),
                onPointerUp: (e) => _endDrag(e.pointer),
                onPointerCancel: (e) => _endDrag(e.pointer),
                child: Stack(fit: StackFit.expand, children: [
                  Image.memory(widget.photo.bytes, fit: BoxFit.fill,
                      gaplessPlayback: true),
                  IgnorePointer(child: CustomPaint(
                    painter: _CornersPainter(_corners, _active))),
                ]),
              ),
            ));
          }),
        )),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Column(children: [
          Wrap(spacing: 7, runSpacing: 5, children: [
            OutlinedButton.icon(
              onPressed: () => setState(() => _corners = List.of(defaultCorners)),
              icon: const Icon(Icons.restart_alt, size: 17),
              label: const Text('إعادة الزوايا')),
            OutlinedButton.icon(
              onPressed: () => setState(() => _rotation = (_rotation + 90) % 360),
              icon: const Icon(Icons.rotate_right, size: 17),
              label: const Text('تدوير 90°')),
            OutlinedButton.icon(
              onPressed: _detecting ? null : () async {
                setState(() => _detecting = true);
                try {
                  final guess = await suggestDocumentCorners(widget.photo.bytes);
                  if (mounted && isValidQuadrilateral(guess)) {
                    setState(() => _corners = guess);
                  }
                } catch (error) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('تعذّر اقتراح الحدود: $error')));
                  }
                } finally {
                  if (mounted) {
                    setState(() => _detecting = false);
                  }
                }
              },
              icon: const Icon(Icons.auto_fix_high_rounded, size: 17),
              label: Text(_detecting ? 'جارٍ التحديد...' : 'حدود مقترحة')),
          ]),
          Row(children: [
            const Icon(Icons.brightness_6_outlined),
            const SizedBox(width: 8),
            const Text('الإضاءة'),
            Expanded(child: Slider(value: _brightness, min: -50, max: 50,
              onChanged: (v) => setState(() => _brightness = v))),
          ]),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            onPressed: _saving ? null : () async {
              setState(() => _saving = true);
              try {
                final bytes = await rectifyImage(PerspectiveArgs(
                  widget.photo.bytes, _corners, _rotation, _brightness.round()));
                if (!context.mounted) {
                  return;
                }
                final codec = await ui.instantiateImageCodec(bytes);
                final frame = await codec.getNextFrame();
                final result = PhotoData(bytes, frame.image.width, frame.image.height);
                frame.image.dispose();
                codec.dispose();
                if (context.mounted) {
                  Navigator.pop(context, result);
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('تعذّر تصحيح المنظور: $e')),
                  );
                }
              } finally {
                if (mounted) {
                  setState(() => _saving = false);
                }
              }
            },
            icon: _saving ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.check_circle_outline_rounded),
            label: Text(_saving ? 'جارٍ التصحيح...' : 'تطبيق التصحيح'),
          )),
          const SizedBox(height: 12),
        ])),
      ])),
    );
  }
}

/// Magnifies the *actual source image pixels* under the dragged corner.
/// The mapping uses the displayed image's real Size, rather than a hardcoded
/// 168px canvas; the latter was why the old lens appeared stuck or blank.
class _ActualCornerLensPainter extends CustomPainter {
  const _ActualCornerLensPainter(this.image, this.point, this.viewSize, this.tint);
  final ui.Image? image;
  final Offset point;
  final Size viewSize;
  final Color tint;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final oval = Offset.zero & size;
    canvas.save();
    canvas.clipPath(Path()..addOval(oval));
    canvas.drawColor(const Color(0xFFECF3F8), BlendMode.src);
    final bitmap = image;
    if (bitmap != null && !viewSize.isEmpty) {
      const zoom = 3.5;
      final sx = zoom * viewSize.width / bitmap.width;
      final sy = zoom * viewSize.height / bitmap.height;
      canvas.translate(center.dx - point.dx * bitmap.width * sx,
          center.dy - point.dy * bitmap.height * sy);
      canvas.scale(sx, sy);
      canvas.drawImage(bitmap, Offset.zero,
          Paint()..filterQuality = FilterQuality.medium);
    }
    canvas.restore();
    canvas.drawOval(oval.deflate(2), Paint()..style = PaintingStyle.stroke
      ..strokeWidth = 3..color = tint);
    canvas.drawLine(center.translate(-17, 0), center.translate(17, 0),
      Paint()..color = const Color(0xFF143552)..strokeWidth = 3);
    canvas.drawLine(center.translate(0, -17), center.translate(0, 17),
      Paint()..color = const Color(0xFF143552)..strokeWidth = 3);
    canvas.drawCircle(center, 3.2, Paint()..color = const Color(0xFFFFCE56));
  }

  @override
  bool shouldRepaint(covariant _ActualCornerLensPainter old) =>
      old.image != image || old.point != point || old.viewSize != viewSize ||
      old.tint != tint;
}

class _CornersPainter extends CustomPainter {
  const _CornersPainter(this.points, this.active);
  final List<Offset> points;
  final int active;

  @override
  void paint(Canvas canvas, Size size) {
    final coords = [for (final p in points) Offset(p.dx * size.width, p.dy * size.height)];
    final shape = Path()..moveTo(coords.first.dx, coords.first.dy);
    for (var i = 1; i < 4; ++i) {
      shape.lineTo(coords[i].dx, coords[i].dy);
    }
    shape.close();
    canvas.drawPath(shape, Paint()..color = Colors.black.withValues(alpha: .13));
    canvas.drawPath(shape, Paint()
      ..color = const Color(0xFF50E5E6)..strokeWidth = 2.3..style = PaintingStyle.stroke);
    for (var i = 0; i < coords.length; ++i) {
      canvas.drawCircle(coords[i], i == active ? 15 : 12, Paint()..color = Colors.white);
      canvas.drawCircle(coords[i], i == active ? 10 : 7, Paint()..color = i == active ? Colors.orange : _blue);
    }
  }

  @override
  bool shouldRepaint(covariant _CornersPainter old) =>
      old.active != active || old.points != points;
}

/// Draws the same nine illustrative paper diagrams as the HTML V7 options.
/// It never displays users' identity photos in layout option cards.
class _LayoutSchematicPainter extends CustomPainter {
  const _LayoutSchematicPainter(this.mode);
  final LayoutStyle mode;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 76, size.height / 90);
    final paper = RRect.fromRectAndRadius(
      const Rect.fromLTWH(2.5, 2.5, 71, 85), const Radius.circular(5));
    canvas.drawRRect(paper, Paint()..color = Colors.white);
    canvas.drawRRect(paper, Paint()..color = const Color(0xFFD7E0EF)
      ..strokeWidth = 1.5..style = PaintingStyle.stroke);
    void card(double x, double y, double w, double h, {bool second = false}) {
      final r = RRect.fromRectAndRadius(Rect.fromLTWH(x, y, w, h),
        const Radius.circular(3.5));
      final fill = second ? const Color(0xFFBDE2D7) : const Color(0xFFC6DEF5);
      final edge = second ? const Color(0xFF7BBDAD) : const Color(0xFF92B7E0);
      canvas.drawRRect(r, Paint()..color = fill);
      canvas.drawRRect(r, Paint()
        ..color = edge
        ..strokeWidth = .7
        ..style = PaintingStyle.stroke);
    }
    switch (mode) {
      case LayoutStyle.sideCenter:
        card(7, 37, 28, 18); card(41, 37, 28, 18, second: true);
      case LayoutStyle.sideTop:
        card(7, 10, 28, 18); card(41, 10, 28, 18, second: true);
      case LayoutStyle.verticalCenter:
        card(16, 25, 44, 22); card(16, 54, 44, 22, second: true);
      case LayoutStyle.stackRight:
        card(38, 13, 30, 20); card(38, 40, 30, 20, second: true);
      case LayoutStyle.stackLeft:
        card(9, 13, 30, 20); card(9, 40, 30, 20, second: true);
      case LayoutStyle.separate:
        canvas.drawRect(const Rect.fromLTWH(9, 20, 26, 45),
          Paint()..color = const Color(0xFFF7F9FC));
        canvas.drawRect(const Rect.fromLTWH(42, 20, 26, 45),
          Paint()..color = const Color(0xFFF7F9FC));
        card(13, 30, 18, 13); card(46, 30, 18, 13, second: true);
      case LayoutStyle.halves:
        card(10, 17, 56, 23); card(10, 54, 56, 23, second: true);
        canvas.drawLine(const Offset(9, 47), const Offset(67, 47),
          Paint()..color = const Color(0xFF9CAABD)..strokeWidth = 1);
      case LayoutStyle.single:
        card(12, 30, 52, 30);
      case LayoutStyle.free:
        canvas.save();
        canvas.translate(26, 33); canvas.rotate(-.12);
        card(-19, -13, 38, 27);
        canvas.restore();
        canvas.save();
        canvas.translate(49, 56); canvas.rotate(.12);
        card(-16, -12, 33, 24, second: true);
        canvas.restore();
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LayoutSchematicPainter oldDelegate) =>
      oldDelegate.mode != mode;
}
