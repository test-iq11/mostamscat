# مستمسكاتي 4.0 — مشروع Android (Flutter)

هذا المشروع يحفظ واجهة HTML التفاعلية المختبرة داخل تطبيق Flutter محلي. لا يحتاج التطبيق للإنترنت، وتبقى معالجة الصور وتوليد Word وPDF على الهاتف. التصوير والمعرض من واجهة Android الأصلية بواسطة `image_picker`، والحفظ عبر منتقي ملفات Android بواسطة `flutter_file_dialog`.

## المحتويات

- `lib/main.dart`: تكامل Flutter مع الكاميرا، المعرض، حفظ PDF/DOCX، المشاركة وفتح ملفات الطباعة.
- `assets/app/index.html`: واجهة عربية RTL كاملة؛ تسعة تخطيطات وترتيب ومعاينة وتحرير.
- `android/`: ملفات تطبيق Android وإعدادات Gradle والهوية والأيقونات.
- `test/basic_test.dart`: اختبارات وجود الواجهة والوظائف الأساسية.
- `build-mustamsakati.yml`: GitHub Actions يعمل مباشرة من هذا ZIP؛ يجهّز Gradle wrapper تلقائياً.

## طريقة البناء — بدون فك الضغط يدوياً

1. ارفع الملف `mustamsakati.zip` إلى جذر مستودع GitHub كملف ZIP واحد.
2. ضع ملف `build-mustamsakati.yml` داخل `.github/workflows/build-mustamsakati.yml` في المستودع. **لا ترفع فقط YAML كملف ZIP**.
3. من Actions شغّل **Build Mustamsakati APK From ZIP**.
4. بعد نجاح البناء حمّل `mustamsakati-release-apk` من Artifacts.

> يحتاج جهاز بناء GitHub إلى تنزيل Flutter وحزم pub وGradle للمرة الأولى. هذا لا يعني أن التطبيق يحتاج إنترنت عند الاستخدام.

## التطوير محلياً

```
flutter pub get
flutter create --platforms=android --org iq.mustamsakati --project-name mustamsakati .
flutter analyze
flutter test
flutter build apk --release
```

الملف `gradle-wrapper.jar` يولَّد آلياً بواسطة `flutter create` في GitHub Actions، لأنه ملف ثنائي تابع لإصدار Flutter وليس مكتوباً يدوياً.

## ملاحظات مهمة

- الكاميرا الأصلية تعمل بالالتقاط اليدوي، وخيارات التحسين والقص المتوفرة داخل HTML ليست بديلاً عن محرك اكتشاف حدود OpenCV على Android؛ اكتشاف الحدود المتقدم تلقائياً ليس جزءاً من هذا الإصدار.
- صفحة «ملفاتي» داخل HTML تعرض صادرات جلسة العمل. الملفات التي حفظتها عبر نافذة Android تبقى في المكان الذي اخترته؛ لم نضف أرشيفاً دائماً غير مشفر إلى التطبيق احتراماً لخصوصيتك.
- طباعة PDF تفتح عارض Android حيث يمكنك اختيار «طباعة» حسب تطبيق العرض الموجود على الجهاز.
- إصدار APK في هذا المشروع موقّع بمفتاح التطوير في CI للاختبار، وليس بتوقيع نشر Google Play. عند النشر يلزم مفتاح إصدار خاص وآمن.
- لا يتم رفع صور الوثائق إلى أي خادم، ولا توجد اتصالات إنترنت في التطبيق.
