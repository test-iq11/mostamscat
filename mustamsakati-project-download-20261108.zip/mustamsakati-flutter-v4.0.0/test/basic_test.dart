import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Android build project has packaged offline HTML asset', () async {
    final page = File('assets/app/index.html');
    expect(await page.exists(), isTrue);
    final html = await page.readAsString();
    expect(html, contains('مستمسكاتي'));
    expect(html, contains('sideTop'));
    expect(html, contains('rightStack'));
    expect(html, contains('leftStack'));
    expect(html, contains('window.mustamsakatiReceiveImage'));
    expect(html, contains('exportBlobToNative'));
    expect(html, isNot(contains('كل مستمسكاتك، بتنسيق مثالي.')));
    expect(html, isNot(contains('وثائقك جاهزة للطباعة بكل سهولة')));
  });
}
