package iq.mustamsakati.mustamsakati

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
