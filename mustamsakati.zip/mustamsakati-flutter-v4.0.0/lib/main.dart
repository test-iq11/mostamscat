import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MustamsakatiApp());
}

class MustamsakatiApp extends StatelessWidget {
  const MustamsakatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مستمسكاتي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3767DA)),
      ),
      home: const MustamsakatiHome(),
    );
  }
}

class MustamsakatiHome extends StatefulWidget {
  const MustamsakatiHome({super.key});

  @override
  State<MustamsakatiHome> createState() => _MustamsakatiHomeState();
}

class _MustamsakatiHomeState extends State<MustamsakatiHome> {
  late final WebViewController _controller;
  final ImagePicker _imagePicker = ImagePicker();
  bool _pageReady = false;
  bool _busyPicking = false;
  final List<String> _exportChunks = [];
  int _requiredChunks = 0;
  String _exportFileName = 'مستمسكاتي.pdf';
  String _exportMode = 'download';
  static const int _maxBase64Size = 96 * 1024 * 1024;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController();
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    try {
      await _controller.setJavaScriptMode(JavaScriptMode.unrestricted);
      await _controller.setBackgroundColor(const Color(0xFFF6F8FC));
      await _controller.setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _pageReady = true);
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame ?? false) {
              _message('تعذر تحميل الواجهة: ${error.description}');
            }
          },
        ),
      );
      await _controller.addJavaScriptChannel(
        'MustamsakatiBridge',
        onMessageReceived: (message) {
          unawaited(_receive(message.message));
        },
      );
      await _controller.loadFlutterAsset('assets/app/index.html');
    } catch (error) {
      _message('حدث خطأ في تشغيل التطبيق: $error');
    }
  }

  Future<void> _receive(String raw) async {
    try {
      final request = jsonDecode(raw);
      if (request is! Map<String, dynamic>) return;
      switch (request['type']) {
        case 'exit':
          await SystemNavigator.pop();
          return;
        case 'pickImage':
          await _pickImage(
            request['side'] as String? ?? 'front',
            request['source'] as String? ?? 'gallery',
          );
          return;
        case 'exportBegin':
          _exportChunks.clear();
          _requiredChunks = (request['parts'] as num?)?.toInt() ?? 0;
          _exportFileName = _safeFileName(request['name'] as String?);
          _exportMode = request['mode'] as String? ?? 'download';
          if (_requiredChunks <= 0 || _requiredChunks > 3000) {
            throw const FormatException('حجم الملف غير صالح');
          }
          await _ack();
          return;
        case 'exportPart':
          final index = (request['part'] as num?)?.toInt() ?? -1;
          final part = request['data'] as String? ?? '';
          if (index != _exportChunks.length || part.length > 48000) {
            throw const FormatException('خطأ في ترتيب أجزاء الملف');
          }
          _exportChunks.add(part);
          await _ack();
          return;
        case 'exportEnd':
          // Acknowledge immediately so the HTML side does not timeout while
          // Android's system Save As dialog is open.
          await _ack();
          await _finishExport();
          return;
      }
    } catch (error) {
      _message('تعذر إكمال العملية: $error');
      _exportChunks.clear();
      _requiredChunks = 0;
      // Release any outstanding JavaScript promise after reporting errors.
      await _ack();
    }
  }

  Future<void> _ack() async {
    try {
      await _controller.runJavaScript('window.mustamsakatiAck?.()');
    } catch (_) {
      // WebView may have been disposed while the Android picker was open.
    }
  }

  String _safeFileName(String? name) {
    final value = (name ?? 'مستمسكاتي.pdf').replaceAll(
      RegExp(r'[\\/:*?"<>|\x00-\x1F]'),
      '_',
    );
    if (value.isEmpty || value == '.' || value == '..') return 'مستمسكاتي.pdf';
    return value.length > 140 ? value.substring(value.length - 140) : value;
  }

  Future<void> _pickImage(String side, String source) async {
    if (_busyPicking) return;
    _busyPicking = true;
    try {
      final picked = await _imagePicker.pickImage(
        source: source == 'camera' ? ImageSource.camera : ImageSource.gallery,
        maxWidth: 3000,
        maxHeight: 3000,
        imageQuality: 93,
        requestFullMetadata: false,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      final file = picked.name.toLowerCase();
      final mime = file.endsWith('.png') ? 'image/png' : 'image/jpeg';
      final dataUrl = 'data:$mime;base64,${base64Encode(bytes)}';
      await _controller.runJavaScript(
        'window.mustamsakatiReceiveImage(${jsonEncode(side)},${jsonEncode(dataUrl)});',
      );
    } catch (error) {
      _message('تعذر فتح الكاميرا أو الصورة: $error');
    } finally {
      _busyPicking = false;
    }
  }

  Future<void> _finishExport() async {
    if (_exportChunks.length != _requiredChunks) {
      _message('الملف لم يكتمل؛ أعد التصدير');
      _exportChunks.clear();
      return;
    }
    final data = _exportChunks.join();
    _exportChunks.clear();
    _requiredChunks = 0;
    if (data.length > _maxBase64Size) {
      _message('حجم الملف كبير جداً؛ قلّل عدد الصور');
      return;
    }
    try {
      final bytes = base64Decode(data);
      final mime = _exportFileName.toLowerCase().endsWith('.pdf')
          ? 'application/pdf'
          : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      if (_exportMode == 'download') {
        final location = await FlutterFileDialog.saveFile(
          params: SaveFileDialogParams(
            data: Uint8List.fromList(bytes),
            fileName: _exportFileName,
            mimeTypesFilter: [mime],
          ),
        );
        if (location != null) {
          _message('تم حفظ الملف في المكان الذي اخترته');
        } else {
          _message('أُلغيت عملية الحفظ');
        }
        return;
      }
      final temp = await getTemporaryDirectory();
      final path = '${temp.path}/${DateTime.now().microsecondsSinceEpoch}_$_exportFileName';
      final file = File(path);
      await file.writeAsBytes(bytes, flush: true);
      if (_exportMode == 'share') {
        await Share.shareXFiles(
          [XFile(file.path, mimeType: mime)],
          text: 'مستند من تطبيق مستمسكاتي',
        );
      } else {
        // For both PDF printing and opening a saved session file, use the
        // installed system viewer (its Print action provides printer access).
        await OpenFilex.open(file.path);
      }
    } catch (error) {
      _message('حدث خطأ أثناء حفظ الملف: $error');
    }
  }

  void _message(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message, textDirection: TextDirection.rtl)),
    );
  }

  void _handleBack() {
    unawaited(_controller.runJavaScript("""
      if (typeof state !== 'undefined') {
        if (state.modal) closeModal();
        else if (state.screen === 'studio' && state.step > 1) {
          state.step--; render();
        } else if (state.screen !== 'home') go('home');
        else window.MustamsakatiBridge.postMessage(JSON.stringify({type:'exit'}));
      }
    """));
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _handleBack();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFF6F8FC),
        body: SafeArea(
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (!_pageReady)
                const Center(child: CircularProgressIndicator()),
            ],
          ),
        ),
      ),
    );
  }
}
