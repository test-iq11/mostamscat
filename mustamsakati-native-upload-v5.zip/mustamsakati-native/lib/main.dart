import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'exporters.dart';
import 'layouts.dart';
import 'perspective.dart';

void main() => runApp(const MustamsakatiApp());

const _navy = Color(0xFF132B45);
const _blue = Color(0xFF176D85);
const _pageBg = Color(0xFFF4F7FA);
const _types = <(String, IconData)>[
  ('البطاقة الوطنية', Icons.badge_outlined),
  ('إجازة السوق', Icons.drive_eta_outlined),
  ('بطاقة السكن', Icons.home_work_outlined),
  ('جواز السفر', Icons.menu_book_outlined),
  ('هوية الأحوال المدنية', Icons.contact_page_outlined),
  ('شهادة الجنسية', Icons.workspace_premium_outlined),
  ('مستمسك آخر', Icons.description_outlined),
];

class MustamsakatiApp extends StatefulWidget {
  const MustamsakatiApp({super.key});

  @override
  State<MustamsakatiApp> createState() => _MustamsakatiAppState();
}

class _MustamsakatiAppState extends State<MustamsakatiApp> {
  final PrintSettings _settings = PrintSettings();

  @override
  void initState() {
    super.initState();
    _restoreTheme();
  }

  Future<void> _restoreTheme() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() => _settings.dark = prefs.getBool('dark') ?? false);
  }

  @override
  Widget build(BuildContext context) {
    final seed = _settings.accent;
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: _settings.dark ? Brightness.dark : Brightness.light,
    );
    return MaterialApp(
      title: 'مستمسكاتي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: _settings.dark ? null : _pageBg,
        cardTheme: CardThemeData(
          elevation: 0,
          color: scheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size(0, 50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
      home: ScannerHome(settings: _settings, onThemeChange: () => setState(() {})),
    );
  }
}

class ScannerHome extends StatefulWidget {
  const ScannerHome({super.key, required this.settings, required this.onThemeChange});
  final PrintSettings settings;
  final VoidCallback onThemeChange;

  @override
  State<ScannerHome> createState() => _ScannerHomeState();
}

class _ScannerHomeState extends State<ScannerHome> {
  final ImagePicker _picker = ImagePicker();
  final List<ScanDocument> _documents = [];
  final Map<int, Offset> _freePositions = {};
  final TextEditingController _filename = TextEditingController(text: 'مستمسكاتي');
  int _navigation = 0;
  int _stage = 0; // 0 home, 1 scanning, 2 layout
  int _currentDoc = 0;
  int _visiblePage = 0;
  bool _busy = false;
  List<File> _saved = [];

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  @override
  void dispose() {
    _filename.dispose();
    super.dispose();
  }

  Future<Directory> _outputDirectory() async {
    final directory = Directory('${(await getApplicationDocumentsDirectory()).path}/mustamsakati');
    if (!await directory.exists()) await directory.create(recursive: true);
    return directory;
  }

  Future<void> _loadSaved() async {
    final directory = await _outputDirectory();
    final files = directory.listSync().whereType<File>().where((f) =>
        f.path.endsWith('.pdf') || f.path.endsWith('.docx')).toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    if (mounted) setState(() => _saved = files);
  }

  Future<void> _selectType(String label) async {
    setState(() {
      _documents.add(ScanDocument(label));
      _currentDoc = _documents.length - 1;
      _stage = 1;
      _navigation = 0;
    });
  }

  Future<void> _chooseKind() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('اختر نوع المستمسك'),
        contentPadding: const EdgeInsets.symmetric(vertical: 10),
        content: SizedBox(
          width: 340,
          child: ListView(shrinkWrap: true, children: [
            for (final entry in _types)
              ListTile(
                leading: Icon(entry.$2, color: _blue),
                title: Text(entry.$1),
                onTap: () {
                  Navigator.pop(dialogContext);
                  _selectType(entry.$1);
                },
              ),
          ]),
        ),
      ),
    );
  }

  Future<PhotoData> _photo(Uint8List bytes) async {
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final result = PhotoData(bytes, frame.image.width, frame.image.height);
    frame.image.dispose();
    codec.dispose();
    return result;
  }

  Future<void> _getPicture(bool back, ImageSource source) async {
    try {
      final file = await _picker.pickImage(source: source, imageQuality: 95);
      if (file == null) return;
      setState(() => _busy = true);
      final normalized = await normalizeImage(await file.readAsBytes());
      if (source == ImageSource.camera) {
        try { await File(file.path).delete(); } catch (_) { /* Cached capture may be inaccessible. */ }
      }
      final rawPhoto = await _photo(normalized);
      if (!mounted) return;
      final corrected = await Navigator.push<PhotoData>(
        context,
        MaterialPageRoute(builder: (_) => CornerEditor(photo: rawPhoto)),
      );
      if (!mounted) return;
      setState(() {
        if (back) {
          _documents[_currentDoc].back = corrected ?? rawPhoto;
        } else {
          _documents[_currentDoc].front = corrected ?? rawPhoto;
        }
      });
    } catch (error) {
      if (mounted) _message('تعذّر فتح الصورة: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _editImage(bool back) async {
    final source = back ? _documents[_currentDoc].back : _documents[_currentDoc].front;
    if (source == null) return;
    final photo = await Navigator.push<PhotoData>(
      context,
      MaterialPageRoute(builder: (_) => CornerEditor(photo: source)),
    );
    if (photo == null || !mounted) return;
    setState(() {
      if (back) {
        _documents[_currentDoc].back = photo;
      } else {
        _documents[_currentDoc].front = photo;
      }
    });
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  List<LayoutSheet> get _sheets => [
    for (var i = 0; i < _documents.length; ++i)
      ...layoutDocument(_documents[i], widget.settings,
          freeOffsets: i == _currentDoc ? _freePositions : const {}),
  ];

  Future<void> _export(bool word) async {
    final sheets = _sheets;
    if (sheets.isEmpty) {
      _message('أضف صورة واحدة على الأقل أولاً');
      return;
    }
    setState(() => _busy = true);
    try {
      final data = word
          ? Exporter.makeDocx(sheets, widget.settings)
          : await Exporter.makePdf(sheets, widget.settings);
      final filename = _filename.text.trim().isEmpty
          ? 'مستمسكاتي'
          : _filename.text.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
      final extension = word ? 'docx' : 'pdf';
      final directory = await _outputDirectory();
      final saved = File('${directory.path}/${filename}_${DateTime.now().millisecondsSinceEpoch}.$extension');
      await saved.writeAsBytes(data, flush: true);
      await _loadSaved();
      if (!mounted) return;
      _message('تم حفظ ${word ? 'Word' : 'PDF'} داخل ملفات التطبيق');
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('تم إنشاء الملف بنجاح'),
          content: Text(saved.path.split('/').last),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
            TextButton(
              onPressed: () async {
                Navigator.pop(ctx);
                try {
                  await FilePicker.platform.saveFile(
                    dialogTitle: 'اختر مكان الحفظ',
                    fileName: '$filename.$extension',
                    bytes: data,
                  );
                } catch (_) {
                  if (mounted) _message('يمكن مشاركة الملف واختيار «حفظ في الملفات»');
                }
              },
              child: const Text('حفظ في مجلد'),
            ),
            FilledButton(
              onPressed: () async {
                Navigator.pop(ctx);
                await _shareFile(saved);
              },
              child: const Text('مشاركة'),
            ),
          ],
        ),
      );
    } catch (error) {
      if (mounted) _message('فشل إنشاء المستند: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _shareFile(File file) async {
    try {
      await SharePlus.instance.share(ShareParams(files: [XFile(file.path)]));
    } catch (error) {
      if (mounted) _message('تعذرت المشاركة: $error');
    }
  }

  Future<void> _printPdf() async {
    try {
      if (_sheets.isEmpty) return;
      await Printing.layoutPdf(onLayout: (_) => Exporter.makePdf(_sheets, widget.settings));
    } catch (error) {
      if (mounted) _message('تعذرت الطباعة: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          Image.asset('assets/icons/ic_launcher_192.png',
              width: 38, height: 38),
          const SizedBox(width: 10),
          const Text('مستمسكاتي', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22)),
        ]),
        backgroundColor: scheme.surface,
        actions: [
          if (_stage != 0 && _navigation == 0)
            IconButton(
              tooltip: 'العودة',
              onPressed: () => setState(() => _stage = _stage == 2 ? 1 : 0),
              icon: const Icon(Icons.arrow_back_rounded),
            ),
        ],
      ),
      body: Stack(children: [
        SafeArea(
          child: _navigation == 1
              ? _filesPage()
              : _navigation == 2
                  ? _settingsPage()
                  : _stage == 0
                      ? _homePage()
                      : _stage == 1
                          ? _scanPage()
                          : _layoutPage(),
        ),
        if (_busy)
          ColoredBox(
            color: Colors.black45,
            child: const Center(child: Card(child: Padding(
              padding: EdgeInsets.all(26),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                CircularProgressIndicator(),
                SizedBox(height: 12),
                Text('جارٍ معالجة الملف...'),
              ]),
            ))),
          ),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navigation,
        onDestinationSelected: (index) => setState(() => _navigation = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder), label: 'ملفاتي'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }

  Widget _homePage() => ListView(padding: const EdgeInsets.all(16), children: [
    _heroCard(),
    const SizedBox(height: 24),
    _sectionTitle('اختر نوع المستمسك'),
    const SizedBox(height: 12),
    GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _types.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10,
        childAspectRatio: 1.72,
      ),
      itemBuilder: (_, i) => InkWell(
        onTap: () => _selectType(_types[i].$1),
        borderRadius: BorderRadius.circular(18),
        child: Card(child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Icon(_types[i].$2, color: _blue, size: 27),
            Text(_types[i].$1, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
          ]),
        )),
      ),
    ),
    if (_saved.isNotEmpty) ...[
      const SizedBox(height: 18),
      _sectionTitle('آخر الملفات'),
      const SizedBox(height: 8),
      ..._saved.take(3).map((f) => ListTile(
        leading: Icon(f.path.endsWith('.pdf') ? Icons.picture_as_pdf_outlined : Icons.description_outlined, color: _blue),
        title: Text(f.path.split('/').last, maxLines: 1, overflow: TextOverflow.ellipsis),
        trailing: IconButton(onPressed: () => _shareFile(f), icon: const Icon(Icons.share_outlined)),
      )),
    ],
  ]);

  Widget _heroCard() => Container(
    height: 166, // 20% shorter than the previous hero
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(colors: [_navy, Color(0xFF176B85)]),
    ),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('تصوير مستمسك جديد', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
        const Text('صوّر الوجهين ونسّقهما للطباعة', style: TextStyle(color: Color(0xFFDBE9F3), fontSize: 12)),
        FilledButton.icon(
          onPressed: _chooseKind,
          style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: _navy, minimumSize: const Size(0, 40)),
          icon: const Icon(Icons.arrow_back_rounded),
          label: const Text('ابدأ الآن'),
        ),
      ])),
      const SizedBox(width: 6),
      const Icon(Icons.document_scanner_outlined, color: Color(0xFFBDE5F4), size: 78),
    ]),
  );

  Widget _sectionTitle(String title) => Text(title,
    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800));

  Widget _scanPage() {
    if (_documents.isEmpty) return _homePage();
    final doc = _documents[_currentDoc];
    return ListView(padding: const EdgeInsets.all(16), children: [
      _progress(1),
      const SizedBox(height: 18),
      Row(children: [
        Expanded(child: Text(doc.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        TextButton.icon(onPressed: _chooseKind, icon: const Icon(Icons.add), label: const Text('مستمسك إضافي')),
      ]),
      const SizedBox(height: 12),
      _imageSlot('الوجه الأمامي', doc.front, false),
      const SizedBox(height: 14),
      _imageSlot(doc.title == 'جواز السفر' ? 'صفحة ثانية (اختياري)' : 'الوجه الخلفي (اختياري)', doc.back, true),
      const SizedBox(height: 14),
      if (_documents.length > 1)
        Card(child: Padding(
          padding: const EdgeInsets.all(12),
          child: Wrap(spacing: 8, runSpacing: 4, children: [
            for (var i = 0; i < _documents.length; ++i)
              InputChip(label: Text(_documents[i].title), selected: i == _currentDoc,
                onPressed: () => setState(() => _currentDoc = i),
                onDeleted: _documents.length > 1 ? () => setState(() {
                  _documents.removeAt(i);
                  _currentDoc = 0;
                }) : null),
          ]),
        )),
      const SizedBox(height: 14),
      FilledButton.icon(
        onPressed: _documents.any((d) => d.photos.isNotEmpty) ? () => setState(() {
          _stage = 2;
          _visiblePage = 0;
        }) : null,
        icon: const Icon(Icons.auto_awesome_motion_outlined),
        label: const Text('التالي: ترتيب الصور والمعاينة'),
      ),
      const SizedBox(height: 20),
    ]);
  }

  Widget _imageSlot(String heading, PhotoData? image, bool back) => Card(
    child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(heading, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 12),
        if (image != null) ...[
          Container(
            height: 158, width: double.infinity,
            decoration: BoxDecoration(color: _pageBg, borderRadius: BorderRadius.circular(12)),
            child: ClipRRect(borderRadius: BorderRadius.circular(12),
              child: Image.memory(image.bytes, fit: BoxFit.contain, gaplessPlayback: true)),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: () => _editImage(back), icon: const Icon(Icons.crop_rotate), label: const Text('تصحيح الزوايا'))),
            const SizedBox(width: 6),
            IconButton(tooltip: 'حذف', onPressed: () => setState(() {
              if (back) { _documents[_currentDoc].back = null; }
              else { _documents[_currentDoc].front = null; }
            }), icon: const Icon(Icons.delete_outline, color: Colors.redAccent)),
          ]),
        ],
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            icon: const Icon(Icons.camera_alt_outlined),
            label: Text(image == null ? 'تصوير' : 'إعادة تصوير'),
            onPressed: () => _getPicture(back, ImageSource.camera),
          )),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(
            icon: const Icon(Icons.photo_library_outlined),
            label: const Text('المعرض'),
            onPressed: () => _getPicture(back, ImageSource.gallery),
          )),
        ]),
      ],
    )),
  );

  Widget _progress(int step) => Row(children: [
    for (var i = 1; i <= 3; ++i) ...[
      Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: i <= step ? _blue : Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(['التصوير', 'التنسيق', 'التصدير'][i - 1],
          textAlign: TextAlign.center,
          style: TextStyle(color: i <= step ? Colors.white : null, fontWeight: FontWeight.w700, fontSize: 12)),
      )),
      if (i < 3) const SizedBox(width: 5),
    ],
  ]);

  Widget _layoutPage() {
    final sheets = _sheets;
    if (sheets.isEmpty) return Center(child: FilledButton(onPressed: () => setState(() => _stage = 1), child: const Text('أضف صوراً أولاً')));
    final pageIndex = _visiblePage.clamp(0, sheets.length - 1).toInt();
    final page = widget.settings.paper;
    return ListView(padding: const EdgeInsets.all(14), children: [
      _progress(2),
      const SizedBox(height: 16),
      _sectionTitle('طريقة عرض الصور'),
      const SizedBox(height: 10),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: LayoutStyle.values.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .98),
        itemBuilder: (_, i) {
          final mode = LayoutStyle.values[i];
          final active = widget.settings.style == mode;
          return InkWell(
            onTap: () => setState(() { widget.settings.style = mode; _visiblePage = 0; }),
            borderRadius: BorderRadius.circular(14),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: active ? _blue.withValues(alpha: .09) : Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: active ? _blue : Colors.transparent, width: active ? 2 : 1),
              ),
              child: Column(children: [
                Expanded(child: CustomPaint(painter: _LayoutIconPainter(mode))),
                Text(mode.label, textAlign: TextAlign.center, maxLines: 2,
                  style: TextStyle(fontSize: 10, fontWeight: active ? FontWeight.w800 : FontWeight.w600)),
              ]),
            ),
          );
        },
      ),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: _sectionTitle('معاينة الصفحة')),
        Text('صفحة ${pageIndex + 1} من ${sheets.length}', style: const TextStyle(fontSize: 12)),
        IconButton(onPressed: pageIndex > 0 ? () => setState(() => _visiblePage--) : null,
          icon: const Icon(Icons.chevron_right_rounded)),
        IconButton(onPressed: pageIndex < sheets.length - 1 ? () => setState(() => _visiblePage++) : null,
          icon: const Icon(Icons.chevron_left_rounded)),
      ]),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: const Color(0xFFE5EBF1), borderRadius: BorderRadius.circular(18)),
        child: Center(child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 470, maxWidth: 375),
          child: AspectRatio(
            aspectRatio: page.width / page.height,
            child: LayoutBuilder(builder: (context, constraints) {
              final ratio = constraints.maxWidth / page.width;
              return Container(
                color: Colors.white,
                child: Stack(children: [
                  for (final item in sheets[pageIndex].placements)
                    Positioned(
                      left: item.rect.left * ratio,
                      top: item.rect.top * ratio,
                      width: item.rect.width * ratio,
                      height: item.rect.height * ratio,
                      child: GestureDetector(
                        onPanUpdate: widget.settings.style == LayoutStyle.free ? (details) {
                          final rect = item.rect;
                          setState(() {
                            _freePositions[item.index] = Offset(
                              (rect.left + details.delta.dx / ratio).clamp(widget.settings.margin,
                                page.width - widget.settings.margin - rect.width).toDouble(),
                              (rect.top + details.delta.dy / ratio).clamp(widget.settings.margin,
                                page.height - widget.settings.margin - rect.height).toDouble(),
                            );
                          });
                        } : null,
                        child: Image.memory(item.photo.bytes, fit: BoxFit.contain),
                      ),
                    ),
                  if (sheets[pageIndex].cutLine)
                    Positioned(left: widget.settings.margin * ratio,
                      top: (page.height / 2) * ratio,
                      width: (page.width - 2 * widget.settings.margin) * ratio,
                      child: const Divider(thickness: 1, color: Colors.grey)),
                ]),
              );
            }),
          ),
        )),
      ),
      if (widget.settings.style == LayoutStyle.free)
        const Padding(padding: EdgeInsets.only(top: 8), child: Text('اسحب كل صورة إلى مكانها الجديد داخل الورقة', textAlign: TextAlign.center)),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(13), child: Column(children: [
        Row(children: [
          Expanded(child: _paperOption()),
          const SizedBox(width: 8),
          Expanded(child: _paperDirection()),
        ]),
        _slider('هوامش الصفحة', widget.settings.margin, 18, 65, (v) => setState(() => widget.settings.margin = v)),
        _slider('المسافة بين الصورتين', widget.settings.gap, 5, 45, (v) => setState(() => widget.settings.gap = v)),
        _slider('حجم الصور', widget.settings.scale, .65, 1.2, (v) => setState(() => widget.settings.scale = v)),
        if (widget.settings.style == LayoutStyle.halves)
          SwitchListTile(title: const Text('خط القص بين النصفين'),
            value: widget.settings.showCut,
            onChanged: (value) => setState(() => widget.settings.showCut = value)),
      ]))),
      const SizedBox(height: 14),
      TextField(controller: _filename, decoration: const InputDecoration(
        border: OutlineInputBorder(), labelText: 'اسم الملف', prefixIcon: Icon(Icons.drive_file_rename_outline))),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: () => _export(false), icon: const Icon(Icons.picture_as_pdf_outlined), label: const Text('حفظ PDF'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.tonalIcon(onPressed: () => _export(true), icon: const Icon(Icons.description_outlined), label: const Text('حفظ Word'))),
      ]),
      TextButton.icon(onPressed: _printPdf, icon: const Icon(Icons.print_outlined), label: const Text('طباعة مباشرة')),
      TextButton(onPressed: () => setState(() => _stage = 1), child: const Text('العودة إلى الصور')),
      const SizedBox(height: 20),
    ]);
  }

  Widget _paperOption() => DropdownButtonFormField<bool>(
    initialValue: widget.settings.a5,
    decoration: const InputDecoration(labelText: 'حجم الورق', border: OutlineInputBorder()),
    items: const [
      DropdownMenuItem(value: false, child: Text('A4')),
      DropdownMenuItem(value: true, child: Text('A5')),
    ],
    onChanged: (v) => setState(() => widget.settings.a5 = v ?? false),
  );

  Widget _paperDirection() => DropdownButtonFormField<bool>(
    initialValue: widget.settings.landscape,
    decoration: const InputDecoration(labelText: 'اتجاه الصفحة', border: OutlineInputBorder()),
    items: const [
      DropdownMenuItem(value: false, child: Text('عمودي')),
      DropdownMenuItem(value: true, child: Text('أفقي')),
    ],
    onChanged: (v) => setState(() => widget.settings.landscape = v ?? false),
  );

  Widget _slider(String title, double value, double min, double max, ValueChanged<double> onChanged) =>
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.only(top: 12), child: Text(title,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
      Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged),
    ]);

  Widget _filesPage() => RefreshIndicator(
    onRefresh: _loadSaved,
    child: ListView(padding: const EdgeInsets.all(16), children: [
      _sectionTitle('الملفات المحفوظة'),
      const SizedBox(height: 10),
      if (_saved.isEmpty)
        const Padding(padding: EdgeInsets.all(40), child: Column(children: [
          Icon(Icons.folder_open_outlined, size: 62, color: Colors.blueGrey),
          SizedBox(height: 10),
          Text('لم تحفظ أي ملفات بعد'),
        ]))
      else
        for (final f in _saved)
          Card(child: ListTile(
            leading: Icon(f.path.endsWith('.pdf') ? Icons.picture_as_pdf : Icons.description, color: _blue),
            title: Text(f.path.split('/').last, maxLines: 2),
            subtitle: Text('${(f.lengthSync() / 1024).round()} KB'),
            trailing: PopupMenuButton<String>(
              onSelected: (choice) async {
                if (choice == 'share') { await _shareFile(f); }
                if (choice == 'delete') { await f.delete(); await _loadSaved(); }
                if (choice == 'print' && f.path.endsWith('.pdf')) {
                  await Printing.layoutPdf(onLayout: (_) => f.readAsBytes());
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'share', child: Text('مشاركة')),
                if (f.path.endsWith('.pdf')) const PopupMenuItem(value: 'print', child: Text('طباعة')),
                const PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          )),
    ]),
  );

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(16), children: [
    _sectionTitle('إعدادات التطبيق'),
    const SizedBox(height: 12),
    Card(child: Column(children: [
      SwitchListTile(
        title: const Text('الوضع الليلي'),
        secondary: const Icon(Icons.dark_mode_outlined),
        value: widget.settings.dark,
        onChanged: (v) async {
          widget.settings.dark = v;
          widget.onThemeChange();
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('dark', v);
        },
      ),
      const Divider(height: 1),
      ListTile(
        title: const Text('اللون الرئيسي'),
        leading: const Icon(Icons.palette_outlined),
        subtitle: const Text('اختر لوناً هادئاً للتطبيق'),
        trailing: Wrap(spacing: 6, children: [
          for (final c in [const Color(0xFF136C83), const Color(0xFF377B57), const Color(0xFF7054A3)])
            InkWell(
              onTap: () { widget.settings.accent = c; widget.onThemeChange(); },
              child: CircleAvatar(radius: 11, backgroundColor: c),
            ),
        ]),
      ),
    ])),
    Card(child: Column(children: [
      const ListTile(leading: Icon(Icons.lock_outline), title: Text('الخصوصية'),
        subtitle: Text('الصور تُعالج محلياً على الهاتف ولا تُرفع إلى خادم')),
      const Divider(height: 1),
      ListTile(
        leading: const Icon(Icons.delete_sweep_outlined),
        title: const Text('حذف الملفات المؤقتة'),
        onTap: () async {
          final directory = await getTemporaryDirectory();
          for (final file in directory.listSync().whereType<File>()) {
            if (file.path.contains('mustamsakati_temp_')) await file.delete();
          }
          if (mounted) _message('تم تنظيف الملفات المؤقتة');
        },
      ),
      const Divider(height: 1),
      const ListTile(leading: Icon(Icons.info_outline),
        title: Text('مستمسكاتي 5.0'), subtitle: Text('تطبيق Flutter أصلي — بدون WebView')),
    ])),
  ]);
}

class CornerEditor extends StatefulWidget {
  const CornerEditor({super.key, required this.photo});
  final PhotoData photo;

  @override
  State<CornerEditor> createState() => _CornerEditorState();
}

class _CornerEditorState extends State<CornerEditor> {
  late List<Offset> _corners;
  int _active = -1;
  int _rotation = 0;
  double _brightness = 0;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _corners = List.of(defaultCorners);
  }

  @override
  Widget build(BuildContext context) {
    final aspect = widget.photo.aspect;
    return Scaffold(
      appBar: AppBar(title: const Text('تصحيح الزوايا والمنظور')),
      body: SafeArea(child: Column(children: [
        const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Text('حرّك زاوية واحدة بإصبعك؛ ستبقى الزوايا الثلاث الأخرى ثابتة.',
            textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w600))),
        Expanded(child: Padding(
          padding: const EdgeInsets.all(14),
          child: LayoutBuilder(builder: (context, limits) {
            final width = math.min(limits.maxWidth, limits.maxHeight * aspect);
            final height = width / aspect;
            return Center(child: SizedBox(
              width: width, height: height,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanStart: (details) {
                  final point = details.localPosition;
                  var near = double.infinity;
                  var index = -1;
                  for (var i = 0; i < 4; ++i) {
                    final p = Offset(_corners[i].dx * width, _corners[i].dy * height);
                    final distance = (p - point).distance;
                    if (distance < near && distance < 45) {
                      near = distance;
                      index = i;
                    }
                  }
                  setState(() => _active = index);
                },
                onPanUpdate: (details) {
                  if (_active < 0) return;
                  final newPoint = Offset(
                    (details.localPosition.dx / width).clamp(0.0, 1.0),
                    (details.localPosition.dy / height).clamp(0.0, 1.0),
                  );
                  final candidate = List<Offset>.from(_corners);
                  candidate[_active] = newPoint;
                  if (isValidQuadrilateral(candidate)) {
                    setState(() => _corners = candidate);
                  }
                },
                onPanEnd: (_) => setState(() => _active = -1),
                child: Stack(fit: StackFit.expand, children: [
                  Image.memory(widget.photo.bytes, fit: BoxFit.fill),
                  CustomPaint(painter: _CornersPainter(_corners, _active)),
                ]),
              ),
            ));
          }),
        )),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Column(children: [
          Row(children: [
            OutlinedButton.icon(onPressed: () => setState(() => _corners = List.of(defaultCorners)),
              icon: const Icon(Icons.restart_alt), label: const Text('إعادة الزوايا')),
            const SizedBox(width: 8),
            OutlinedButton.icon(onPressed: () => setState(() => _rotation = (_rotation + 90) % 360),
              icon: const Icon(Icons.rotate_right), label: const Text('تدوير 90°')),
          ]),
          Row(children: [
            const Icon(Icons.brightness_6_outlined),
            const SizedBox(width: 8),
            const Text('الإضاءة'),
            Expanded(child: Slider(value: _brightness, min: -50, max: 50,
              onChanged: (v) => setState(() => _brightness = v))),
          ]),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            onPressed: _saving ? null : () async {
              setState(() => _saving = true);
              try {
                final bytes = await rectifyImage(PerspectiveArgs(
                  widget.photo.bytes, _corners, _rotation, _brightness.round()));
                if (!context.mounted) return;
                final codec = await ui.instantiateImageCodec(bytes);
                final frame = await codec.getNextFrame();
                final result = PhotoData(bytes, frame.image.width, frame.image.height);
                frame.image.dispose();
                codec.dispose();
                if (context.mounted) Navigator.pop(context, result);
              } catch (e) {
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('تعذّر تصحيح المنظور: $e')));
              } finally {
                if (mounted) setState(() => _saving = false);
              }
            },
            icon: _saving ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.check_circle_outline_rounded),
            label: Text(_saving ? 'جارٍ التصحيح...' : 'تطبيق التصحيح'),
          )),
          const SizedBox(height: 12),
        ])),
      ])),
    );
  }
}

class _CornersPainter extends CustomPainter {
  const _CornersPainter(this.points, this.active);
  final List<Offset> points;
  final int active;

  @override
  void paint(Canvas canvas, Size size) {
    final coords = [for (final p in points) Offset(p.dx * size.width, p.dy * size.height)];
    final shape = Path()..moveTo(coords.first.dx, coords.first.dy);
    for (var i = 1; i < 4; ++i) {
      shape.lineTo(coords[i].dx, coords[i].dy);
    }
    shape.close();
    canvas.drawPath(shape, Paint()..color = Colors.black.withValues(alpha: .13));
    canvas.drawPath(shape, Paint()
      ..color = const Color(0xFF50E5E6)..strokeWidth = 2.3..style = PaintingStyle.stroke);
    for (var i = 0; i < coords.length; ++i) {
      canvas.drawCircle(coords[i], i == active ? 15 : 12, Paint()..color = Colors.white);
      canvas.drawCircle(coords[i], i == active ? 10 : 7, Paint()..color = i == active ? Colors.orange : _blue);
    }
  }

  @override
  bool shouldRepaint(covariant _CornersPainter old) =>
      old.active != active || old.points != points;
}

class _LayoutIconPainter extends CustomPainter {
  const _LayoutIconPainter(this.mode);
  final LayoutStyle mode;

  @override
  void paint(Canvas canvas, Size size) {
    final w = math.min(47.0, size.width * .65);
    final h = math.min(59.0, size.height * .91);
    final x = (size.width - w) / 2;
    final y = (size.height - h) / 2;
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, y, w, h), const Radius.circular(2)),
      Paint()..color = Colors.white);
    canvas.drawRect(Rect.fromLTWH(x, y, w, h), Paint()..color = Colors.blueGrey.withValues(alpha: .3)
      ..style = PaintingStyle.stroke);
    void image(double left, double top, double width, double height, Color color) =>
      canvas.drawRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(x + left * w, y + top * h, width * w, height * h),
        const Radius.circular(2)), Paint()..color = color);
    const first = Color(0xFF7BC5D8);
    const second = Color(0xFFA8C8A9);
    switch (mode) {
      case LayoutStyle.sideCenter:
        image(.09, .40, .39, .16, first); image(.52, .40, .39, .16, second);
      case LayoutStyle.verticalCenter:
        image(.24, .26, .52, .20, first); image(.24, .55, .52, .20, second);
      case LayoutStyle.separate:
        image(.12, .18, .76, .25, first); image(.12, .60, .76, .25, second);
      case LayoutStyle.halves:
        image(.16, .17, .68, .21, first); image(.16, .62, .68, .21, second);
      case LayoutStyle.single:
        image(.14, .37, .72, .26, first);
      case LayoutStyle.free:
        image(.12, .10, .46, .22, first); image(.39, .53, .47, .21, second);
      case LayoutStyle.sideTop:
        image(.09, .08, .39, .16, first); image(.52, .08, .39, .16, second);
      case LayoutStyle.stackRight:
        image(.42, .11, .50, .19, first); image(.42, .36, .50, .19, second);
      case LayoutStyle.stackLeft:
        image(.08, .11, .50, .19, first); image(.08, .36, .50, .19, second);
    }
  }

  @override
  bool shouldRepaint(covariant _LayoutIconPainter old) => old.mode != mode;
}
