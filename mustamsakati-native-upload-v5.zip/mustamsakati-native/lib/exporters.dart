import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'layouts.dart';

class Exporter {
  const Exporter._();

  static Future<Uint8List> makePdf(
      List<LayoutSheet> sheets, PrintSettings settings) async {
    final result = pw.Document(compress: true);
    final p = settings.paper;
    for (final sheet in sheets) {
      result.addPage(pw.Page(
        pageFormat: PdfPageFormat(p.width, p.height),
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.SizedBox(
          width: p.width,
          height: p.height,
          child: pw.Stack(children: [
          for (final item in sheet.placements)
            pw.Positioned(
              left: item.rect.left,
              top: item.rect.top,
              child: pw.Image(pw.MemoryImage(item.photo.bytes),
                  width: item.rect.width,
                  height: item.rect.height,
                  fit: pw.BoxFit.contain),
            ),
          if (sheet.cutLine)
            pw.Positioned(
              left: settings.margin,
              top: p.height / 2,
              child: pw.Container(
                width: p.width - 2 * settings.margin,
                height: 0.5,
                color: PdfColors.grey400,
              ),
            ),
          ]),
        ),
      ));
    }
    return result.save();
  }

  /// DOCX with genuine editable image objects and page-relative coordinates.
  /// All images remain individually selectable in Microsoft Word.
  static Uint8List makeDocx(List<LayoutSheet> sheets, PrintSettings settings) {
    final archive = Archive();
    final relationships = StringBuffer();
    final body = StringBuffer();
    var imageId = 0;
    var drawingId = 0;
    const emuPerPoint = 12700;
    int emu(double points) => (points * emuPerPoint).round();
    final images = <String, Uint8List>{};

    for (var pageIndex = 0; pageIndex < sheets.length; ++pageIndex) {
      body.write('<w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr>');
      final sheet = sheets[pageIndex];
      for (final item in sheet.placements) {
        final rid = ++imageId;
        final did = ++drawingId;
        images['word/media/image$rid.jpg'] = item.photo.bytes;
        relationships.write(
          '<Relationship Id="rId$rid" '
          'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" '
          'Target="media/image$rid.jpg"/>',
        );
        final x = emu(item.rect.left);
        final y = emu(item.rect.top);
        final w = emu(item.rect.width);
        final h = emu(item.rect.height);
        body.write('''
<w:r><w:drawing>
<wp:anchor distT="0" distB="0" distL="0" distR="0" simplePos="0"
 relativeHeight="251659264" behindDoc="0" locked="0" layoutInCell="1" allowOverlap="1">
<wp:simplePos x="0" y="0"/>
<wp:positionH relativeFrom="page"><wp:posOffset>$x</wp:posOffset></wp:positionH>
<wp:positionV relativeFrom="page"><wp:posOffset>$y</wp:posOffset></wp:positionV>
<wp:extent cx="$w" cy="$h"/>
<wp:effectExtent l="0" t="0" r="0" b="0"/>
<wp:wrapNone/>
<wp:docPr id="$did" name="Document Image $did"/>
<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>
<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
<pic:pic>
<pic:nvPicPr><pic:cNvPr id="$did" name="Image $did"/><pic:cNvPicPr/></pic:nvPicPr>
<pic:blipFill><a:blip r:embed="rId$rid"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$w" cy="$h"/></a:xfrm>
<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>
</pic:pic></a:graphicData></a:graphic>
</wp:anchor></w:drawing></w:r>''');
      }
      if (pageIndex < sheets.length - 1) {
        body.write('<w:r><w:br w:type="page"/></w:r>');
      }
      body.write('</w:p>');
    }

    final page = settings.paper;
    final widthTwips = (page.width * 20).round();
    final heightTwips = (page.height * 20).round();
    final document = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
 xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
 xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
 xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
 xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
<w:body>$body<w:sectPr>
<w:pgSz w:w="$widthTwips" w:h="$heightTwips"/>
<w:pgMar w:top="0" w:right="0" w:bottom="0" w:left="0" w:header="0" w:footer="0" w:gutter="0"/>
</w:sectPr></w:body></w:document>''';

    archive.addFile(ArchiveFile.string('[Content_Types].xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Default Extension="jpg" ContentType="image/jpeg"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>'''.trim()));
    archive.addFile(ArchiveFile.string('_rels/.rels', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>'''.trim()));
    archive.addFile(ArchiveFile.string('word/document.xml', document));
    archive.addFile(ArchiveFile.string('word/_rels/document.xml.rels', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$relationships</Relationships>'''.trim()));
    archive.addFile(ArchiveFile.string('docProps/core.xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Mustamsakati Document</dc:title></cp:coreProperties>'''.trim()));
    archive.addFile(ArchiveFile.string('docProps/app.xml', '''
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Mustamsakati</Application></Properties>'''.trim()));
    for (final item in images.entries) {
      archive.addFile(ArchiveFile.bytes(item.key, item.value));
    }
    return Uint8List.fromList(ZipEncoder().encodeBytes(archive));
  }

  static String xmlEscape(String input) =>
      const HtmlEscape(HtmlEscapeMode.element).convert(input);
}
