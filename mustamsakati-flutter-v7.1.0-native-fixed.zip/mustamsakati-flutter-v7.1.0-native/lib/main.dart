import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'exporters.dart';
import 'layouts.dart';
import 'perspective.dart';
import 'scan_filters.dart';
import 'camera_capture.dart';
import 'card_geometry.dart';

void main() => runApp(const MustamsakatiApp());

const _navy = Color(0xFF193B68);
const _blue = Color(0xFF4874EB);
const _pageBg = Color(0xFFF6F8FC);
const _types = <(String, IconData, String, Color, Color)>[
  ('البطاقة الوطنية', Icons.badge_outlined, 'الوجه الأمامي والخلفي', Color(0xFF5A79E8), Color(0xFFEDEEFF)),
  ('إجازة السوق', Icons.directions_car_outlined, 'رخصة القيادة', Color(0xFF15A98C), Color(0xFFE4F8F3)),
  ('بطاقة السكن', Icons.home_outlined, 'بيانات السكن', Color(0xFFEF913E), Color(0xFFFFF1E5)),
  ('جواز السفر', Icons.book_outlined, 'صفحة البيانات', Color(0xFF448FF0), Color(0xFFE7F3FF)),
  ('مستمسك آخر', Icons.post_add_outlined, 'أي وثيقة إضافية', Color(0xFF9675CE), Color(0xFFF0EAFC)),
];

const _accentPalette = <(String, Color)>[
  ('أزرق', Color(0xFF4874EB)),
  ('تركوازي', Color(0xFF138CA5)),
  ('أخضر', Color(0xFF239C78)),
  ('نعناعي', Color(0xFF27A9A1)),
  ('بنفسجي', Color(0xFF8061CF)),
  ('ليلكي', Color(0xFF9B70C6)),
  ('وردي', Color(0xFFCA688D)),
  ('مرجاني', Color(0xFFE37D67)),
  ('برتقالي', Color(0xFFE28B46)),
  ('ذهبي', Color(0xFFB99441)),
  ('كحلي', Color(0xFF305A88)),
  ('رمادي أزرق', Color(0xFF6E859E)),
];

const _captureModes = <(String, String, IconData, Color, Color, LayoutStyle, String)>[
  ('البطاقات', 'وجه أمامي وخلفي', Icons.badge_outlined,
    Color(0xFF4771C9), Color(0xFFE5EEFF), LayoutStyle.sideTop, 'البطاقة الوطنية'),
  ('المستندات', 'أوراق A4 وA5', Icons.description_outlined,
    Color(0xFF168A71), Color(0xFFE1F6ED), LayoutStyle.single, 'مستمسك آخر'),
  ('الجوازات', 'صفحة بيانات الجواز', Icons.menu_book_outlined,
    Color(0xFFBA8031), Color(0xFFFFF0DF), LayoutStyle.single, 'جواز السفر'),
  ('سكنر متعدد', 'صور متتابعة في ملف', Icons.auto_awesome_motion,
    Color(0xFF7960B1), Color(0xFFEFE9FF), LayoutStyle.verticalCenter, 'مستمسك آخر'),
  ('إيصالات', 'أوراق صغيرة وطويلة', Icons.receipt_long_outlined,
    Color(0xFFC87462), Color(0xFFFFEDE8), LayoutStyle.single, 'مستمسك آخر'),
  ('بطاقات صغيرة', 'مستمسكات متفرقة', Icons.dashboard_customize_outlined,
    Color(0xFF4C83B3), Color(0xFFE7F1F8), LayoutStyle.free, 'مستمسك آخر'),
];

class MustamsakatiApp extends StatefulWidget {
  const MustamsakatiApp({super.key});

  @override
  State<MustamsakatiApp> createState() => _MustamsakatiAppState();
}

class _MustamsakatiAppState extends State<MustamsakatiApp> {
  final PrintSettings _settings = PrintSettings();

  @override
  void initState() {
    super.initState();
    _restoreTheme();
  }

  Future<void> _restoreTheme() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _settings.dark = prefs.getBool('dark') ?? false;
        _settings.accent = Color(prefs.getInt('accent') ?? 0xFF4874EB);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final seed = _settings.accent;
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: _settings.dark ? Brightness.dark : Brightness.light,
    );
    return MaterialApp(
      title: 'مستمسكاتي',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        brightness: scheme.brightness,
        scaffoldBackgroundColor: _settings.dark
            ? const Color(0xFF101A29) : _pageBg,
        dialogTheme: DialogThemeData(
          backgroundColor: _settings.dark ? const Color(0xFF1A283A) : Colors.white,
        ),
        appBarTheme: AppBarThemeData(
          backgroundColor: _settings.dark ? const Color(0xFF182638) : Colors.white,
          foregroundColor: scheme.onSurface,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          color: scheme.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size(0, 50),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
      home: ScannerHome(settings: _settings, onThemeChange: () => setState(() {})),
    );
  }
}

class ScannerHome extends StatefulWidget {
  const ScannerHome({super.key, required this.settings, required this.onThemeChange});
  final PrintSettings settings;
  final VoidCallback onThemeChange;

  @override
  State<ScannerHome> createState() => _ScannerHomeState();
}

class _ScannerHomeState extends State<ScannerHome> {
  final ImagePicker _picker = ImagePicker();
  final List<ScanDocument> _documents = [];
  final Map<int, Offset> _freePositions = {};
  final TextEditingController _filename = TextEditingController(text: 'مستمسكاتي');
  int _navigation = 0;
  int _stage = 0; // 0 home, 1 scanning, 2 layout
  int _currentDoc = 0;
  int _visiblePage = 0;
  bool _busy = false;
  int _captureQuality = 86;
  String _captureMode = 'البطاقات';
  String? _processingPhoto;

  Color get _accent => widget.settings.accent;
  bool get _dark => widget.settings.dark;
  Color get _ink => Theme.of(context).colorScheme.onSurface;
  Color get _muted => Theme.of(context).colorScheme.onSurfaceVariant;
  Color _tileColor(Color color, Color light) => _dark
      ? Color.alphaBlend(color.withValues(alpha: .19),
          Theme.of(context).colorScheme.surface)
      : light;
  List<File> _saved = [];

  @override
  void initState() {
    super.initState();
    _loadSaved();
    _loadPreferences();
  }

  @override
  void dispose() {
    _filename.dispose();
    super.dispose();
  }

  Future<Directory> _outputDirectory() async {
    final directory = Directory('${(await getApplicationDocumentsDirectory()).path}/mustamsakati');
    if (!await directory.exists()) {
      await directory.create(recursive: true);
    }
    return directory;
  }

  Future<void> _loadSaved() async {
    final directory = await _outputDirectory();
    final files = directory.listSync().whereType<File>().where((f) =>
        f.path.endsWith('.pdf') || f.path.endsWith('.docx')).toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    if (mounted) {
      setState(() => _saved = files);
    }
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) {
      return;
    }
    setState(() => _captureQuality = prefs.getInt('capture_quality') ?? 86);
  }

  Future<void> _selectType(String label) async {
    setState(() {
      if (_stage == 0) {
        _documents.clear();
        _freePositions.clear();
      }
      _documents.add(ScanDocument(label));
      _captureMode = 'البطاقات';
      _currentDoc = _documents.length - 1;
      _stage = 1;
      _navigation = 0;
    });
  }

  Future<void> _startCaptureMode(
      (String, String, IconData, Color, Color, LayoutStyle, String) mode) async {
    setState(() {
      _captureMode = mode.$1;
      widget.settings.style = mode.$6;
      _documents.clear();
      _freePositions.clear();
      _documents.add(ScanDocument(mode.$7));
      _currentDoc = 0;
      _stage = 1;
      _navigation = 0;
      _visiblePage = 0;
    });
  }

  Future<void> _chooseKind() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('اختر نوع المستمسك'),
        contentPadding: const EdgeInsets.symmetric(vertical: 10),
        content: SizedBox(
          width: 340,
          child: ListView(shrinkWrap: true, children: [
            for (final entry in _types)
              ListTile(
                leading: Icon(entry.$2, color: entry.$4),
                title: Text(entry.$1),
                onTap: () {
                  Navigator.pop(dialogContext);
                  _selectType(entry.$1);
                },
              ),
          ]),
        ),
      ),
    );
  }

  Future<PhotoData> _photo(Uint8List bytes) async {
    // Decode only a screen-sized frame here; keep the original bytes untouched.
    // Full-resolution processing is deferred to scanner/editor/export actions.
    final codec = await ui.instantiateImageCodec(
      bytes, targetWidth: 1200, allowUpscaling: false);
    final frame = await codec.getNextFrame();
    final result = PhotoData(bytes, frame.image.width, frame.image.height);
    frame.image.dispose();
    codec.dispose();
    return result;
  }

  /// Capture once and display immediately. Choosing scanner is optional and
  /// uses a background isolate; the original JPEG/PNG remains recoverable.
  Future<void> _getPicture(bool back, ImageSource source) async {
    final target = _documents.isEmpty ? null : _documents[_currentDoc];
    if (target == null) {
      return;
    }
    try {
      final Uint8List bytes;
      if (source == ImageSource.camera) {
        final captured = await Navigator.push<Uint8List>(context,
          MaterialPageRoute(builder: (_) => CardCameraScreen(
            card: target.usesNaturalCardSize,
            documentName: target.title,
          )),
        );
        if (captured == null) {
          return;
        }
        bytes = captured;
      } else {
        final file = await _picker.pickImage(
          source: source,
          maxWidth: 2400, maxHeight: 2400,
          imageQuality: _captureQuality,
          requestFullMetadata: false,
        );
        if (file == null) {
          return;
        }
        bytes = await file.readAsBytes();
      }
      final photo = await _photo(bytes);
      if (!mounted || !_documents.contains(target)) {
        return;
      }
      setState(() {
        if (back) {
          target.backOriginal = photo;
          target.back = photo;
          target.backAppearance = ScanAppearance.original;
        } else {
          target.frontOriginal = photo;
          target.front = photo;
          target.frontAppearance = ScanAppearance.original;
        }
      });
      if (!mounted) {
        return;
      }
      // The image is already on-screen before this small choice dialog.
      await _askPhotoAppearance(target, back);
    } catch (error) {
      if (mounted) {
        _message('تعذّر فتح الصورة: $error');
      }
    }
  }

  Future<void> _askPhotoAppearance(ScanDocument doc, bool back) async {
    final selected = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('كيف تريد الاحتفاظ بالصورة؟'),
        content: SizedBox(width: 345, child: Column(
          mainAxisSize: MainAxisSize.min, children: [
          const Text('اختر الصورة الأصلية أو أحد فلاتر السكنر. يمكنك الرجوع للأصل لاحقاً.',
            style: TextStyle(fontSize: 12, color: Color(0xFF7C899A))),
          const SizedBox(height: 14),
          _appearanceChoiceCard(
            icon: Icons.photo_outlined, title: 'الصورة الأصلية',
            subtitle: 'احتفظ بتفاصيل المستمسك والألوان دون تغيير',
            tint: const Color(0xFFE8F0FF),
            onTap: () => Navigator.pop(ctx, false)),
          const SizedBox(height: 10),
          _appearanceChoiceCard(
            icon: Icons.document_scanner_outlined, title: 'عمل سكنر للصورة',
            subtitle: 'اختر من 9 تحسينات بعد الالتقاط',
            tint: const Color(0xFFE3F6EE),
            onTap: () => Navigator.pop(ctx, true)),
        ])),
        actions: [TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('لاحقاً'))],
      ),
    );
    if (!mounted || !_documents.contains(doc)) {
      return;
    }
    if (selected == true) {
      final style = await _chooseScannerPreset(back ? doc.backOriginal : doc.frontOriginal);
      if (style != null && mounted) {
        await _setPhotoAppearance(doc, back, style);
      }
    } else if (selected == false) {
      await _setPhotoAppearance(doc, back, ScanAppearance.original);
    }
  }

  Future<ScanAppearance?> _chooseScannerPreset(PhotoData? original) async {
    if (original == null) {
      return null;
    }
    return showDialog<ScanAppearance>(context: context, builder: (ctx) {
      var chosen = ScanAppearance.smart;
      return StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
        title: const Text('اختر وضع السكنر'),
        contentPadding: const EdgeInsets.fromLTRB(12, 14, 12, 4),
        content: SizedBox(width: 365, child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(height: 144, width: double.infinity,
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHigh,
                borderRadius: BorderRadius.circular(14)),
              child: ClipRRect(borderRadius: BorderRadius.circular(14),
                child: ColorFiltered(
                  colorFilter: _scanPreviewFilter(chosen),
                  child: Image.memory(original.bytes, fit: BoxFit.contain,
                    filterQuality: FilterQuality.low)))),
            const SizedBox(height: 7),
            Text(chosen.description, style: const TextStyle(fontSize: 11)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              itemCount: ScanAppearance.values.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, mainAxisSpacing: 7,
                crossAxisSpacing: 7, childAspectRatio: 1.36),
              itemBuilder: (_, i) {
                final style = ScanAppearance.values[i];
                final picked = style == chosen;
                return InkWell(
                  onTap: () => setDialog(() => chosen = style),
                  borderRadius: BorderRadius.circular(12),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: picked ? _tileColor(const Color(0xFF148A77),
                          const Color(0xFFE2F3EF))
                          : Theme.of(context).colorScheme.surfaceContainerLow,
                      border: Border.all(color: picked ? const Color(0xFF148A77)
                        : Theme.of(context).colorScheme.outlineVariant, width: picked ? 2 : 1)),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(style.icon, size: 23,
                        color: picked ? const Color(0xFF138870) : const Color(0xFF7187A3)),
                      const SizedBox(height: 4),
                      Text(style.label, style: const TextStyle(fontSize: 10,
                        fontWeight: FontWeight.w700), textAlign: TextAlign.center),
                    ]),
                  ),
                );
              },
            ),
            const SizedBox(height: 7),
            const Text('الصورة الأصلية تبقى محفوظة ويمكن استعادتها.',
              style: TextStyle(fontSize: 10, color: Color(0xFF2E977E))),
          ]))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, chosen),
            child: const Text('تطبيق السكنر')),
        ],
      ));
    });
  }

  ColorFilter _scanPreviewFilter(ScanAppearance preset) {
    if (preset == ScanAppearance.original) {
      return const ColorFilter.mode(Colors.transparent, BlendMode.dst);
    }
    if (preset == ScanAppearance.gray || preset == ScanAppearance.blackWhite ||
        preset == ScanAppearance.whitePaper) {
      const r = .299, g = .587, b = .114;
      return ColorFilter.matrix([
        r, g, b, 0, 0,
        r, g, b, 0, 0,
        r, g, b, 0, 0,
        0, 0, 0, 1, 0,
      ]);
    }
    final brightness = switch (preset) {
      ScanAppearance.smart => 9.0,
      ScanAppearance.color => 10.0,
      ScanAppearance.soft => 5.0,
      _ => 8.0,
    };
    final contrast = switch (preset) {
      ScanAppearance.highContrast => 1.55,
      ScanAppearance.smart => 1.18,
      ScanAppearance.color => 1.16,
      _ => 1.08,
    };
    final offset = 128 * (1 - contrast) + brightness;
    return ColorFilter.matrix([
      contrast, 0, 0, 0, offset + (preset == ScanAppearance.warm ? 10 : 0),
      0, contrast, 0, 0, offset,
      0, 0, contrast, 0, offset + (preset == ScanAppearance.cool ? 10 : 0),
      0, 0, 0, 1, 0,
    ]);
  }

  Widget _appearanceChoiceCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color tint,
    required VoidCallback onTap,
  }) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(16),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: _tileColor(_accent, tint),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(children: [
        Icon(icon, size: 27, color: _ink),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: _ink, fontSize: 14,
            fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text(subtitle, style: TextStyle(color: _muted,
            fontSize: 10, height: 1.5)),
        ])),
        Icon(Icons.chevron_left_rounded, color: _ink),
      ]),
    ),
  );

  Future<void> _setPhotoAppearance(
      ScanDocument doc, bool back, ScanAppearance appearance) async {
    final original = back ? doc.backOriginal : doc.frontOriginal;
    if (original == null) {
      return;
    }
    if (appearance == ScanAppearance.original) {
      setState(() {
        if (back) {
          doc.back = original;
          doc.backAppearance = appearance;
        } else {
          doc.front = original;
          doc.frontAppearance = appearance;
        }
      });
      return;
    }
    if (_processingPhoto != null) {
      return;
    }
    final token = '${_documents.indexOf(doc)}_${back ? 'back' : 'front'}';
    setState(() => _processingPhoto = token);
    try {
      final bytes = await scanImageAsync(original.bytes, appearance);
      final decoded = await _photo(bytes);
      // A scanner filter changes pixels, never the photograph's print geometry.
      // Keep the original preview aspect, avoiding a sudden resize in layouts.
      final processed = PhotoData(bytes, original.width, original.height);
      if (decoded.width <= 0 || decoded.height <= 0) {
        throw const FormatException('تعذر معالجة الصورة');
      }
      if (!mounted || !_documents.contains(doc) ||
          !identical(back ? doc.backOriginal : doc.frontOriginal, original)) {
        return;
      }
      setState(() {
        if (back) {
          doc.back = processed;
          doc.backAppearance = appearance;
        } else {
          doc.front = processed;
          doc.frontAppearance = appearance;
        }
      });
    } catch (error) {
      if (mounted) {
        _message('تعذّر تطبيق السكنر: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _processingPhoto = null);
      }
    }
  }

  Future<void> _getExtraPicture(ScanDocument doc, ExtraScanPage extra,
      ImageSource source) async {
    try {
      final Uint8List bytes;
      if (source == ImageSource.camera) {
        final captured = await Navigator.push<Uint8List>(context,
          MaterialPageRoute(builder: (_) => CardCameraScreen(
            card: doc.usesNaturalCardSize, documentName: doc.title,
          )),
        );
        if (captured == null) {
          return;
        }
        bytes = captured;
      } else {
        final file = await _picker.pickImage(source: source,
          maxWidth: 2400, maxHeight: 2400,
          imageQuality: _captureQuality, requestFullMetadata: false);
        if (file == null) {
          return;
        }
        bytes = await file.readAsBytes();
      }
      final photo = await _photo(bytes);
      if (!mounted || !_documents.contains(doc) || !doc.extras.contains(extra)) {
        return;
      }
      setState(() {
        extra.original = photo;
        extra.image = photo;
        extra.appearance = ScanAppearance.original;
      });
      if (!mounted) {
        return;
      }
      final useScanner = await showDialog<bool>(context: context, builder: (ctx) =>
        AlertDialog(title: const Text('الصورة الأصلية أم السكنر؟'),
          content: const Text('يمكنك تحسين الصفحة أو الاحتفاظ بالصورة الأصلية.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('الأصلية')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true),
              child: const Text('السكنر')),
          ]));
      if (useScanner == true && mounted) {
        final appearance = await _chooseScannerPreset(extra.original);
        if (appearance != null && mounted) {
          await _setExtraAppearance(doc, extra, appearance);
        }
      }
    } catch (error) {
      if (mounted) {
        _message('تعذّر إضافة الصفحة: $error');
      }
    }
  }

  Future<void> _setExtraAppearance(ScanDocument doc,
      ExtraScanPage extra, ScanAppearance appearance) async {
    final source = extra.original;
    if (source == null) {
      return;
    }
    if (appearance == ScanAppearance.original) {
      setState(() { extra.image = source; extra.appearance = appearance; });
      return;
    }
    if (_processingPhoto != null) {
      return;
    }
    setState(() => _processingPhoto = 'extra');
    try {
      final data = await scanImageAsync(source.bytes, appearance);
      final decoded = await _photo(data);
      final image = PhotoData(data, source.width, source.height);
      if (decoded.width <= 0 || decoded.height <= 0) {
        throw const FormatException('تعذر معالجة الصفحة');
      }
      if (!mounted || !doc.extras.contains(extra) ||
          !identical(extra.original, source)) {
        return;
      }
      setState(() { extra.image = image; extra.appearance = appearance; });
    } catch (error) {
      if (mounted) {
        _message('تعذّرت معالجة الصورة: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _processingPhoto = null);
      }
    }
  }

  Future<void> _editExtra(ScanDocument doc, ExtraScanPage extra) async {
    if (extra.image == null) {
      return;
    }
    final image = await Navigator.push<PhotoData>(context,
      MaterialPageRoute(builder: (_) => CornerEditor(photo: extra.image!)));
    if (image != null && mounted && doc.extras.contains(extra)) {
      setState(() {
        // The corrected quadrilateral is the new scanner source; otherwise
        // choosing a filter would restore the full-size pre-crop photograph.
        extra.image = image;
        extra.original = image;
        extra.appearance = ScanAppearance.original;
      });
    }
  }

  Future<void> _demo() async {
    try {
      final front = await rootBundle.load('assets/demo/sample_front.jpg');
      final back = await rootBundle.load('assets/demo/sample_back.jpg');
      final photoA = await _photo(front.buffer.asUint8List());
      final photoB = await _photo(back.buffer.asUint8List());
      if (!mounted) {
        return;
      }
      setState(() {
        _documents.clear();
        _freePositions.clear();
        _documents.add(ScanDocument('بطاقات تجريبية')
          ..front = photoA
          ..frontOriginal = photoA
          ..back = photoB
          ..backOriginal = photoB);
        _currentDoc = _documents.length - 1;
        _stage = 2;
        _visiblePage = 0;
        _navigation = 0;
      });
    } catch (e) {
      if (mounted) {
        _message('تعذرت تجربة الصور: $e');
      }
    }
  }

  Future<void> _editImage(bool back) async {
    final source = back ? _documents[_currentDoc].back : _documents[_currentDoc].front;
    if (source == null) {
      return;
    }
    final photo = await Navigator.push<PhotoData>(
      context,
      MaterialPageRoute(builder: (_) => CornerEditor(photo: source)),
    );
    if (photo == null || !mounted) {
      return;
    }
    setState(() {
      if (back) {
        _documents[_currentDoc].back = photo;
        _documents[_currentDoc].backOriginal = photo;
        _documents[_currentDoc].backAppearance = ScanAppearance.original;
      } else {
        _documents[_currentDoc].front = photo;
        _documents[_currentDoc].frontOriginal = photo;
        _documents[_currentDoc].frontAppearance = ScanAppearance.original;
      }
    });
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  List<LayoutSheet> get _sheets => [
    for (var i = 0; i < _documents.length; ++i)
      ...layoutDocument(_documents[i], widget.settings,
          freeOffsets: i == _currentDoc ? _freePositions : const {}),
  ];

  Future<void> _export(bool word) async {
    final sheets = _sheets;
    if (sheets.isEmpty) {
      _message('أضف صورة واحدة على الأقل أولاً');
      return;
    }
    setState(() => _busy = true);
    try {
      final data = word
          ? Exporter.makeDocx(sheets, widget.settings)
          : await Exporter.makePdf(sheets, widget.settings);
      final filename = _filename.text.trim().isEmpty
          ? 'مستمسكاتي'
          : _filename.text.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
      final extension = word ? 'docx' : 'pdf';
      final directory = await _outputDirectory();
      final saved = File('${directory.path}/${filename}_${DateTime.now().millisecondsSinceEpoch}.$extension');
      await saved.writeAsBytes(data, flush: true);
      await _loadSaved();
      if (!mounted) {
        return;
      }
      _message('تم حفظ ${word ? 'Word' : 'PDF'} داخل ملفات التطبيق');
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('تم إنشاء الملف بنجاح'),
          content: Text(saved.path.split('/').last),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
            TextButton(
              onPressed: () async {
                Navigator.pop(ctx);
                try {
                  await FilePicker.platform.saveFile(
                    dialogTitle: 'اختر مكان الحفظ',
                    fileName: '$filename.$extension',
                    bytes: data,
                  );
                } catch (_) {
                  if (mounted) {
                    _message('يمكن مشاركة الملف واختيار «حفظ في الملفات»');
                  }
                }
              },
              child: const Text('حفظ في مجلد'),
            ),
            FilledButton(
              onPressed: () async {
                Navigator.pop(ctx);
                await _shareFile(saved);
              },
              child: const Text('مشاركة'),
            ),
          ],
        ),
      );
    } catch (error) {
      if (mounted) {
        _message('فشل إنشاء المستند: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _shareFile(File file) async {
    try {
      await SharePlus.instance.share(ShareParams(files: [XFile(file.path)]));
    } catch (error) {
      if (mounted) {
        _message('تعذرت المشاركة: $error');
      }
    }
  }

  Future<void> _printPdf() async {
    try {
      if (_sheets.isEmpty) {
        return;
      }
      await Printing.layoutPdf(onLayout: (_) => Exporter.makePdf(_sheets, widget.settings));
    } catch (error) {
      if (mounted) {
        _message('تعذرت الطباعة: $error');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 16,
        toolbarHeight: 62,
        backgroundColor: scheme.surface,
        title: Row(children: [
          Image.asset('assets/icons/ic_launcher_192.png', width: 36, height: 36),
          const SizedBox(width: 9),
          const Text('مستمسكاتي', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        ]),
        actions: [
          if (_stage == 0 && _navigation == 0)
            Padding(padding: const EdgeInsets.only(left: 7), child: Chip(
              label: const Text('دون إنترنت', style: TextStyle(fontSize: 10,
                color: Color(0xFF169877))),
              avatar: const Icon(Icons.verified_user_outlined,
                color: Color(0xFF169877), size: 15),
              backgroundColor: _tileColor(const Color(0xFF169877),
                  const Color(0xFFE8F8F2)),
              side: BorderSide.none, visualDensity: VisualDensity.compact,
            )),
          if (_stage != 0 && _navigation == 0)
            IconButton(
              tooltip: 'العودة',
              onPressed: () => setState(() => _stage = _stage == 2 ? 1 : 0),
              icon: const Icon(Icons.arrow_back_rounded),
            )
          else
            IconButton(
              tooltip: 'تغيير المظهر',
              onPressed: () async {
                widget.settings.dark = !widget.settings.dark;
                widget.onThemeChange();
                final prefs = await SharedPreferences.getInstance();
                await prefs.setBool('dark', widget.settings.dark);
              },
              icon: Icon(widget.settings.dark ? Icons.dark_mode_outlined : Icons.light_mode_outlined),
            ),
        ],
      ),
      body: Stack(children: [
        SafeArea(
          child: _navigation == 1
              ? _filesPage()
              : _navigation == 2
                  ? _settingsPage()
                  : _stage == 0
                      ? _homePage()
                      : _stage == 1
                          ? _scanPage()
                          : _layoutPage(),
        ),
        if (_busy)
          ColoredBox(
            color: Colors.black45,
            child: const Center(child: Card(child: Padding(
              padding: EdgeInsets.all(26),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                CircularProgressIndicator(),
                SizedBox(height: 12),
                Text('جارٍ معالجة الملف...'),
              ]),
            ))),
          ),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _navigation,
        onDestinationSelected: (index) => setState(() {
          _navigation = index;
          if (index == 0) {
            _stage = 0;
          }
        }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.folder_outlined), selectedIcon: Icon(Icons.folder), label: 'ملفاتي'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
    );
  }

  Widget _homePage() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 21, 16, 28),
    children: [
      _heroCard(),
      const SizedBox(height: 28),
      _heading('أنواع المستمسكات', 'اختر نوع الوثيقة للبدء'),
      const SizedBox(height: 13),
      GridView.builder(
        key: const ValueKey('document_types'),
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _types.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.45,
        ),
        itemBuilder: (_, i) {
          final type = _types[i];
          return InkWell(
            onTap: () => _selectType(type.$1),
            borderRadius: BorderRadius.circular(19),
            child: Container(
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(19),
                border: Border.all(color: type.$4.withValues(alpha: .10)),
                color: _tileColor(type.$4, type.$5),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  height: 41, width: 41,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(13),
                      color: _dark ? Theme.of(context).colorScheme.surfaceContainerHigh : Colors.white),
                  child: Icon(type.$2, color: type.$4, size: 23),
                ),
                const Spacer(),
                Text(type.$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 3),
                Text(type.$3, style: TextStyle(fontSize: 10, color: _muted),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              ]),
            ),
          );
        },
      ),
      const SizedBox(height: 23),
      _heading('طرق التصوير', 'اختر طريقة التقاط الصور ثم عالجها بالسكنر'),
      const SizedBox(height: 11),
      GridView.builder(
        key: const ValueKey('capture_modes'),
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _captureModes.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10,
          childAspectRatio: 2.08),
        itemBuilder: (_, i) {
          final m = _captureModes[i];
          return InkWell(
            onTap: () => _startCaptureMode(m),
            borderRadius: BorderRadius.circular(17),
            child: Container(
              decoration: BoxDecoration(color: _tileColor(m.$4, m.$5),
                borderRadius: BorderRadius.circular(17)),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
              child: Row(children: [
                Container(width: 38, height: 38,
                  decoration: BoxDecoration(color: _dark
                      ? Theme.of(context).colorScheme.surfaceContainerHigh
                      : Colors.white,
                    borderRadius: BorderRadius.circular(12)),
                  child: Icon(m.$3, size: 20, color: m.$4)),
                const SizedBox(width: 8),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(m.$1, style: const TextStyle(fontWeight: FontWeight.w900,
                    fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(m.$2, style: TextStyle(fontSize: 9,
                    color: _muted), maxLines: 2,
                    overflow: TextOverflow.ellipsis),
                ])),
              ]),
            ),
          );
        },
      ),
      const SizedBox(height: 17),
      Container(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(color: _tileColor(const Color(0xFF168A71),
            const Color(0xFFF0FAF9)), borderRadius: BorderRadius.circular(21)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Icon(Icons.image_outlined, color: Color(0xFF247B8F)), const SizedBox(width: 8),
            Text('هل لديك صور جاهزة؟', style: TextStyle(color: _ink, fontWeight: FontWeight.w900, fontSize: 14))]),
          const SizedBox(height: 9),
          const Text('استورد الصور من الهاتف، وعدّل الزوايا، ثم اختر طريقة توزيعها على الورقة.',
            style: TextStyle(fontSize: 11, color: Color(0xFF8D9BB2), height: 1.9)),
          const SizedBox(height: 9),
          OutlinedButton.icon(onPressed: _chooseKind,
            icon: const Icon(Icons.add, size: 18), label: const Text('إنشاء مستند من الصور')),
        ]),
      ),
      const SizedBox(height: 16),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('ثلاث خطوات'),
          const SizedBox(height: 16),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            _stepChip('١', 'التصوير'),
            const Icon(Icons.remove, color: Color(0xFFB5C8DC), size: 16),
            _stepChip('٢', 'المعاينة'),
            const Icon(Icons.remove, color: Color(0xFFB5C8DC), size: 16),
            _stepChip('٣', 'التصدير'),
          ]),
        ],
      ))),
      if (_saved.isNotEmpty) ...[
        const SizedBox(height: 23),
        _heading('آخر الملفات', 'الملفات التي صدّرتها مؤخراً'),
        for (final f in _saved.take(3)) ListTile(
          leading: Icon(f.path.endsWith('.pdf') ? Icons.picture_as_pdf_outlined : Icons.description_outlined, color: _accent),
          title: Text(f.path.split('/').last, maxLines: 1, overflow: TextOverflow.ellipsis),
          trailing: IconButton(onPressed: () => _shareFile(f), icon: const Icon(Icons.share_outlined)),
        ),
      ],
    ],
  );

  Widget _stepChip(String count, String label) => Row(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 27, height: 27, alignment: Alignment.center,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(9), color: const Color(0xFFE8EFFC)),
      child: Text(count, style: TextStyle(color: _accent, fontWeight: FontWeight.w900))),
    const SizedBox(width: 6),
    Text(label, style: const TextStyle(fontSize: 10, color: Color(0xFF8798AF))),
  ]);

  Widget _heading(String title, String subtitle) => Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: _ink)),
      const SizedBox(height: 7),
      Text(subtitle, style: const TextStyle(fontSize: 11, color: Color(0xFF93A2B8))),
    ],
  );

  Widget _heroCard() => Container(
    height: 189,
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(23),
      gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft,
        colors: [Color.lerp(_navy, _accent, .18)!,
          Color.lerp(_navy, _accent, .65)!, _accent]),
      boxShadow: const [BoxShadow(color: Color(0x1A1B3C68), blurRadius: 25, offset: Offset(0, 9))],
    ),
    child: Stack(children: [
      Positioned(left: -60, top: -41,
        child: Transform.rotate(angle: -.22,
          child: Container(height: 150, width: 200,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .13), borderRadius: BorderRadius.circular(17)),
            child: const Center(child: Icon(Icons.badge_outlined, size: 95, color: Color(0x338ECDE5))))),
      ),
      Padding(padding: const EdgeInsets.fromLTRB(17, 14, 17, 14), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), color: Colors.white.withValues(alpha: .10)),
            child: const Text('♧  آمن ويعمل دون إنترنت', style: TextStyle(fontSize: 9, color: Color(0xFFD6E5F5)))),
          const SizedBox(height: 8),
          const Text('صوّر مستمسكك\nوجهّزه للطباعة.',
            style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, height: 1.32)),
          const Text('تصوير، تصحيح الزوايا وتنسيق المستند في خطوات بسيطة.',
            style: TextStyle(color: Color(0xFFCDDCED), fontSize: 9, height: 1.6), maxLines: 2),
          const Spacer(),
          Row(children: [
            Expanded(child: FilledButton.icon(
              onPressed: _chooseKind,
              style: FilledButton.styleFrom(backgroundColor: Colors.white,
                foregroundColor: const Color(0xFF204A80),
                minimumSize: const Size(0, 38), visualDensity: VisualDensity.compact),
              icon: const Icon(Icons.camera_alt_outlined, size: 16),
              label: const Text('تصوير مستمسك جديد', style: TextStyle(fontSize: 11)),
            )),
            const SizedBox(width: 7),
            TextButton(onPressed: _demo,
              style: TextButton.styleFrom(foregroundColor: Colors.white, padding: const EdgeInsets.all(4)),
              child: const Text('تجربة سريعة', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800))),
          ]),
        ],
      )),
    ]),
  );

  Widget _sectionTitle(String title) => Text(title,
    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900));

  Widget _scanPage() {
    if (_documents.isEmpty) {
      return _homePage();
    }
    final doc = _documents[_currentDoc];
    return ListView(padding: const EdgeInsets.all(16), children: [
      _progress(1),
      const SizedBox(height: 8),
      Text('وضع التصوير: $_captureMode', style: TextStyle(color: _accent,
        fontSize: 11, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: Text(doc.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        TextButton.icon(onPressed: _chooseKind, icon: const Icon(Icons.add), label: const Text('مستمسك إضافي')),
      ]),
      const SizedBox(height: 13),
      _imageSlot(doc.title == 'جواز السفر' ? 'صفحة البيانات' : 'الوجه الأمامي', doc.front, false),
      const SizedBox(height: 14),
      _imageSlot(doc.title == 'جواز السفر' ? 'صفحة ثانية (اختياري)' : 'الوجه الخلفي (اختياري)', doc.back, true),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: Text('صفحات إضافية', style: const TextStyle(
          fontWeight: FontWeight.w900, fontSize: 16))),
        OutlinedButton.icon(
          onPressed: () => setState(() => doc.extras.add(ExtraScanPage())),
          icon: const Icon(Icons.add_photo_alternate_outlined, size: 18),
          label: const Text('إضافة صفحة')),
      ]),
      if (doc.front != null || doc.back != null)
        Padding(padding: const EdgeInsets.only(bottom: 12),
          child: Row(children: [
            OutlinedButton.icon(
              onPressed: () => setState(doc.swapSides),
              icon: const Icon(Icons.swap_horiz_rounded),
              label: const Text('تبديل الأمامي والخلفي')),
            const SizedBox(width: 8),
            Text('${doc.photos.length} صورة',
              style: const TextStyle(fontSize: 11, color: Color(0xFF8395A9))),
          ])),
      for (var i = 0; i < doc.extras.length; ++i)
        _extraPageCard(doc, doc.extras[i], i),
      const SizedBox(height: 10),
      if (_documents.length > 1)
        Card(child: Padding(
          padding: const EdgeInsets.all(12),
          child: Wrap(spacing: 8, runSpacing: 4, children: [
            for (var i = 0; i < _documents.length; ++i)
              InputChip(label: Text(_documents[i].title), selected: i == _currentDoc,
                onPressed: () => setState(() => _currentDoc = i),
                onDeleted: _documents.length > 1 ? () => setState(() {
                  _documents.removeAt(i);
                  _currentDoc = 0;
                }) : null),
          ]),
        )),
      const SizedBox(height: 14),
      FilledButton.icon(
        onPressed: _documents.any((d) => d.photos.isNotEmpty) ? () => setState(() {
          _stage = 2;
          _visiblePage = 0;
        }) : null,
        icon: const Icon(Icons.auto_awesome_motion_outlined),
        label: const Text('التالي: ترتيب الصور والمعاينة'),
      ),
      const SizedBox(height: 20),
    ]);
  }

  Widget _extraPageCard(ScanDocument doc, ExtraScanPage page, int index) {
    return Card(child: Padding(padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text('صفحة إضافية ${index + 1}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
          const Spacer(),
          IconButton(tooltip: 'تقديم الصفحة',
            onPressed: index == 0 ? null : () => setState(
              () => doc.moveExtra(index, index - 1)),
            icon: const Icon(Icons.arrow_upward_rounded, size: 19)),
          IconButton(tooltip: 'تأخير الصفحة',
            onPressed: index + 1 >= doc.extras.length ? null : () => setState(
              () => doc.moveExtra(index, index + 1)),
            icon: const Icon(Icons.arrow_downward_rounded, size: 19)),
          IconButton(tooltip: 'حذف الصفحة',
            onPressed: () => setState(() => doc.extras.remove(page)),
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 19)),
        ]),
        if (page.image != null) ...[
          ClipRRect(borderRadius: BorderRadius.circular(12),
            child: Container(height: 130, width: double.infinity,
              color: Theme.of(context).colorScheme.surfaceContainerHigh,
              child: Image.memory(page.image!.bytes, fit: BoxFit.contain,
                gaplessPlayback: true))),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () async {
                final style = await _chooseScannerPreset(page.original);
                if (style != null) {
                  await _setExtraAppearance(doc, page, style);
                }
              }, icon: const Icon(Icons.tune, size: 18),
              label: Text(page.appearance.label))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(
              onPressed: () => _editExtra(doc, page),
              icon: const Icon(Icons.crop, size: 18),
              label: const Text('الزوايا'))),
          ]),
          const SizedBox(height: 8),
        ],
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            onPressed: () => _getExtraPicture(doc, page, ImageSource.camera),
            icon: const Icon(Icons.camera_alt_outlined, size: 18),
            label: const Text('تصوير'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(
            onPressed: () => _getExtraPicture(doc, page, ImageSource.gallery),
            icon: const Icon(Icons.photo_library_outlined, size: 18),
            label: const Text('المعرض'))),
        ]),
      ])));
  }

  Widget _imageSlot(String heading, PhotoData? image, bool back) {
    final doc = _documents[_currentDoc];
    final appearance = back ? doc.backAppearance : doc.frontAppearance;
    final photoKey = '${_documents.indexOf(doc)}_${back ? 'back' : 'front'}';
    final processing = _processingPhoto == photoKey;
    return Card(child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(heading, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 12),
        if (image != null) ...[
          Container(
            height: 158,
            width: double.infinity,
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHigh,
              borderRadius: BorderRadius.circular(12)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.memory(image.bytes, fit: BoxFit.contain,
                gaplessPlayback: true,
                errorBuilder: (_, error, stack) => const Center(
                  child: Text('تعذّر عرض الصورة، أعد اختيارها'))),
            ),
          ),
          const SizedBox(height: 12),
          const Text('طريقة معالجة الصورة',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
          const SizedBox(height: 7),
          Row(children: [
            Expanded(child: _photoModeCard(
              icon: Icons.photo_outlined, title: 'الأصلية',
              active: appearance == ScanAppearance.original,
              color: const Color(0xFF537AE3),
              onTap: processing ? null : () => _setPhotoAppearance(
                doc, back, ScanAppearance.original))),
            const SizedBox(width: 8),
            Expanded(child: _photoModeCard(
              icon: Icons.document_scanner_outlined,
              title: appearance == ScanAppearance.original
                ? 'اختيار السكنر' : appearance.label,
              active: appearance != ScanAppearance.original,
              color: const Color(0xFF169C80),
              onTap: processing ? null : () async {
                final selected = await _chooseScannerPreset(
                  back ? doc.backOriginal : doc.frontOriginal);
                if (selected != null) {
                  await _setPhotoAppearance(doc, back, selected);
                }
              })),
          ]),
          if (processing) const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 2)),
              SizedBox(width: 9),
              Text('جارٍ تجهيز السكنر...', style: TextStyle(fontSize: 11)),
            ]),
          ),
          const SizedBox(height: 9),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: processing ? null : () => _editImage(back),
              icon: const Icon(Icons.crop_rotate),
              label: const Text('تصحيح الزوايا'),
            )),
            const SizedBox(width: 6),
            IconButton(
              tooltip: 'حذف الصورة',
              onPressed: processing ? null : () => setState(() {
                if (back) {
                  doc.back = null;
                  doc.backOriginal = null;
                  doc.backAppearance = ScanAppearance.original;
                } else {
                  doc.front = null;
                  doc.frontOriginal = null;
                  doc.frontAppearance = ScanAppearance.original;
                }
              }),
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            ),
          ]),
        ],
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            icon: const Icon(Icons.camera_alt_outlined),
            label: Text(image == null ? 'تصوير' : 'إعادة تصوير'),
            onPressed: processing ? null : () => _getPicture(back, ImageSource.camera),
          )),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(
            icon: const Icon(Icons.photo_library_outlined),
            label: const Text('المعرض'),
            onPressed: processing ? null : () => _getPicture(back, ImageSource.gallery),
          )),
        ]),
      ]),
    ));
  }

  Widget _photoModeCard({
    required IconData icon,
    required String title,
    required bool active,
    required Color color,
    required VoidCallback? onTap,
    bool small = false,
  }) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(13),
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      constraints: BoxConstraints(minHeight: small ? 49 : 57),
      padding: EdgeInsets.symmetric(horizontal: small ? 5 : 9, vertical: 8),
      decoration: BoxDecoration(
        color: active ? color.withValues(alpha: .11) :
          Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: active ? color
            : Theme.of(context).colorScheme.outlineVariant,
          width: active ? 1.7 : 1),
      ),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: color, size: small ? 18 : 22),
        const SizedBox(height: 3),
        Text(title, textAlign: TextAlign.center,
          maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: small ? 10 : 12,
            fontWeight: active ? FontWeight.w900 : FontWeight.w600)),
      ]),
    ),
  );

  Widget _progress(int step) => Row(children: [
    for (var i = 1; i <= 3; ++i) ...[
      Expanded(child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: i <= step ? _accent : Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(['التصوير', 'التنسيق', 'التصدير'][i - 1],
          textAlign: TextAlign.center,
          style: TextStyle(color: i <= step ? Colors.white : null, fontWeight: FontWeight.w700, fontSize: 12)),
      )),
      if (i < 3) const SizedBox(width: 5),
    ],
  ]);

  Widget _layoutThumbnail(LayoutStyle style) => Center(
    child: CustomPaint(
      painter: _LayoutSchematicPainter(style),
      size: const Size(76, 90),
    ),
  );

  Widget _layoutPage() {
    final sheets = _sheets;
    if (sheets.isEmpty) {
      return Center(child: FilledButton(onPressed: () => setState(() => _stage = 1), child: const Text('أضف صوراً أولاً')));
    }
    final pageIndex = _visiblePage.clamp(0, sheets.length - 1).toInt();
    final page = widget.settings.paper;
    return ListView(padding: const EdgeInsets.all(14), children: [
      _progress(2),
      const SizedBox(height: 16),
      _sectionTitle('طريقة عرض الصور'),
      const SizedBox(height: 10),
      GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: LayoutStyle.values.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .98),
        itemBuilder: (_, i) {
          final mode = LayoutStyle.values[i];
          final active = widget.settings.style == mode;
          return InkWell(
            onTap: () => setState(() { widget.settings.style = mode; _visiblePage = 0; }),
            borderRadius: BorderRadius.circular(14),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: active ? _accent.withValues(alpha: .09) : Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: active ? _accent : Colors.transparent, width: active ? 2 : 1),
              ),
              child: Column(children: [
                Expanded(child: _layoutThumbnail(mode)),
                Text(mode.label, textAlign: TextAlign.center, maxLines: 2,
                  style: TextStyle(fontSize: 10, fontWeight: active ? FontWeight.w800 : FontWeight.w600)),
              ]),
            ),
          );
        },
      ),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: _sectionTitle('معاينة الصفحة')),
        Text('صفحة ${pageIndex + 1} من ${sheets.length}', style: const TextStyle(fontSize: 12)),
        IconButton(onPressed: pageIndex > 0 ? () => setState(() => _visiblePage--) : null,
          icon: const Icon(Icons.chevron_right_rounded)),
        IconButton(onPressed: pageIndex < sheets.length - 1 ? () => setState(() => _visiblePage++) : null,
          icon: const Icon(Icons.chevron_left_rounded)),
      ]),
      Text('التخطيط الحالي: ${widget.settings.style.label}',
        style: TextStyle(fontSize: 11, color: _accent, fontWeight: FontWeight.w800)),
      if (_documents.any((d) => d.usesNaturalCardSize))
        Padding(padding: const EdgeInsets.only(top: 5),
          child: Text('مقاس البطاقات الطبيعي: 85.6 × 53.98 ملم عند حجم 100%؛ '
              'قد يُصغَّر عند عدم اتساع الورقة.',
            style: TextStyle(fontSize: 11, color: _muted))),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHigh,
            borderRadius: BorderRadius.circular(18)),
        child: Center(child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 470, maxWidth: 375),
          child: AspectRatio(
            aspectRatio: page.width / page.height,
            child: FittedBox(
              fit: BoxFit.contain,
              child: SizedBox(
                width: page.width,
                height: page.height,
                child: ColoredBox(
                  color: Colors.white,
                  child: Stack(children: [
                    for (final item in sheets[pageIndex].placements)
                      Positioned.fromRect(
                        rect: item.rect,
                        child: GestureDetector(
                          onPanUpdate: widget.settings.style == LayoutStyle.free
                            ? (details) {
                              final rect = item.rect;
                              setState(() {
                                _freePositions[item.index] = Offset(
                                  (rect.left + details.delta.dx).clamp(
                                    widget.settings.margin,
                                    page.width - widget.settings.margin - rect.width).toDouble(),
                                  (rect.top + details.delta.dy).clamp(
                                    widget.settings.margin,
                                    page.height - widget.settings.margin - rect.height).toDouble(),
                                );
                              });
                            } : null,
                          child: Container(
                            decoration: BoxDecoration(border: Border.all(
                              color: const Color(0xFF9EADC0), width: .8)),
                            child: Stack(fit: StackFit.expand, children: [
                              Image.memory(item.photo.bytes,
                                key: ValueKey(item.photo.bytes),
                                fit: BoxFit.fill, gaplessPlayback: true,
                                filterQuality: FilterQuality.medium,
                                cacheWidth: 1100,
                                errorBuilder: (_, error, stack) => const ColoredBox(
                                  color: Color(0xFFFFE8E8), child: Center(
                                    child: Icon(Icons.broken_image_outlined,
                                      color: Colors.redAccent))),
                              ),
                              PositionedDirectional(top: 5, start: 5,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: const Color(0xCC193B68),
                                    borderRadius: BorderRadius.circular(5)),
                                  child: Text(item.index == 0 ? 'الأمامي'
                                      : item.index == 1 ? 'الخلفي'
                                      : 'صفحة ${item.index + 1}',
                                    style: const TextStyle(color: Colors.white,
                                      fontSize: 12)),
                                )),
                            ]),
                          ),
                        ),
                      ),
                    if (sheets[pageIndex].cutLine)
                      Positioned(left: widget.settings.margin,
                        top: page.height / 2,
                        width: page.width - 2 * widget.settings.margin,
                        child: const Divider(thickness: 1,
                          color: Colors.grey)),
                  ]),
                ),
              ),
            ),
          ),
        )),
      ),
      if (sheets.length > 1) ...[
        const SizedBox(height: 11),
        SizedBox(height: 56, child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: sheets.length,
          separatorBuilder: (context, index) => const SizedBox(width: 8),
          itemBuilder: (_, i) => InkWell(
            onTap: () => setState(() => _visiblePage = i),
            borderRadius: BorderRadius.circular(11),
            child: Container(
              width: 86,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: i == pageIndex ? _accent.withValues(alpha: .12)
                    : Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: i == pageIndex ? _accent
                  : const Color(0xFFD6E0E9))),
              child: Text('صفحة ${i + 1}  •  ${sheets[i].placements.length} صورة',
                textAlign: TextAlign.center, style: const TextStyle(fontSize: 10)),
            ),
          ),
        )),
      ],
      if (widget.settings.style == LayoutStyle.free)
        const Padding(padding: EdgeInsets.only(top: 8), child: Text('اسحب كل صورة إلى مكانها الجديد داخل الورقة', textAlign: TextAlign.center)),
      const SizedBox(height: 14),
      Card(child: Padding(padding: const EdgeInsets.all(13), child: Column(children: [
        Row(children: [
          Expanded(child: _paperOption()),
          const SizedBox(width: 8),
          Expanded(child: _paperDirection()),
        ]),
        _slider('هوامش الصفحة', widget.settings.margin, 18, 65, (v) => setState(() => widget.settings.margin = v)),
        _slider('المسافة بين الصورتين', widget.settings.gap, 5, 45, (v) => setState(() => widget.settings.gap = v)),
        _slider('حجم الصور', widget.settings.scale, .65, 1.2, (v) => setState(() => widget.settings.scale = v)),
        if (widget.settings.style == LayoutStyle.halves)
          SwitchListTile(title: const Text('خط القص بين النصفين'),
            value: widget.settings.showCut,
            onChanged: (value) => setState(() => widget.settings.showCut = value)),
      ]))),
      const SizedBox(height: 14),
      TextField(controller: _filename, decoration: const InputDecoration(
        border: OutlineInputBorder(), labelText: 'اسم الملف', prefixIcon: Icon(Icons.drive_file_rename_outline))),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: () => _export(false), icon: const Icon(Icons.picture_as_pdf_outlined), label: const Text('حفظ PDF'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.tonalIcon(onPressed: () => _export(true), icon: const Icon(Icons.description_outlined), label: const Text('حفظ Word'))),
      ]),
      TextButton.icon(onPressed: _printPdf, icon: const Icon(Icons.print_outlined), label: const Text('طباعة مباشرة')),
      TextButton(onPressed: () => setState(() => _stage = 1), child: const Text('العودة إلى الصور')),
      const SizedBox(height: 20),
    ]);
  }

  Widget _paperOption() => DropdownButtonFormField<bool>(
    initialValue: widget.settings.a5,
    decoration: const InputDecoration(labelText: 'حجم الورق', border: OutlineInputBorder()),
    items: const [
      DropdownMenuItem(value: false, child: Text('A4')),
      DropdownMenuItem(value: true, child: Text('A5')),
    ],
    onChanged: (v) => setState(() => widget.settings.a5 = v ?? false),
  );

  Widget _paperDirection() => DropdownButtonFormField<bool>(
    initialValue: widget.settings.landscape,
    decoration: const InputDecoration(labelText: 'اتجاه الصفحة', border: OutlineInputBorder()),
    items: const [
      DropdownMenuItem(value: false, child: Text('عمودي')),
      DropdownMenuItem(value: true, child: Text('أفقي')),
    ],
    onChanged: (v) => setState(() => widget.settings.landscape = v ?? false),
  );

  Widget _slider(String title, double value, double min, double max, ValueChanged<double> onChanged) =>
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.only(top: 12), child: Text(title,
        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
      Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged),
    ]);

  Widget _filesPage() => RefreshIndicator(
    onRefresh: _loadSaved,
    child: ListView(padding: const EdgeInsets.all(16), children: [
      _sectionTitle('الملفات المحفوظة'),
      const SizedBox(height: 10),
      if (_saved.isEmpty)
        const Padding(padding: EdgeInsets.all(40), child: Column(children: [
          Icon(Icons.folder_open_outlined, size: 62, color: Colors.blueGrey),
          SizedBox(height: 10),
          Text('لم تحفظ أي ملفات بعد'),
        ]))
      else
        for (final f in _saved)
          Card(child: ListTile(
            leading: Icon(f.path.endsWith('.pdf') ? Icons.picture_as_pdf : Icons.description, color: _accent),
            title: Text(f.path.split('/').last, maxLines: 2),
            subtitle: Text('${(f.lengthSync() / 1024).round()} KB'),
            trailing: PopupMenuButton<String>(
              onSelected: (choice) async {
                if (choice == 'share') { await _shareFile(f); }
                if (choice == 'delete') { await f.delete(); await _loadSaved(); }
                if (choice == 'print' && f.path.endsWith('.pdf')) {
                  await Printing.layoutPdf(onLayout: (_) => f.readAsBytes());
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'share', child: Text('مشاركة')),
                if (f.path.endsWith('.pdf')) const PopupMenuItem(value: 'print', child: Text('طباعة')),
                const PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          )),
    ]),
  );

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(16), children: [
    _sectionTitle('إعدادات التطبيق'),
    const SizedBox(height: 12),
    Card(child: Column(children: [
      SwitchListTile(
        title: const Text('الوضع الليلي'),
        secondary: const Icon(Icons.dark_mode_outlined),
        value: widget.settings.dark,
        onChanged: (v) async {
          widget.settings.dark = v;
          widget.onThemeChange();
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('dark', v);
        },
      ),
      const Divider(height: 1),
      Padding(
        padding: const EdgeInsets.fromLTRB(14, 15, 14, 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.palette_outlined), SizedBox(width: 8),
            Text('اللون الرئيسي', style: TextStyle(fontWeight: FontWeight.w900)),
          ]),
          const SizedBox(height: 5),
          const Text('اختر لوناً من البطاقات الصغيرة. سيُحفظ اختيارك تلقائياً.',
            style: TextStyle(color: Color(0xFF8492A5), fontSize: 11)),
          const SizedBox(height: 13),
          Wrap(spacing: 9, runSpacing: 10, children: [
            for (final swatch in _accentPalette)
              InkWell(
                onTap: () async {
                  widget.settings.accent = swatch.$2;
                  widget.onThemeChange();
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setInt('accent', swatch.$2.toARGB32());
                },
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  width: 66,
                  padding: const EdgeInsets.fromLTRB(4, 6, 4, 5),
                  decoration: BoxDecoration(
                    color: _accent == swatch.$2
                        ? swatch.$2.withValues(alpha: .12)
                        : Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _accent == swatch.$2 ? swatch.$2
                          : Theme.of(context).colorScheme.outlineVariant,
                      width: _accent == swatch.$2 ? 2 : 1,
                    ),
                  ),
                  child: Column(children: [
                    Container(
                      height: 32, width: 36,
                      decoration: BoxDecoration(color: swatch.$2,
                        borderRadius: BorderRadius.circular(9)),
                      child: _accent == swatch.$2
                          ? const Icon(Icons.check_rounded, color: Colors.white, size: 20)
                          : null,
                    ),
                    const SizedBox(height: 4),
                    Text(swatch.$1, style: const TextStyle(fontSize: 9,
                      fontWeight: FontWeight.w700), maxLines: 1,
                      textAlign: TextAlign.center),
                  ]),
                ),
              ),
          ]),
        ]),
      ),
    ])),
    Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('جودة الصور المستوردة', style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 7),
        Text('جودة ضغط صور المعرض: $_captureQuality%', style: const TextStyle(fontSize: 12)),
        Slider(value: _captureQuality.toDouble(), min: 65, max: 100, divisions: 7,
          onChanged: (v) => setState(() => _captureQuality = v.round()),
          onChangeEnd: (v) async {
            final prefs = await SharedPreferences.getInstance();
            await prefs.setInt('capture_quality', v.round());
          }),
        const Text('التصوير يحفظ الصورة دون ضغط إضافي لتسريع ظهورها، ويمكن تصحيح المنظور لاحقاً.',
          style: TextStyle(fontSize: 11, color: Color(0xFF8C9BB0))),
      ],
    ))),
    Card(child: Column(children: [
      const ListTile(leading: Icon(Icons.lock_outline), title: Text('الخصوصية'),
        subtitle: Text('الصور تُعالج محلياً على الهاتف ولا تُرفع إلى خادم')),
      const Divider(height: 1),
      ListTile(
        leading: const Icon(Icons.delete_sweep_outlined),
        title: const Text('حذف الملفات المؤقتة'),
        onTap: () async {
          final directory = await getTemporaryDirectory();
          for (final file in directory.listSync().whereType<File>()) {
            if (file.path.contains('mustamsakati_temp_')) {
              await file.delete();
            }
          }
          if (mounted) {
            _message('تم تنظيف الملفات المؤقتة');
          }
        },
      ),
      const Divider(height: 1),
      const ListTile(leading: Icon(Icons.info_outline),
        title: Text('مستمسكاتي 7.1.0'), subtitle: Text('تطبيق Flutter أصلي — بدون WebView')),
    ])),
  ]);
}

class CornerEditor extends StatefulWidget {
  const CornerEditor({super.key, required this.photo});
  final PhotoData photo;

  @override
  State<CornerEditor> createState() => _CornerEditorState();
}

class _CornerEditorState extends State<CornerEditor> {
  late List<Offset> _corners;
  int _active = -1;
  int _rotation = 0;
  double _brightness = 0;
  bool _saving = false;
  bool _detecting = false;
  int? _dragPointer;
  Offset _lensPoint = const Offset(.5, .5);
  ui.Image? _lensBitmap;
  Size _imageViewport = Size.zero;

  @override
  void initState() {
    super.initState();
    _corners = List.of(defaultCorners);
    _prepareLensImage();
  }

  Future<void> _prepareLensImage() async {
    try {
      final codec = await ui.instantiateImageCodec(widget.photo.bytes,
          targetWidth: 1800, allowUpscaling: false);
      final frame = await codec.getNextFrame();
      codec.dispose();
      if (!mounted) {
        frame.image.dispose();
        return;
      }
      setState(() => _lensBitmap = frame.image);
    } catch (_) {
      // The editor remains usable even if the zoom image cannot be decoded.
    }
  }

  @override
  void dispose() {
    _lensBitmap?.dispose();
    super.dispose();
  }

  void _startDrag(PointerDownEvent event, double width, double height) {
    if (_dragPointer != null) {
      return;
    }
    var closest = double.infinity;
    var hit = -1;
    for (var i = 0; i < 4; ++i) {
      final point = Offset(_corners[i].dx * width, _corners[i].dy * height);
      final distance = (point - event.localPosition).distance;
      if (distance < closest && distance <= 68) {
        hit = i;
        closest = distance;
      }
    }
    if (hit >= 0) {
      setState(() {
        _active = hit;
        _dragPointer = event.pointer;
        _lensPoint = _corners[hit];
      });
    }
  }

  void _continueDrag(PointerMoveEvent event, double width, double height) {
    if (_dragPointer != event.pointer || _active < 0) {
      return;
    }
    final next = Offset(
      (event.localPosition.dx / width).clamp(0.0, 1.0),
      (event.localPosition.dy / height).clamp(0.0, 1.0),
    );
    final candidate = List<Offset>.from(_corners);
    candidate[_active] = next;
    setState(() {
      // The lens follows the finger even when an invalid crossing is rejected.
      _lensPoint = next;
      if (isValidQuadrilateral(candidate)) {
        _corners = candidate;
      }
    });
  }

  void _endDrag(int pointer) {
    if (_dragPointer == pointer) {
      setState(() {
        _dragPointer = null;
        _active = -1;
      });
    }
  }

  Widget _magnifier() {
    if (_active < 0) {
      return const SizedBox.shrink();
    }
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      SizedBox(width: 116, height: 116,
        child: CustomPaint(painter: _ActualCornerLensPainter(
          _lensBitmap, _lensPoint, _imageViewport,
          Theme.of(context).colorScheme.primary,
        )),
      ),
      const SizedBox(height: 3),
      Text('الزاوية ${_active + 1} / 4 • حرّك إصبعك بدقة',
        style: TextStyle(color: Theme.of(context).colorScheme.primary,
          fontSize: 10, fontWeight: FontWeight.w900)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final aspect = widget.photo.aspect;
    return Scaffold(
      appBar: AppBar(title: const Text('تصحيح الزوايا والمنظور')),
      body: SafeArea(child: Column(children: [
        SizedBox(height: 142, child: Center(child: _active >= 0
          ? _magnifier()
          : const Padding(padding: EdgeInsets.all(16),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.zoom_in_rounded, size: 28),
                SizedBox(height: 9),
                Text('اسحب أي زاوية لتصحيح الميل',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                SizedBox(height: 4),
                Text('ستظهر عدسة مكبّرة هنا، بعيداً عن إصبعك.',
                    style: TextStyle(fontSize: 11)),
              ]))),
        ),
        Expanded(child: Padding(
          padding: const EdgeInsets.all(14),
          child: LayoutBuilder(builder: (context, limits) {
            final width = math.min(limits.maxWidth, limits.maxHeight * aspect);
            final height = width / aspect;
            // Listener is immediate and does not wait for the pan gesture arena.
            // It works independently for each of the four visible handles.
            _imageViewport = Size(width, height);
            return Center(child: SizedBox(
              width: width, height: height,
              child: Listener(
                key: const ValueKey('corner_touch_layer'),
                behavior: HitTestBehavior.opaque,
                onPointerDown: (e) => _startDrag(e, width, height),
                onPointerMove: (e) => _continueDrag(e, width, height),
                onPointerUp: (e) => _endDrag(e.pointer),
                onPointerCancel: (e) => _endDrag(e.pointer),
                child: Stack(fit: StackFit.expand, children: [
                  Image.memory(widget.photo.bytes, fit: BoxFit.fill,
                      gaplessPlayback: true),
                  IgnorePointer(child: CustomPaint(
                    painter: _CornersPainter(_corners, _active))),
                ]),
              ),
            ));
          }),
        )),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Column(children: [
          Wrap(spacing: 7, runSpacing: 5, children: [
            OutlinedButton.icon(
              onPressed: () => setState(() => _corners = List.of(defaultCorners)),
              icon: const Icon(Icons.restart_alt, size: 17),
              label: const Text('إعادة الزوايا')),
            OutlinedButton.icon(
              onPressed: () => setState(() => _rotation = (_rotation + 90) % 360),
              icon: const Icon(Icons.rotate_right, size: 17),
              label: const Text('تدوير 90°')),
            OutlinedButton.icon(
              onPressed: _detecting ? null : () async {
                setState(() => _detecting = true);
                try {
                  final guess = await suggestDocumentCorners(widget.photo.bytes);
                  if (mounted && isValidQuadrilateral(guess)) {
                    setState(() => _corners = guess);
                  }
                } catch (error) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('تعذّر اقتراح الحدود: $error')));
                  }
                } finally {
                  if (mounted) {
                    setState(() => _detecting = false);
                  }
                }
              },
              icon: const Icon(Icons.auto_fix_high_rounded, size: 17),
              label: Text(_detecting ? 'جارٍ التحديد...' : 'حدود مقترحة')),
          ]),
          Row(children: [
            const Icon(Icons.brightness_6_outlined),
            const SizedBox(width: 8),
            const Text('الإضاءة'),
            Expanded(child: Slider(value: _brightness, min: -50, max: 50,
              onChanged: (v) => setState(() => _brightness = v))),
          ]),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            onPressed: _saving ? null : () async {
              setState(() => _saving = true);
              try {
                final bytes = await rectifyImage(PerspectiveArgs(
                  widget.photo.bytes, _corners, _rotation, _brightness.round()));
                if (!context.mounted) {
                  return;
                }
                final codec = await ui.instantiateImageCodec(bytes);
                final frame = await codec.getNextFrame();
                final result = PhotoData(bytes, frame.image.width, frame.image.height);
                frame.image.dispose();
                codec.dispose();
                if (context.mounted) {
                  Navigator.pop(context, result);
                }
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('تعذّر تصحيح المنظور: $e')),
                  );
                }
              } finally {
                if (mounted) {
                  setState(() => _saving = false);
                }
              }
            },
            icon: _saving ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.check_circle_outline_rounded),
            label: Text(_saving ? 'جارٍ التصحيح...' : 'تطبيق التصحيح'),
          )),
          const SizedBox(height: 12),
        ])),
      ])),
    );
  }
}

/// Magnifies the *actual source image pixels* under the dragged corner.
/// The mapping uses the displayed image's real Size, rather than a hardcoded
/// 168px canvas; the latter was why the old lens appeared stuck or blank.
class _ActualCornerLensPainter extends CustomPainter {
  const _ActualCornerLensPainter(this.image, this.point, this.viewSize, this.tint);
  final ui.Image? image;
  final Offset point;
  final Size viewSize;
  final Color tint;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final oval = Offset.zero & size;
    canvas.save();
    canvas.clipPath(Path()..addOval(oval));
    canvas.drawColor(const Color(0xFFECF3F8), BlendMode.src);
    final bitmap = image;
    if (bitmap != null && !viewSize.isEmpty) {
      const zoom = 3.5;
      final sx = zoom * viewSize.width / bitmap.width;
      final sy = zoom * viewSize.height / bitmap.height;
      canvas.translate(center.dx - point.dx * bitmap.width * sx,
          center.dy - point.dy * bitmap.height * sy);
      canvas.scale(sx, sy);
      canvas.drawImage(bitmap, Offset.zero,
          Paint()..filterQuality = FilterQuality.medium);
    }
    canvas.restore();
    canvas.drawOval(oval.deflate(2), Paint()..style = PaintingStyle.stroke
      ..strokeWidth = 3..color = tint);
    canvas.drawLine(center.translate(-17, 0), center.translate(17, 0),
      Paint()..color = const Color(0xFF143552)..strokeWidth = 3);
    canvas.drawLine(center.translate(0, -17), center.translate(0, 17),
      Paint()..color = const Color(0xFF143552)..strokeWidth = 3);
    canvas.drawCircle(center, 3.2, Paint()..color = const Color(0xFFFFCE56));
  }

  @override
  bool shouldRepaint(covariant _ActualCornerLensPainter old) =>
      old.image != image || old.point != point || old.viewSize != viewSize ||
      old.tint != tint;
}

class _CornersPainter extends CustomPainter {
  const _CornersPainter(this.points, this.active);
  final List<Offset> points;
  final int active;

  @override
  void paint(Canvas canvas, Size size) {
    final coords = [for (final p in points) Offset(p.dx * size.width, p.dy * size.height)];
    final shape = Path()..moveTo(coords.first.dx, coords.first.dy);
    for (var i = 1; i < 4; ++i) {
      shape.lineTo(coords[i].dx, coords[i].dy);
    }
    shape.close();
    canvas.drawPath(shape, Paint()..color = Colors.black.withValues(alpha: .13));
    canvas.drawPath(shape, Paint()
      ..color = const Color(0xFF50E5E6)..strokeWidth = 2.3..style = PaintingStyle.stroke);
    for (var i = 0; i < coords.length; ++i) {
      canvas.drawCircle(coords[i], i == active ? 15 : 12, Paint()..color = Colors.white);
      canvas.drawCircle(coords[i], i == active ? 10 : 7, Paint()..color = i == active ? Colors.orange : _blue);
    }
  }

  @override
  bool shouldRepaint(covariant _CornersPainter old) =>
      old.active != active || old.points != points;
}

/// Draws the same nine illustrative paper diagrams as the HTML V7 options.
/// It never displays users' identity photos in layout option cards.
class _LayoutSchematicPainter extends CustomPainter {
  const _LayoutSchematicPainter(this.mode);
  final LayoutStyle mode;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 76, size.height / 90);
    final paper = RRect.fromRectAndRadius(
      const Rect.fromLTWH(2.5, 2.5, 71, 85), const Radius.circular(5));
    canvas.drawRRect(paper, Paint()..color = Colors.white);
    canvas.drawRRect(paper, Paint()..color = const Color(0xFFD7E0EF)
      ..strokeWidth = 1.5..style = PaintingStyle.stroke);
    void card(double x, double y, double w, double h, {bool second = false}) {
      final r = RRect.fromRectAndRadius(Rect.fromLTWH(x, y, w, h),
        const Radius.circular(3.5));
      final fill = second ? const Color(0xFFBDE2D7) : const Color(0xFFC6DEF5);
      final edge = second ? const Color(0xFF7BBDAD) : const Color(0xFF92B7E0);
      canvas.drawRRect(r, Paint()..color = fill);
      canvas.drawRRect(r, Paint()
        ..color = edge
        ..strokeWidth = .7
        ..style = PaintingStyle.stroke);
    }
    switch (mode) {
      case LayoutStyle.sideCenter:
        card(7, 37, 28, 18); card(41, 37, 28, 18, second: true);
      case LayoutStyle.sideTop:
        card(7, 10, 28, 18); card(41, 10, 28, 18, second: true);
      case LayoutStyle.verticalCenter:
        card(16, 25, 44, 22); card(16, 54, 44, 22, second: true);
      case LayoutStyle.stackRight:
        card(38, 13, 30, 20); card(38, 40, 30, 20, second: true);
      case LayoutStyle.stackLeft:
        card(9, 13, 30, 20); card(9, 40, 30, 20, second: true);
      case LayoutStyle.separate:
        canvas.drawRect(const Rect.fromLTWH(9, 20, 26, 45),
          Paint()..color = const Color(0xFFF7F9FC));
        canvas.drawRect(const Rect.fromLTWH(42, 20, 26, 45),
          Paint()..color = const Color(0xFFF7F9FC));
        card(13, 30, 18, 13); card(46, 30, 18, 13, second: true);
      case LayoutStyle.halves:
        card(10, 17, 56, 23); card(10, 54, 56, 23, second: true);
        canvas.drawLine(const Offset(9, 47), const Offset(67, 47),
          Paint()..color = const Color(0xFF9CAABD)..strokeWidth = 1);
      case LayoutStyle.single:
        card(12, 30, 52, 30);
      case LayoutStyle.free:
        canvas.save();
        canvas.translate(26, 33); canvas.rotate(-.12);
        card(-19, -13, 38, 27);
        canvas.restore();
        canvas.save();
        canvas.translate(49, 56); canvas.rotate(.12);
        card(-16, -12, 33, 24, second: true);
        canvas.restore();
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LayoutSchematicPainter oldDelegate) =>
      oldDelegate.mode != mode;
}
