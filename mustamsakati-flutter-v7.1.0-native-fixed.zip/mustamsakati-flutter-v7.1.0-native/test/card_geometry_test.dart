import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mustamsakati/card_geometry.dart';
import 'package:mustamsakati/layouts.dart';

void main() {
  test('Identity types use natural ID-1 print dimensions on A4', () {
    for (final kind in ['البطاقة الوطنية', 'بطاقة السكن', 'إجازة السوق']) {
      final doc = ScanDocument(kind)
        ..front = PhotoData(Uint8List.fromList([1]), 1300, 820)
        ..back = PhotoData(Uint8List.fromList([2]), 1600, 1000);
      final settings = PrintSettings()..style = LayoutStyle.sideTop;
      final sheet = layoutDocument(doc, settings).single;
      expect(sheet.placements.length, 2);
      for (final p in sheet.placements) {
        expect(p.rect.width, closeTo(identityCardWidthMm * pointsPerMm, .02));
        expect(p.rect.height, closeTo(identityCardHeightMm * pointsPerMm, .02));
      }
    }
  });

  test('Scanner changes the pixels but not the printed card size', () {
    final original = PhotoData(Uint8List.fromList([1]), 1400, 880);
    final differentFilter = PhotoData(Uint8List.fromList([2]), 1600, 900);
    final doc = ScanDocument('البطاقة الوطنية')
      ..front = original..frontOriginal = original;
    final print = PrintSettings()..style = LayoutStyle.single;
    final before = layoutDocument(doc, print).single.placements.single.rect;
    doc.front = differentFilter;
    doc.frontAppearance = ScanAppearance.smart;
    final after = layoutDocument(doc, print).single.placements.single.rect;
    expect(after, before);
  });

  test('Every physical card stays within A5 and A4 margins', () {
    final photo = PhotoData(Uint8List.fromList([1]), 1000, 640);
    final doc = ScanDocument('بطاقة السكن')..front = photo..back = photo;
    for (final a5 in [true, false]) {
      for (final landscape in [true, false]) {
        for (final mode in LayoutStyle.values) {
          final settings = PrintSettings()
            ..a5 = a5..landscape = landscape..style = mode;
          final sheets = layoutDocument(doc, settings);
          for (final placement in sheets.expand((s) => s.placements)) {
            expect(placement.rect.left, greaterThanOrEqualTo(settings.margin - .1));
            expect(placement.rect.top, greaterThanOrEqualTo(settings.margin - .1));
            expect(placement.rect.right,
                lessThanOrEqualTo(settings.paper.width - settings.margin + .1));
            expect(placement.rect.bottom,
                lessThanOrEqualTo(settings.paper.height - settings.margin + .1));
          }
        }
      }
    }
  });

  test('The camera overlay is card shaped, centered and inside the viewfinder', () {
    const viewport = Size(390, 645);
    final guide = frameForCamera(viewport, card: true);
    expect(guide.width / guide.height, closeTo(identityCardAspect, 1e-8));
    expect(guide.center, const Offset(195, 322.5));
    expect((Offset.zero & viewport).contains(guide.topLeft), true);
    expect((Offset.zero & viewport).contains(guide.bottomRight), true);
    final doc = frameForCamera(viewport, card: false);
    expect(doc.width / doc.height, closeTo(1 / 1.4142135623730951, 1e-8));
  });

  test('The cropped photo corresponds to the on-screen camera guide', () {
    const viewport = Size(390, 700);
    const source = Size(3000, 4000);
    final guide = frameForCamera(viewport, card: true);
    final crop = cameraFrameInPhoto(photoSize: source, viewSize: viewport,
        frame: guide);
    expect(crop.width / crop.height, closeTo(identityCardAspect, 1e-8));
    expect(crop.left, greaterThanOrEqualTo(0));
    expect(crop.top, greaterThanOrEqualTo(0));
    expect(crop.right, lessThanOrEqualTo(source.width));
    expect(crop.bottom, lessThanOrEqualTo(source.height));
  });
}
