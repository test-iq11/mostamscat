import 'dart:io';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

import 'card_geometry.dart';
import 'rounded_card.dart';

class _CameraCropRequest {
  const _CameraCropRequest(this.bytes, this.viewport, this.frame, this.roundCard);
  final Uint8List bytes;
  final Size viewport;
  final Rect frame;
  final bool roundCard;
}

/// Uses the same viewfinder geometry as the live guide. Runs off the UI
/// isolate to avoid blocking the shutter animation or preview.
Uint8List _cropToCameraGuide(_CameraCropRequest request) {
  final decoded = img.decodeImage(request.bytes);
  if (decoded == null) {
    throw const FormatException('تعذر قراءة صورة الكاميرا');
  }
  final upright = img.bakeOrientation(decoded);
  final rect = cameraFrameInPhoto(
    photoSize: Size(upright.width.toDouble(), upright.height.toDouble()),
    viewSize: request.viewport,
    frame: request.frame,
  );
  final x = rect.left.round().clamp(0, upright.width - 1).toInt();
  final y = rect.top.round().clamp(0, upright.height - 1).toInt();
  final width = rect.width.round().clamp(1, upright.width - x).toInt();
  final height = rect.height.round().clamp(1, upright.height - y).toInt();
  var cropped = img.copyCrop(upright, x: x, y: y, width: width, height: height);
  if (math.max(cropped.width, cropped.height) > 2400) {
    final scale = 2400 / math.max(cropped.width, cropped.height);
    cropped = img.copyResize(cropped,
        width: (cropped.width * scale).round().clamp(1, 2400).toInt(),
        height: (cropped.height * scale).round().clamp(1, 2400).toInt());
  }
  return request.roundCard ? encodeRoundedCard(cropped) : img.encodeJpg(cropped, quality: 92);
}

class CardCameraScreen extends StatefulWidget {
  const CardCameraScreen({super.key, required this.card, required this.documentName,
      this.autoCapture = false, this.faceLabel});
  final bool card;
  final String documentName;
  final bool autoCapture;
  final String? faceLabel;

  @override
  State<CardCameraScreen> createState() => _CardCameraScreenState();
}

class _CardCameraScreenState extends State<CardCameraScreen>
    with WidgetsBindingObserver {
  CameraController? _controller;
  bool _busy = false;
  bool _initializing = true;
  String? _error;
  Size _viewSize = Size.zero;
  Rect _guide = Rect.zero;
  FlashMode _flash = FlashMode.off;
  int _receiptLength = 1;
  int _cameraGeneration = 0;
  DateTime? _sampledAt;
  List<int>? _lastSample;
  int _stableFrames = 0;
  String? _assistantHint;

  bool get _isReceipt => widget.documentName == 'إيصال';
  double? get _documentAspect => _isReceipt
      ? const [.63, .4, .25][_receiptLength]
      : widget.documentName == 'جواز السفر' ? 1.42 : null;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initialize();
  }

  Future<void> _initialize() async {
    final generation = ++_cameraGeneration;
    if (mounted) {
      setState(() { _initializing = true; _error = null; });
    }
    CameraController? created;
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        throw StateError('لا تتوفر كاميرا على هذا الجهاز');
      }
      final camera = cameras.firstWhere(
          (c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => cameras.first);
      created = CameraController(camera, ResolutionPreset.high, enableAudio: false,
        imageFormatGroup: ImageFormatGroup.yuv420);
      await created.initialize();
      try {
        await created.setFlashMode(_flash);
      } on CameraException {
        // A camera without a flash can still take pictures.
      }
      if (!mounted || generation != _cameraGeneration) {
        await created.dispose();
        return;
      }
      final ready = created;
      setState(() { _controller = ready; _initializing = false; });
      await _startAssistant(ready);
    } catch (e) {
      if (created != null) {
        await created.dispose();
      }
      if (mounted && generation == _cameraGeneration) {
        setState(() { _controller = null; _initializing = false; _error = 'تعذر تشغيل الكاميرا: $e'; });
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      ++_cameraGeneration;
      final old = _controller;
      _controller = null;
      old?.dispose();
    } else if (state == AppLifecycleState.resumed && _controller == null &&
        (!_initializing || _cameraGeneration > 1) && !_busy) {
      _initialize();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    ++_cameraGeneration;
    _controller?.dispose();
    super.dispose();
  }

  Future<void> _startAssistant(CameraController camera) async {
    if (!widget.autoCapture || !mounted || _controller != camera ||
        camera.value.isStreamingImages) {
      return;
    }
    _lastSample = null;
    _stableFrames = 0;
    _sampledAt = null;
    try {
      await camera.startImageStream(_assessFrame);
    } on CameraException {
      if (mounted && _controller == camera) {
        setState(() => _assistantHint = 'التقاط يدوي · المساعد غير متاح على هذه الكاميرا');
      }
    }
  }

  void _assessFrame(CameraImage frame) {
    if (!mounted || _busy || _guide.isEmpty || frame.format.group != ImageFormatGroup.yuv420 ||
        frame.planes.isEmpty) {
      return;
    }
    final now = DateTime.now();
    if (_sampledAt != null && now.difference(_sampledAt!).inMilliseconds < 230) return;
    _sampledAt = now;
    final yPlane = frame.planes.first;
    final sample = <int>[];
    const grid = 24;
    var sum = 0;
    var bright = 0;
    for (var y = 0; y < grid; y++) {
      final row = (frame.height * (.18 + .64 * y / grid)).floor();
      for (var x = 0; x < grid; x++) {
        final col = (frame.width * (.18 + .64 * x / grid)).floor();
        final position = row * yPlane.bytesPerRow + col * (yPlane.bytesPerPixel ?? 1);
        if (position >= yPlane.bytes.length) return;
        final value = yPlane.bytes[position];
        sample.add(value);
        sum += value;
        if (value > 247) bright++;
      }
    }
    var motion = 0;
    var detail = 0;
    final last = _lastSample;
    for (var i = 0; i < sample.length; i++) {
      if (last != null) motion += (sample[i] - last[i]).abs();
      if (i % grid != 0) detail += (sample[i] - sample[i - 1]).abs();
    }
    _lastSample = sample;
    final String hint;
    if (sum / sample.length < 52) {
      hint = 'الإضاءة ضعيفة';
    } else if (bright / sample.length > .77) {
      hint = 'إضاءة زائدة أو انعكاس على الصورة';
    } else if (detail / sample.length < 5) {
      hint = 'قرّب المستند ووضّح تفاصيله';
    } else if (last == null || motion / sample.length > 4.5) {
      hint = 'ثبّت الهاتف لحظة';
    } else {
      hint = 'الصورة مستقرة';
    }
    if (_assistantHint != hint) setState(() => _assistantHint = hint);
    _stableFrames = hint == 'الصورة مستقرة' ? _stableFrames + 1 : 0;
    if (_stableFrames >= 5) _takePhoto();
  }

  Future<void> _takePhoto() async {
    final camera = _controller;
    if (camera == null || _busy || _viewSize.isEmpty || _guide.isEmpty) {
      return;
    }
    final viewSize = _viewSize;
    final guide = _guide;
    var delivered = false;
    setState(() => _busy = true);
    try {
      if (camera.value.isStreamingImages) await camera.stopImageStream();
      if (!mounted || _controller != camera) return;
      final captured = await camera.takePicture();
      final data = await File(captured.path).readAsBytes();
      try {
        await File(captured.path).delete();
      } catch (_) {
        // Temporary camera file may already have been removed.
      }
      final output = await compute(_cropToCameraGuide,
          _CameraCropRequest(data, viewSize, guide, widget.card));
      if (mounted) {
        delivered = true;
        Navigator.of(context).pop(output);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('تعذر التقاط الصورة: $e')));
      }
    } finally {
      if (mounted && !delivered) {
        setState(() => _busy = false);
        await _startAssistant(camera);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final camera = _controller;
    final dark = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: const Color(0xFF101B29),
      appBar: AppBar(
        title: Text(widget.faceLabel ?? widget.documentName),
        foregroundColor: Colors.white,
        backgroundColor: const Color(0xFF152238),
        actions: [
          if (camera != null && camera.value.isInitialized)
            IconButton(
              tooltip: 'تبديل الفلاش',
              icon: Icon(_flash == FlashMode.off
                  ? Icons.flash_off_rounded : Icons.flash_auto_rounded),
              onPressed: () async {
                final next = _flash == FlashMode.off ? FlashMode.auto : FlashMode.off;
                try {
                  await camera.setFlashMode(next);
                  if (mounted) {
                    setState(() => _flash = next);
                  }
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('الفلاش غير مدعوم: $e')));
                  }
                }
              },
            ),
        ],
      ),
      body: Column(children: [
        Expanded(child: _initializing
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(26),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Text(_error!, textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white)),
                      const SizedBox(height: 18),
                      OutlinedButton(onPressed: _initialize,
                          child: const Text('إعادة المحاولة')),
                    ])))
                : camera == null ? const Center(child: CircularProgressIndicator())
                : LayoutBuilder(builder: (context, constraints) {
                    _viewSize = Size(constraints.maxWidth, constraints.maxHeight);
                    _guide = frameForCamera(_viewSize, card: widget.card, documentAspect: _documentAspect);
                    final preview = camera.value.previewSize;
                    // Portrait coordinates of the camera's video preview.
                    final pw = preview?.height ?? 1080.0;
                    final ph = preview?.width ?? 1920.0;
                    return Stack(children: [
                      Positioned.fill(child: ClipRect(child: FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(width: pw, height: ph,
                          child: CameraPreview(camera)),
                      ))),
                      Positioned.fill(child: IgnorePointer(child: CustomPaint(
                        painter: _CameraGuidePainter(_guide, roundedCard: widget.card),
                      ))),
                      Positioned(
                        top: math.max(12, _guide.top - 42),
                        left: 8, right: 8,
                        child: Center(child: DecoratedBox(
                          decoration: BoxDecoration(color: Colors.black54,
                            borderRadius: BorderRadius.circular(11)),
                          child: Padding(padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 7),
                            child: Text(_assistantHint ?? (widget.card
                              ? 'طابق البطاقة داخل الإطار' : 'طابق المستند داخل الإطار'),
                              style: const TextStyle(color: Colors.white)),
                          ),
                        )),
                      ),
                    ]);
                  })),
        Container(
          color: const Color(0xFF152238),
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
          child: Column(children: [
            if (_isReceipt)
              Wrap(spacing: 6, children: [
                for (final (index, label) in [(0, 'قصير'), (1, 'طويل'), (2, 'طويل جداً')])
                  ChoiceChip(label: Text(label), selected: _receiptLength == index,
                    onSelected: _busy ? null : (_) => setState(() {
                      _receiptLength = index;
                      _stableFrames = 0;
                    })),
              ]),
            Text(widget.card ? 'بطاقة 85.6 × 53.98 ملم — الطباعة بالحجم الطبيعي' :
              'راجع حدود المستند بعد الالتقاط',
              style: const TextStyle(color: Color(0xFFC5D5E5), fontSize: 12)),
            const SizedBox(height: 10),
            Center(child: FilledButton(
              onPressed: _busy || camera == null ? null : _takePhoto,
              style: FilledButton.styleFrom(
                backgroundColor: dark.primary,
                minimumSize: const Size(88, 66),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(32))),
              child: _busy
                  ? const SizedBox(width: 23, height: 23,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Icon(Icons.camera_alt_rounded, size: 30),
            )),
          ]),
        ),
      ]),
    );
  }
}

class _CameraGuidePainter extends CustomPainter {
  const _CameraGuidePainter(this.guide, {required this.roundedCard});
  final Rect guide;
  final bool roundedCard;

  @override
  void paint(Canvas canvas, Size size) {
    final outer = Path()..addRect(Offset.zero & size);
    final radius = roundedCard ? cardCornerRadius(guide.width, guide.height) : 15.0;
    final opening = RRect.fromRectAndRadius(guide, Radius.circular(radius));
    final hole = Path()..addRRect(opening);
    final shade = Path.combine(PathOperation.difference, outer, hole);
    canvas.drawPath(shade, Paint()..color = Colors.black.withValues(alpha: .58));
    canvas.drawRRect(opening,
        Paint()..color = const Color(0xFF5DE6DB)
          ..strokeWidth = 3..style = PaintingStyle.stroke);
    if (roundedCard) {
      return;
    }
    const length = 25.0;
    final corners = [
      (Offset(guide.left, guide.top), 1.0, 1.0),
      (Offset(guide.right, guide.top), -1.0, 1.0),
      (Offset(guide.right, guide.bottom), -1.0, -1.0),
      (Offset(guide.left, guide.bottom), 1.0, -1.0),
    ];
    for (final point in corners) {
      final p = Path()..moveTo(point.$1.dx + length * point.$2, point.$1.dy)
        ..lineTo(point.$1.dx, point.$1.dy)
        ..lineTo(point.$1.dx, point.$1.dy + length * point.$3);
      canvas.drawPath(p, Paint()..color = Colors.white..strokeWidth = 4
          ..strokeCap = StrokeCap.round..style = PaintingStyle.stroke);
    }
  }

  @override
  bool shouldRepaint(covariant _CameraGuidePainter old) => old.guide != guide || old.roundedCard != roundedCard;
}
