import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Default ISO ID-1 dimensions in millimeters. Users may adjust the output
/// scale in the print screen if their document differs from this standard.
const double identityCardWidthMm = 85.60;
const double identityCardHeightMm = 53.98;
const double pointsPerMm = 72.0 / 25.4;
const double identityCardAspect = identityCardWidthMm / identityCardHeightMm;

bool isIdentityCard(String title) => const {
  'البطاقة الوطنية', 'إجازة السوق', 'بطاقة السكن', 'بطاقات تجريبية', 'بطاقات صغيرة',
}.contains(title);

/// The overlay is the visible region for the *actual captured crop*.
Rect frameForCamera(Size viewport, {required bool card, double? documentAspect}) {
  final aspect = card ? identityCardAspect : documentAspect ?? 1 / math.sqrt2;
  final maxWidth = viewport.width * 0.88;
  final maxHeight = viewport.height * 0.65;
  final width = math.min(maxWidth, maxHeight * aspect);
  final height = width / aspect;
  return Rect.fromCenter(center: Offset(viewport.width / 2, viewport.height / 2),
      width: width, height: height);
}

/// Map the viewfinder frame to the (upright) captured photo. The camera feed
/// fills the display with BoxFit.cover; unshown border areas are excluded.
Rect cameraFrameInPhoto({
  required Size photoSize,
  required Size viewSize,
  required Rect frame,
}) {
  final scale = math.max(viewSize.width / photoSize.width,
      viewSize.height / photoSize.height);
  final visibleWidth = viewSize.width / scale;
  final visibleHeight = viewSize.height / scale;
  final visibleLeft = (photoSize.width - visibleWidth) / 2;
  final visibleTop = (photoSize.height - visibleHeight) / 2;
  final result = Rect.fromLTWH(
    visibleLeft + frame.left / scale,
    visibleTop + frame.top / scale,
    frame.width / scale,
    frame.height / scale,
  );
  return result.intersect(Offset.zero & photoSize);
}
