import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' show IconData, Icons;
import 'package:image/image.dart' as im;

import 'layouts.dart';

extension ScanAppearanceLabel on ScanAppearance {
  String get label => switch (this) {
    ScanAppearance.original => 'الأصلية',
    ScanAppearance.smart => 'سكنر ذكي',
    ScanAppearance.color => 'سكنر ملون',
    ScanAppearance.gray => 'رمادي',
    ScanAppearance.blackWhite => 'أبيض وأسود',
    ScanAppearance.soft => 'هادئ',
    ScanAppearance.whitePaper => 'صفحة بيضاء',
    ScanAppearance.highContrast => 'تباين مرتفع',
    ScanAppearance.warm => 'دافئ',
    ScanAppearance.cool => 'بارد',
  };

  String get description => switch (this) {
    ScanAppearance.original => 'الصورة الأصلية كما التُقطت',
    ScanAppearance.smart => 'إضاءة وتباين أوضح',
    ScanAppearance.color => 'ألوان زاهية للبطاقات',
    ScanAppearance.gray => 'إزالة الألوان وإبراز النص',
    ScanAppearance.blackWhite => 'مناسب للمستندات النصية',
    ScanAppearance.soft => 'تحسين طبيعي خفيف',
    ScanAppearance.whitePaper => 'تفتيح الورق',
    ScanAppearance.highContrast => 'تقوية الكتابة الباهتة',
    ScanAppearance.warm => 'تدرجات دافئة',
    ScanAppearance.cool => 'تدرجات باردة',
  };

  IconData get icon => switch (this) {
    ScanAppearance.original => Icons.photo_outlined,
    ScanAppearance.smart => Icons.auto_awesome_outlined,
    ScanAppearance.color => Icons.palette_outlined,
    ScanAppearance.gray => Icons.gradient_outlined,
    ScanAppearance.blackWhite => Icons.contrast_outlined,
    ScanAppearance.soft => Icons.wb_sunny_outlined,
    ScanAppearance.whitePaper => Icons.article_outlined,
    ScanAppearance.highContrast => Icons.hdr_strong_outlined,
    ScanAppearance.warm => Icons.wb_sunny_rounded,
    ScanAppearance.cool => Icons.ac_unit_outlined,
  };
}

class _ScanJob {
  const _ScanJob(this.bytes, this.appearance);
  final Uint8List bytes;
  final ScanAppearance appearance;
}

/// Decode and process off the UI thread, after the user chooses a scan filter.
Future<Uint8List> scanImageAsync(Uint8List bytes, ScanAppearance appearance) =>
    appearance == ScanAppearance.original
        ? Future.value(bytes)
        : compute(_runScanner, _ScanJob(bytes, appearance));

Uint8List scanImageSync(Uint8List bytes, ScanAppearance appearance) =>
    _runScanner(_ScanJob(bytes, appearance));

Uint8List _runScanner(_ScanJob job) {
  if (job.appearance == ScanAppearance.original) {
    return job.bytes;
  }
  final decoded = im.decodeImage(job.bytes);
  if (decoded == null) {
    throw const FormatException('Unsupported image format');
  }
  var source = im.bakeOrientation(decoded);
  final longest = math.max(source.width, source.height);
  if (longest > 2000) {
    final factor = 2000.0 / longest;
    source = im.copyResize(source,
      width: math.max(1, (source.width * factor).round()),
      height: math.max(1, (source.height * factor).round()),
      interpolation: im.Interpolation.linear);
  }
  final hasAlpha = source.numChannels == 4;
  final result = im.Image(width: source.width, height: source.height,
      numChannels: hasAlpha ? 4 : 3);
  final mode = job.appearance;
  int byte(num v) => v.round().clamp(0, 255).toInt();
  void setPixel(int x, int y, int r, int g, int b, int alpha) {
    if (hasAlpha) {
      result.setPixelRgba(x, y, r, g, b, alpha);
    } else {
      result.setPixelRgb(x, y, r, g, b);
    }
  }
  for (var y = 0; y < source.height; y++) {
    for (var x = 0; x < source.width; x++) {
      final p = source.getPixel(x, y);
      final alpha = hasAlpha ? byte(p.a) : 255;
      var red = p.r.toDouble();
      var green = p.g.toDouble();
      var blue = p.b.toDouble();
      final lum = .299 * red + .587 * green + .114 * blue;
      if (mode == ScanAppearance.blackWhite) {
        final v = lum >= 152 ? 255 : 0;
        setPixel(x, y, v, v, v, alpha);
        continue;
      }
      if (mode == ScanAppearance.gray || mode == ScanAppearance.whitePaper) {
        final v = mode == ScanAppearance.gray
            ? byte((lum - 128) * 1.18 + 135)
            : byte((lum - 125) * 1.48 + 153);
        setPixel(x, y, v, v, v, alpha);
        continue;
      }
      final contrast = switch (mode) {
        ScanAppearance.smart => 1.2,
        ScanAppearance.color => 1.16,
        ScanAppearance.soft => 1.08,
        ScanAppearance.highContrast => 1.62,
        ScanAppearance.warm || ScanAppearance.cool => 1.1,
        _ => 1.12,
      };
      final light = switch (mode) {
        ScanAppearance.smart => 8.0,
        ScanAppearance.color => 9.0,
        ScanAppearance.soft => 5.0,
        ScanAppearance.highContrast => 10.0,
        _ => 6.0,
      };
      final sat = switch (mode) {
        ScanAppearance.color => 1.37,
        ScanAppearance.smart => 1.13,
        ScanAppearance.highContrast => .78,
        ScanAppearance.soft => 1.04,
        _ => 1.0,
      };
      red = (red - lum) * sat + lum;
      green = (green - lum) * sat + lum;
      blue = (blue - lum) * sat + lum;
      final rShift = mode == ScanAppearance.warm ? 10 : mode == ScanAppearance.cool ? -5 : 0;
      final bShift = mode == ScanAppearance.cool ? 11 : mode == ScanAppearance.warm ? -10 : 0;
      setPixel(x, y,
        byte((red - 128) * contrast + 128 + light + rShift),
        byte((green - 128) * contrast + 128 + light),
        byte((blue - 128) * contrast + 128 + light + bShift), alpha);
    }
  }
  return hasAlpha ? im.encodePng(result) : im.encodeJpg(result, quality: 91);
}
