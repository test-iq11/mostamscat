import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'card_geometry.dart';
import 'layouts.dart';
import 'scan_filters.dart';

typedef QuickCardCapture = Future<PhotoData?> Function(
  BuildContext context, String documentType, bool back,
);
typedef QuickCardEdit = Future<PhotoData?> Function(BuildContext context, PhotoData photo);

class QuickCardResult {
  const QuickCardResult(this.document, this.settings, {required this.saveImmediately});
  final ScanDocument document;
  final PrintSettings settings;
  final bool saveImmediately;
}

/// The capture flow keeps both faces here until the user approves the result.
class QuickCardPage extends StatefulWidget {
  const QuickCardPage({
    super.key,
    required this.capture,
    required this.edit,
    this.initialType = 'البطاقة الوطنية',
    this.initialA5 = false,
    this.initialLandscape = false,
  });

  final QuickCardCapture capture;
  final QuickCardEdit edit;
  final String initialType;
  final bool initialA5;
  final bool initialLandscape;

  @override
  State<QuickCardPage> createState() => _QuickCardPageState();
}

class _QuickCardPageState extends State<QuickCardPage> {
  static const _types = ['البطاقة الوطنية', 'إجازة السوق', 'بطاقة السكن'];
  late String _type = _types.contains(widget.initialType) ? widget.initialType : _types.first;
  late bool _a5 = widget.initialA5;
  bool _busy = false;
  bool _frontApproved = false;
  final _front = _CardFace();
  final _back = _CardFace();

  _CardFace _face(bool back) => back ? _back : _front;

  PrintSettings _printSettings() {
    final settings = PrintSettings()
      ..a5 = _a5
      ..landscape = widget.initialLandscape;
    final need = identityCardWidthMm * pointsPerMm * 2 + settings.gap;
    settings.style = settings.paper.width - settings.margin * 2 >= need
      ? LayoutStyle.sideCenter : LayoutStyle.verticalCenter;
    return settings;
  }

  ScanDocument _document() => ScanDocument(_type)
    ..front = _front.image
    ..back = _back.image
    ..frontOriginal = _front.base
    ..backOriginal = _back.base
    ..frontAppearance = _front.improved ? ScanAppearance.smart : ScanAppearance.original
    ..backAppearance = _back.improved ? ScanAppearance.smart : ScanAppearance.original;

  Future<void> _capture(bool back) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      if (back) _frontApproved = true;
    });
    try {
      final photo = await widget.capture(context, _type, back);
      if (!mounted || photo == null) return;
      setState(() {
        _face(back).replace(photo);
        if (!back && _back.image == null) _frontApproved = false;
      });
    } catch (_) {
      if (mounted) _notice('تعذّر فتح اللقطة. يمكنك إعادة المحاولة.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _edit(bool back) async {
    final face = _face(back);
    final photo = face.base;
    if (_busy || photo == null) return;
    setState(() => _busy = true);
    try {
      final result = await widget.edit(context, photo);
      if (mounted && result != null) setState(() => face.replace(result));
    } catch (_) {
      if (mounted) _notice('تعذّر تعديل الصورة.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleEnhancement(bool back) async {
    final face = _face(back);
    final photo = face.base;
    if (_busy || photo == null) return;
    if (face.improved) {
      setState(() => face.improved = false);
      return;
    }
    if (face.enhanced != null) {
      setState(() => face.improved = true);
      return;
    }
    setState(() => _busy = true);
    try {
      final bytes = await scanImageAsync(photo.bytes, ScanAppearance.smart);
      if (mounted) {
        setState(() {
          // The scanner keeps the image proportions and its alpha channel.
          face.enhanced = PhotoData(bytes, photo.width, photo.height);
          face.improved = true;
        });
      }
    } catch (_) {
      if (mounted) _notice('تعذّر تحسين الصورة. بقيت اللقطة الأصلية.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _notice(String message) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

  void _showDetails(PhotoData photo) {
    showDialog<void>(context: context, builder: (dialogContext) => Dialog(
      child: SafeArea(child: Padding(padding: const EdgeInsets.all(12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('تكبير تفاصيل اللقطة', style: Theme.of(dialogContext).textTheme.titleMedium),
          const SizedBox(height: 8),
          AspectRatio(aspectRatio: photo.aspect, child: ClipRect(
            child: InteractiveViewer(maxScale: 6,
              child: Image.memory(photo.bytes, fit: BoxFit.contain)),
          )),
          const SizedBox(height: 8),
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إغلاق')),
        ]),
      )),
    ));
  }

  void _finish({required bool saveImmediately}) {
    if (_front.image == null || _back.image == null || _busy) return;
    Navigator.pop(context, QuickCardResult(_document(), _printSettings(),
      saveImmediately: saveImmediately));
  }

  @override
  Widget build(BuildContext context) {
    final front = _front.image;
    final back = _back.image;
    final ready = front != null && back != null;
    final scheme = Theme.of(context).colorScheme;
    final heading = ready ? '٣. راجع الوجهين قبل الحفظ' : front == null
      ? '١. صوّر الوجه الأمامي' : _frontApproved
      ? '٢. صوّر الوجه الخلفي' : '١. راجع الوجه الأمامي';
    return Scaffold(
      appBar: AppBar(title: const Text('بطاقة في دقيقة')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(14), children: [
        Text(heading, style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6),
        Text(ready ? 'كبّر الأرقام للتأكد من وضوحها، ثم احفظ الوجهين في ملف واحد.' :
          front == null ? 'ضع البطاقة داخل الإطار الدائري، مع إبقاء الحواف والأرقام واضحة.' :
          'تأكّد من وضوح التفاصيل. يمكنك إعادة تصوير هذا الوجه وحده.',
          style: TextStyle(color: scheme.onSurfaceVariant)),
        const SizedBox(height: 14),
        if (front == null)
          DropdownButtonFormField<String>(
            initialValue: _type,
            decoration: const InputDecoration(labelText: 'نوع البطاقة'),
            items: [for (final type in _types) DropdownMenuItem(value: type, child: Text(type))],
            onChanged: _busy ? null : (value) {
              if (value != null) setState(() => _type = value);
            },
          ),
        if (front != null) _reviewFace(front, back: false),
        if (back != null) _reviewFace(back, back: true),
        if (ready) _paperPreview(),
        const SizedBox(height: 14),
        if (_busy) const LinearProgressIndicator(),
        const SizedBox(height: 6),
        if (!ready)
          FilledButton.icon(
            onPressed: _busy ? null : () => _capture(front != null),
            icon: const Icon(Icons.camera_alt_outlined),
            label: Text(front == null ? 'تصوير الوجه الأمامي' : _frontApproved
              ? 'تصوير الوجه الخلفي' : 'اعتماد الوجه وتصوير الظهر'),
          )
        else ...[
          FilledButton.icon(
            onPressed: _busy ? null : () => _finish(saveImmediately: true),
            icon: const Icon(Icons.picture_as_pdf_outlined),
            label: const Text('حفظ الوجهين PDF'),
          ),
          TextButton(
            onPressed: _busy ? null : () => _finish(saveImmediately: false),
            child: const Text('فتح التخطيطات الكاملة'),
          ),
        ],
      ])),
    );
  }

  Widget _reviewFace(PhotoData photo, {required bool back}) => Card(
    child: Padding(padding: const EdgeInsets.all(10), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(back ? 'الوجه الخلفي' : 'الوجه الأمامي',
          style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 310, maxHeight: 170),
          child: AspectRatio(aspectRatio: photo.aspect, child: GestureDetector(
            onTap: () => _showDetails(photo),
            child: Image.memory(photo.bytes, fit: BoxFit.contain, gaplessPlayback: true,
              cacheWidth: 680, semanticLabel: back ? 'تكبير الوجه الخلفي' : 'تكبير الوجه الأمامي'),
          )),
        )),
        Wrap(alignment: WrapAlignment.center, children: [
          TextButton.icon(
            onPressed: _busy ? null : () => _capture(back),
            icon: const Icon(Icons.camera_alt_outlined, size: 17),
            label: const Text('إعادة التصوير'),
          ),
          TextButton.icon(
            onPressed: _busy ? null : () => _edit(back),
            icon: const Icon(Icons.crop_outlined, size: 17),
            label: const Text('ضبط الزوايا'),
          ),
          TextButton.icon(
            onPressed: _busy ? null : () => _toggleEnhancement(back),
            icon: const Icon(Icons.auto_awesome_outlined, size: 17),
            label: Text(_face(back).improved ? 'عرض الأصل' : 'تحسين الوضوح'),
          ),
        ]),
      ],
    )),
  );

  Widget _paperPreview() {
    final settings = _printSettings();
    final sheet = layoutDocument(_document(), settings).single;
    final paper = settings.paper;
    Size printed(ImagePlacement item) {
      final width = math.min(item.rect.width, item.rect.height * item.photo.aspect);
      return Size(width / pointsPerMm, width / item.photo.aspect / pointsPerMm);
    }
    final sizes = sheet.placements.map(printed).toList();
    final first = sizes.first;
    final second = sizes.last;
    final sameSize = (first.width - second.width).abs() < .05 &&
        (first.height - second.height).abs() < .05;
    String describe(Size size) =>
      '${size.width.toStringAsFixed(2)} × ${size.height.toStringAsFixed(2)} ملم';
    final shrunk = sizes.any((size) =>
      size.width < identityCardWidthMm - .1 || size.height < identityCardHeightMm - .1);
    return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
      Wrap(spacing: 8, children: [
        for (final isA5 in [false, true])
          ChoiceChip(label: Text(isA5 ? 'A5' : 'A4'), selected: _a5 == isA5,
            onSelected: _busy ? null : (_) => setState(() => _a5 = isA5)),
      ]),
      Text(sameSize ? 'مقاس كل وجه: ${describe(first)}' :
        'الأمامي: ${describe(first)}\nالخلفي: ${describe(second)}', textAlign: TextAlign.center),
      if (shrunk)
        const Text('القياس الفعلي أصغر من مقاس البطاقة. راجع حدود القص أو اختر ورقة أكبر.'),
      const SizedBox(height: 8),
      SizedBox(height: 180, child: FittedBox(child: SizedBox(
        width: paper.width, height: paper.height,
        child: ColoredBox(color: Colors.white, child: Stack(children: [
          for (final item in sheet.placements)
            Positioned.fromRect(rect: item.rect, child: Image.memory(item.photo.bytes,
              fit: BoxFit.contain, cacheWidth: 700)),
        ])),
      ))),
    ])));
  }
}

class _CardFace {
  PhotoData? base;
  PhotoData? enhanced;
  bool improved = false;

  PhotoData? get image => improved ? enhanced ?? base : base;

  void replace(PhotoData photo) {
    base = photo;
    enhanced = null;
    improved = false;
  }
}
