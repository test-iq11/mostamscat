import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' show Offset;

import 'package:cryptography/cryptography.dart';

import 'layouts.dart';

class VaultDraft {
  VaultDraft(this.documents, this.filename, this.settings);
  final List<ScanDocument> documents;
  final String filename;
  final PrintSettings settings;
}

const _vaultMagic = [0x4d, 0x53, 0x56, 1];
const _saltLength = 16;
const _nonceLength = 12;
const _tagLength = 16;
const _maxVaultBytes = 96 * 1024 * 1024;

Future<SecretKey> _deriveKey(String password, List<int> salt) =>
    Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: 600000,
      bits: 256,
    ).deriveKeyFromPassword(password: password, nonce: salt);

Map<String, Object>? _encodePhoto(PhotoData? photo) => photo == null ? null : {
  'data': base64Encode(photo.bytes),
  'width': photo.width,
  'height': photo.height,
};

PhotoData? _decodePhoto(Object? value) {
  if (value == null) return null;
  final map = value as Map<String, dynamic>;
  final width = map['width'] as int;
  final height = map['height'] as int;
  if (width < 1 || height < 1) throw const FormatException('Invalid image size');
  return PhotoData(base64Decode(map['data'] as String), width, height);
}

Map<String, Object?> _encodeSide(PhotoData? photo, PhotoData? original,
    ScanAppearance appearance) => {
  'photo': _encodePhoto(photo),
  if (original != null && !identical(photo, original)) 'original': _encodePhoto(original),
  'appearance': appearance.name,
};

(PhotoData?, PhotoData?, ScanAppearance) _decodeSide(Object? value) {
  final map = value as Map<String, dynamic>;
  final photo = _decodePhoto(map['photo']);
  final original = _decodePhoto(map['original']) ?? photo;
  final appearance = ScanAppearance.values.byName(map['appearance'] as String);
  return (photo, original, appearance);
}

Future<Uint8List> sealVault((VaultDraft, String) request) async {
  final (draft, password) = request;
  final settings = draft.settings;
  final plain = utf8.encode(jsonEncode({
    'filename': draft.filename,
    'settings': {
      'a5': settings.a5,
      'landscape': settings.landscape,
      'margin': settings.margin,
      'gap': settings.gap,
      'scale': settings.scale,
      'style': settings.style.name,
      'fill': settings.fillPage,
      'cut': settings.showCut,
      'singleFace': settings.singleFace,
    },
    'documents': [
      for (final doc in draft.documents)
        {
          'title': doc.title,
          'freeOffsets': {for (final item in doc.freeOffsets.entries)
            item.key.toString(): [item.value.dx, item.value.dy]},
          'freeScales': {for (final item in doc.freeScales.entries)
            item.key.toString(): item.value},
          'front': _encodeSide(doc.front, doc.frontOriginal, doc.frontAppearance),
          'back': _encodeSide(doc.back, doc.backOriginal, doc.backAppearance),
          'extra': [
            for (final entry in doc.extras)
              _encodeSide(entry.image, entry.original, entry.appearance),
          ],
        },
    ],
  }));
  if (plain.length > _maxVaultBytes) throw const FormatException('Draft is too large');
  final salt = SecretKeyData.random(length: _saltLength).bytes;
  final cipher = AesGcm.with256bits();
  final key = await _deriveKey(password, salt);
  final box = await cipher.encrypt(plain, secretKey: key, aad: _vaultMagic);
  final bytes = BytesBuilder(copy: false)
    ..add(_vaultMagic)
    ..add(salt)
    ..add(box.nonce)
    ..add(box.mac.bytes)
    ..add(box.cipherText);
  return bytes.takeBytes();
}

Future<VaultDraft> openVault((Uint8List, String) request) async {
  final (bytes, password) = request;
  final saltEnd = _vaultMagic.length + _saltLength;
  final nonceEnd = saltEnd + _nonceLength;
  final tagEnd = nonceEnd + _tagLength;
  if (bytes.length <= tagEnd || bytes.length > _maxVaultBytes + tagEnd) {
    throw const FormatException('Invalid vault size');
  }
  for (var i = 0; i < _vaultMagic.length; ++i) {
    if (bytes[i] != _vaultMagic[i]) throw const FormatException('Invalid vault header');
  }
  final key = await _deriveKey(password, Uint8List.sublistView(bytes, _vaultMagic.length, saltEnd));
  final box = SecretBox(
    Uint8List.sublistView(bytes, tagEnd),
    nonce: Uint8List.sublistView(bytes, saltEnd, nonceEnd),
    mac: Mac(Uint8List.sublistView(bytes, nonceEnd, tagEnd)),
  );
  final plain = await AesGcm.with256bits().decrypt(box, secretKey: key, aad: _vaultMagic);
  final data = jsonDecode(utf8.decode(plain)) as Map<String, dynamic>;
  final raw = data['settings'] as Map<String, dynamic>;
  final settings = PrintSettings()
    ..a5 = raw['a5'] as bool
    ..landscape = raw['landscape'] as bool
    ..margin = (raw['margin'] as num).clamp(18, 65).toDouble()
    ..gap = (raw['gap'] as num).clamp(5, 45).toDouble()
    ..scale = (raw['scale'] as num).clamp(.65, 1.2).toDouble()
    ..style = LayoutStyle.values.byName(raw['style'] as String)
    ..fillPage = raw['fill'] as bool
    ..showCut = raw['cut'] as bool
    ..singleFace = raw['singleFace'] as int?;
  final documents = <ScanDocument>[];
  for (final item in data['documents'] as List<dynamic>) {
    final map = item as Map<String, dynamic>;
    final (front, frontOriginal, frontAppearance) = _decodeSide(map['front']);
    final (back, backOriginal, backAppearance) = _decodeSide(map['back']);
    final doc = ScanDocument(map['title'] as String)
      ..front = front
      ..frontOriginal = frontOriginal
      ..frontAppearance = frontAppearance
      ..back = back
      ..backOriginal = backOriginal
      ..backAppearance = backAppearance;
    for (final entry in map['extra'] as List<dynamic>) {
      final (photo, original, appearance) = _decodeSide(entry);
      doc.extras.add(ExtraScanPage()
        ..image = photo
        ..original = original
        ..appearance = appearance);
    }
    final offsets = map['freeOffsets'] as Map<String, dynamic>? ?? {};
    for (final item in offsets.entries) {
      final xy = item.value as List<dynamic>;
      doc.freeOffsets[int.parse(item.key)] = Offset(
        (xy[0] as num).toDouble(), (xy[1] as num).toDouble());
    }
    final scales = map['freeScales'] as Map<String, dynamic>? ?? {};
    for (final item in scales.entries) {
      doc.freeScales[int.parse(item.key)] = (item.value as num).clamp(.65, 1.2).toDouble();
    }
    documents.add(doc);
  }
  if (documents.isEmpty || !documents.any((doc) => doc.photos.isNotEmpty)) {
    throw const FormatException('No scanned pages');
  }
  return VaultDraft(documents, data['filename'] as String, settings);
}
