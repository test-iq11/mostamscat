import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

import 'layouts.dart';

PhotoData burnRedactions((PhotoData, List<Rect>) request) {
  final (photo, regions) = request;
  final decoded = img.decodeImage(photo.bytes);
  if (decoded == null) throw const FormatException('تعذّر فك الصورة');
  final upright = img.bakeOrientation(decoded);
  final width = upright.width;
  final height = upright.height;
  final flattened = img.Image(width: width, height: height);
  img.fill(flattened, color: img.ColorRgb8(255, 255, 255));
  img.compositeImage(flattened, upright);
  for (final region in regions) {
    final left = (region.left * width).floor().clamp(0, width).toInt();
    final right = (region.right * width).ceil().clamp(0, width).toInt();
    final top = (region.top * height).floor().clamp(0, height).toInt();
    final bottom = (region.bottom * height).ceil().clamp(0, height).toInt();
    if (left < right && top < bottom) {
      img.fillRect(flattened, x1: left, y1: top, x2: right - 1, y2: bottom - 1,
        color: img.ColorRgb8(0, 0, 0));
    }
  }
  return PhotoData(img.encodePng(flattened), width, height);
}

class RedactionEditor extends StatefulWidget {
  const RedactionEditor({super.key, required this.photos});
  final List<PhotoData> photos;

  @override
  State<RedactionEditor> createState() => _RedactionEditorState();
}

class _RedactionEditorState extends State<RedactionEditor> {
  final Map<PhotoData, List<Rect>> _regions = {};
  int _index = 0;
  Offset? _start;
  Rect? _current;

  @override
  Widget build(BuildContext context) {
    final photo = widget.photos[_index];
    final regions = _regions[photo] ?? const <Rect>[];
    final canExport = _regions.values.any((list) => list.isNotEmpty);
    return Scaffold(
      appBar: AppBar(title: const Text('إخفاء البيانات للمشاركة')),
      body: SafeArea(child: Padding(padding: const EdgeInsets.all(16),
        child: Column(children: [
          const Text('اسحب مستطيلاً يغطي البيانات. راجع كل صورة قبل تصدير النسخة.'),
          const SizedBox(height: 8),
          if (widget.photos.length > 1)
            DropdownButton<int>(
              value: _index,
              items: [
                for (var i = 0; i < widget.photos.length; i++)
                  DropdownMenuItem(value: i, child: Text('الصورة ${i + 1}')),
              ],
              onChanged: (i) {
                if (i != null) setState(() { _index = i; _start = null; _current = null; });
              },
            ),
          Expanded(child: Center(child: AspectRatio(
            aspectRatio: photo.aspect,
            child: LayoutBuilder(builder: (_, limits) {
              final width = limits.maxWidth;
              final height = limits.maxHeight;
              Offset normalized(Offset p) => Offset(
                (p.dx / width).clamp(0.0, 1.0).toDouble(),
                (p.dy / height).clamp(0.0, 1.0).toDouble(),
              );
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanStart: (event) => setState(() => _start = normalized(event.localPosition)),
                onPanUpdate: (event) {
                  final start = _start;
                  if (start != null) {
                    setState(() => _current =
                      Rect.fromPoints(start, normalized(event.localPosition)));
                  }
                },
                onPanEnd: (_) => setState(() {
                  final rect = _current;
                  if (rect != null && rect.width > .002 && rect.height > .002) {
                    _regions.putIfAbsent(photo, () => []).add(rect);
                  }
                  _start = null;
                  _current = null;
                }),
                onPanCancel: () => setState(() { _start = null; _current = null; }),
                child: Stack(fit: StackFit.expand, children: [
                  Image.memory(photo.bytes, fit: BoxFit.fill, gaplessPlayback: true),
                  for (final rect in [...regions, if (_current != null) _current!])
                    Positioned(
                      left: rect.left * width, top: rect.top * height,
                      width: rect.width * width, height: rect.height * height,
                      child: const ColoredBox(color: Colors.black),
                    ),
                ]),
              );
            }),
          ))),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 6, children: [
            OutlinedButton(
              onPressed: regions.isEmpty ? null : () => setState(regions.removeLast),
              child: const Text('تراجع'),
            ),
            FilledButton.icon(
              onPressed: canExport ? () => Navigator.pop(context, _regions) : null,
              icon: const Icon(Icons.picture_as_pdf_outlined),
              label: const Text('حفظ PDF مع الإخفاء'),
            ),
          ]),
        ]),
      )),
    );
  }
}
