import 'dart:math' as math;
import 'dart:typed_data';

import 'package:image/image.dart' as img;

/// Keep the corner radius proportional to the physical card, not screen density.
double cardCornerRadius(double width, double height) =>
    math.min(width, height) * .055;

/// Round only the four corners. The middle and all printed dimensions stay put.
Uint8List encodeRoundedCard(img.Image source) {
  final rgba = source.convert(numChannels: 4);
  final radius = cardCornerRadius(rgba.width.toDouble(), rgba.height.toDouble());
  final extent = radius.ceil();
  for (var y = 0; y < extent; y++) {
    for (var x = 0; x < extent; x++) {
      final dx = radius - x - .5;
      final dy = radius - y - .5;
      final distance = math.sqrt(dx * dx + dy * dy);
      final coverage = (radius + .5 - distance).clamp(0.0, 1.0);
      if (coverage == 1) {
        continue;
      }
      for (final (px, py) in [
        (x, y), (rgba.width - 1 - x, y),
        (x, rgba.height - 1 - y), (rgba.width - 1 - x, rgba.height - 1 - y),
      ].toSet()) {
        final pixel = rgba.getPixel(px, py);
        pixel.a = (pixel.a * coverage).round();
      }
    }
  }
  return img.encodePng(rgba);
}
