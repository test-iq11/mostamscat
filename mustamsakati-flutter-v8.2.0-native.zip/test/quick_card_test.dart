import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:mustamsakati/layouts.dart';
import 'package:mustamsakati/perspective.dart';
import 'package:mustamsakati/quick_card.dart';
import 'package:mustamsakati/rounded_card.dart';
import 'package:mustamsakati/scan_filters.dart';

PhotoData _sample(int value) {
  final image = img.Image(width: 856, height: 540);
  img.fill(image, color: img.ColorRgb8(value, 120, 180));
  return PhotoData(encodeRoundedCard(image), image.width, image.height);
}

void main() {
  test('Rounded crop keeps the center opaque and all four corners transparent', () {
    final source = _sample(70);
    final bitmap = img.decodePng(source.bytes)!;
    expect(bitmap.width, source.width);
    expect(bitmap.height, source.height);
    for (final (x, y) in [(0, 0), (855, 0), (0, 539), (855, 539)]) {
      expect(bitmap.getPixel(x, y).a, 0);
    }
    expect(bitmap.getPixel(428, 270).a, 255);
    expect(bitmap.getPixel(428, 270).r, 70);
    expect(bitmap.getPixel(428, 0).a, 255);

    for (final style in ScanAppearance.values) {
      final filtered = img.decodePng(scanImageSync(source.bytes, style))!;
      expect(filtered.getPixel(0, 0).a, 0, reason: style.name);
      expect(filtered.getPixel(428, 270).a, 255, reason: style.name);
    }
  });

  test('Perspective edits reapply the rounded outline of a card', () async {
    final sample = _sample(80);
    final bytes = await rectifyImage(PerspectiveArgs(
      sample.bytes, defaultCorners, 0, 0, roundCard: true));
    final edited = img.decodePng(bytes)!;
    expect(edited.getPixel(0, 0).a, 0);
    expect(edited.getPixel(edited.width ~/ 2, edited.height ~/ 2).a, 255);
  });

  testWidgets('Guided capture retains the front after a cancelled back capture and retake',
      (tester) async {
    await tester.binding.setSurfaceSize(const Size(430, 1550));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final front = _sample(70);
    final back = _sample(110);
    final retake = _sample(150);
    final captures = <bool>[];
    QuickCardResult? saved;

    await tester.pumpWidget(MaterialApp(home: Builder(builder: (context) => Scaffold(
      body: TextButton(
        onPressed: () async {
          saved = await Navigator.push<QuickCardResult>(context, MaterialPageRoute(
            builder: (_) => QuickCardPage(
              initialA5: true,
              capture: (context, type, backSide) async {
                captures.add(backSide);
                if (!backSide) return front;
                if (captures.length == 2) return null;
                return captures.length == 3 ? back : retake;
              },
              edit: (context, image) async => image,
            ),
          ));
        },
        child: const Text('ابدأ'),
      ),
    ))));
    await tester.tap(find.text('ابدأ'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('تصوير الوجه الأمامي'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('اعتماد الوجه وتصوير الظهر'));
    await tester.pumpAndSettle();
    expect(find.text('تصوير الوجه الخلفي'), findsOneWidget);
    expect(find.text('حفظ الوجهين PDF'), findsNothing);
    await tester.tap(find.text('تصوير الوجه الخلفي'));
    await tester.pumpAndSettle();
    expect(find.text('٣. راجع الوجهين قبل الحفظ'), findsOneWidget);
    await tester.tap(find.text('إعادة التصوير').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('حفظ الوجهين PDF'));
    await tester.pumpAndSettle();

    expect(captures, [false, true, true, true]);
    expect(saved!.saveImmediately, isTrue);
    expect(saved!.document.front, same(front));
    expect(saved!.document.back, same(retake));
    expect(saved!.settings.style, LayoutStyle.verticalCenter);
    final printed = layoutDocument(saved!.document, saved!.settings).single.placements;
    expect(printed, hasLength(2));
    expect(printed.first.rect.width, closeTo(242.65, .1));
  });
}
