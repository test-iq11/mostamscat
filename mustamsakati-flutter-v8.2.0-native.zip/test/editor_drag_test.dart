import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as im;
import 'package:mustamsakati/layouts.dart';
import 'package:mustamsakati/main.dart';

void main() {
  testWidgets('Magnifier activates independently at each of the four corners',
      (tester) async {
    final raw = Uint8List.fromList(im.encodeJpg(im.Image(width: 640, height: 400)));
    await tester.pumpWidget(MaterialApp(home: CornerEditor(
      photo: PhotoData(raw, 640, 400))));
    await tester.pumpAndSettle();
    final touch = find.byKey(const ValueKey('corner_touch_layer'));
    expect(touch, findsOneWidget);
    final rect = tester.getRect(touch);
    final points = [
      Offset(rect.left + rect.width * .04, rect.top + rect.height * .04),
      Offset(rect.left + rect.width * .96, rect.top + rect.height * .04),
      Offset(rect.left + rect.width * .96, rect.top + rect.height * .96),
      Offset(rect.left + rect.width * .04, rect.top + rect.height * .96),
    ];
    for (var i = 0; i < 4; ++i) {
      final drag = await tester.startGesture(points[i]);
      await tester.pump();
      expect(find.textContaining('الزاوية ${i + 1} / 4'), findsOneWidget);
      await drag.moveBy(const Offset(5, 5));
      await tester.pump();
      expect(find.textContaining('الزاوية ${i + 1} / 4'), findsOneWidget);
      await drag.up();
      await tester.pump();
      expect(find.textContaining('الزاوية ${i + 1} / 4'), findsNothing);
    }
  });
}
