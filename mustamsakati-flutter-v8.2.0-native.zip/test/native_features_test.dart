import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:mustamsakati/card_geometry.dart';
import 'package:mustamsakati/layouts.dart';
import 'package:mustamsakati/redaction.dart';
import 'package:mustamsakati/vault.dart';

void main() {
  test('Fill page keeps receipt proportions and uses available height', () {
    final receipt = PhotoData(Uint8List(1), 400, 1000);
    final document = ScanDocument('إيصال')..front = receipt;
    final settings = PrintSettings()..fillPage = true;
    final rect = layoutDocument(document, settings).single.placements.single.rect;
    expect(rect.height, closeTo(settings.paper.height - 2 * settings.margin, .001));
    expect(rect.width / rect.height, closeTo(.4, .001));
    expect(rect.center.dx, closeTo(settings.paper.width / 2, .001));
  });

  test('Single-card export selects the requested face without mutating the scan', () {
    final front = PhotoData(Uint8List(1), 856, 540);
    final back = PhotoData(Uint8List(2), 856, 540);
    final document = ScanDocument('البطاقة الوطنية')..front = front..back = back;
    final settings = PrintSettings()..style = LayoutStyle.single..singleFace = 1;
    expect(layoutDocument(document, settings).single.placements.single.photo, same(back));
    expect(document.photos, [front, back]);
    document.extras.add(ExtraScanPage()..image = front);
    expect(layoutDocument(document, settings), hasLength(3));
  });

  test('Receipt camera framing is centered and uses the selected ratio', () {
    final rect = frameForCamera(const Size(400, 800), card: false, documentAspect: .25);
    expect(rect.width / rect.height, closeTo(.25, .001));
    expect(rect.center.dx, closeTo(200, .001));
    expect(rect.center.dy, closeTo(400, .001));
  });

  test('A sharing copy replaces covered pixels and keeps the original intact', () {
    final sample = img.Image(width: 10, height: 10);
    img.fill(sample, color: img.ColorRgb8(240, 160, 130));
    final original = PhotoData(img.encodePng(sample), 10, 10);
    final masked = burnRedactions((original, [const Rect.fromLTWH(.2, .2, .6, .6)]));
    final output = img.decodePng(masked.bytes)!;
    expect(output.getPixel(4, 4).r, 0);
    expect(output.getPixel(9, 9).r, 240);
    expect(img.decodePng(original.bytes)!.getPixel(4, 4).r, 240);
  });

  test('Vault restores a draft and rejects an incorrect passphrase', () async {
    final photo = PhotoData(Uint8List.fromList([9, 5, 1]), 856, 540);
    final doc = ScanDocument('البطاقة الوطنية')..front = photo..frontOriginal = photo;
    doc.freeOffsets[0] = const Offset(80, 100);
    const password = 'my-test-passphrase';
    final sealed = await sealVault((VaultDraft([doc], 'عينة', PrintSettings()), password));
    final opened = await openVault((sealed, password));
    expect(opened.filename, 'عينة');
    expect(opened.documents.single.front!.bytes, [9, 5, 1]);
    expect(opened.documents.single.freeOffsets[0], const Offset(80, 100));
    await expectLater(openVault((sealed, 'incorrect-passphrase')), throwsA(anything));
  }, timeout: const Timeout(Duration(minutes: 2)));
}
