import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as im;
import 'package:mustamsakati/exporters.dart';
import 'package:mustamsakati/layouts.dart';
import 'package:mustamsakati/perspective.dart';

void main() {
  test('Moving a single corner leaves the other corners fixed', () {
    final original = List<Offset>.from(defaultCorners);
    final changed = List<Offset>.from(original);
    changed[0] = const Offset(.13, .1);
    expect(isValidQuadrilateral(changed), isTrue);
    expect(changed[1], original[1]);
    expect(changed[2], original[2]);
    expect(changed[3], original[3]);
  });

  test('Crossing corners is rejected', () {
    expect(isValidQuadrilateral(const [
      Offset(.1, .1), Offset(.9, .9), Offset(.9, .1), Offset(.1, .9),
    ]), isFalse);
  });

  test('Homography maps all four destination corners correctly', () {
    const corners = [
      Offset(.1, .08), Offset(.91, .02), Offset(.85, .9), Offset(.18, .82),
    ];
    final h = solveHomography(corners);
    const outputCorners = [
      Offset(0, 0), Offset(1, 0), Offset(1, 1), Offset(0, 1),
    ];
    for (var i = 0; i < 4; ++i) {
      final u = outputCorners[i].dx;
      final v = outputCorners[i].dy;
      final d = h[6] * u + h[7] * v + 1;
      expect((h[0] * u + h[1] * v + h[2]) / d,
          closeTo(corners[i].dx, 1e-8));
      expect((h[3] * u + h[4] * v + h[5]) / d,
          closeTo(corners[i].dy, 1e-8));
    }
  });

  test('All layouts stay inside page margins', () {
    final photo = PhotoData(Uint8List.fromList([1, 2]), 1200, 720);
    final doc = ScanDocument('test')..front = photo..back = photo;
    final settings = PrintSettings();
    for (final layout in LayoutStyle.values) {
      settings.style = layout;
      for (final page in layoutDocument(doc, settings)) {
        for (final p in page.placements) {
          expect(p.rect.left >= settings.margin - 0.01, isTrue, reason: '$layout left');
          expect(p.rect.top >= settings.margin - 0.01, isTrue, reason: '$layout top');
          expect(p.rect.right <= settings.paper.width - settings.margin + 0.01,
              isTrue, reason: '$layout right');
          expect(p.rect.bottom <= settings.paper.height - settings.margin + 0.01,
              isTrue, reason: '$layout bottom');
        }
      }
    }
  });


  test('PDF output has a real PDF header and two images', () async {
    final bitmap = im.Image(width: 32, height: 20);
    final photo = PhotoData(Uint8List.fromList(im.encodeJpg(bitmap)), 32, 20);
    final doc = ScanDocument('test')..front = photo..back = photo;
    final settings = PrintSettings()..style = LayoutStyle.stackRight;
    final pdf = await Exporter.makePdf(layoutDocument(doc, settings), settings);
    expect(String.fromCharCodes(pdf.take(4)), '%PDF');
  });

  test('Word is an OOXML archive with positioned editable images', () {
    final photo = PhotoData(Uint8List.fromList([0xFF, 0xD8, 0xFF, 0xD9]), 120, 80);
    final doc = ScanDocument('test')..front = photo..back = photo;
    final bytes = Exporter.makeDocx(layoutDocument(doc, PrintSettings()), PrintSettings());
    final zip = ZipDecoder().decodeBytes(bytes);
    final names = zip.files.map((f) => f.name).toSet();
    expect(names.contains('[Content_Types].xml'), isTrue);
    expect(names.contains('word/document.xml'), isTrue);
    expect(names.contains('word/media/image1.jpg'), isTrue);
    expect(names.contains('word/media/image2.jpg'), isTrue);
  });
}
